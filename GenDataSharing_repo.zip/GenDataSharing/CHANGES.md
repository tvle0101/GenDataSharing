# Changes to the released code (second revision)

## Defects in the previously released code
1. `chaincode/genomic/go/genomic.go`: `SeqPriVer`, `SeqTxnFin`, `SharePriVer`, `ShareTxnFin` did not verify any signature; they only checked that the signature string arguments were non-empty. The manuscript stated that the pairing check e(H, σ_b1) = e(σ_b2, g) was executed by the GSC/DSC.
2. The chaincode stored `time.Now()`; chaincode must be deterministic across endorsing peers, and Fabric provides the proposal timestamp (`GetTxTimestamp`) for this purpose. With a 1-of-N endorsement policy the defect is invisible; with an AND policy it produces endorsement mismatches.
3. `benchmark.go` spawned `peer chaincode invoke` via a shell and counted a transaction as successful when the CLI exited 0, i.e. after endorsement and orderer acceptance, not after commit; latency included process start-up; the average divided over an array that kept zeros for failed calls. The reported 29.92 TPS / 0.33 s were therefore not commit figures.
4. Function and field names differed from the paper (`SharePriVer`/`SigmaH2` vs `ShaPriVer`/σ_w2).
5. No code existed for the fault-injection tables (VII–IX) or the trust analysis (Fig. 6).

## What is released now
- `cryptobench/`: the scheme on BLS12-381 (circl) + ECDSA P-256 + AES-GCM/HMAC: SeqPriAcc/SeqPriCfm(+Batch)/SeqPriVer/SeqSignCrypt/SeqUnsignCrypt/SeqTxnFin and the Sha* counterparts; tests; benchmarks (`results/crypto_timings.*`).
- `chaincode/genomic/go/`: GSContract (SeqPriVer, SeqTxnFin, QuerySeqRecord) and DSContract (ShaPriVer, ShaTxnFin, QueryShareRecord) with on-chain ECDSA + pairing verification, proposal timestamps, duplicate-ID rejection; unit tests cover valid, tampered-α_k, tampered-wrapper, wrong-key, malformed-point and duplicate cases.
- `testbed/`: Fabric v2.5.13 built from source, native 3-orderer / 2-org × 2-peer network, Gateway-SDK client that measures commit latency (`SubmitTransaction` returns after commit) and runs the kill tests; `results/` (non-verifying v1 chaincode, for comparison) and `results_v2/` (verifying chaincode = the figures in the paper).
- `sim/`: analytic availability/sensitivity script, discrete-event Raft consortium fault simulator, trust-score simulator; `make_all.sh` regenerates every table and figure; seeds fixed.
