# Where every number in the paper comes from

Table and section numbers refer to the revised manuscript (TR-2026-044, second revision).

| Paper item | Kind | Source in this repository | How to regenerate |
|---|---|---|---|
| Table II unit costs ($P_e$, $E_1$, $E_2$, $EC_s$, $S$); per-algorithm costs and batch-verification costs in Section VII-B | measured | `cryptobench/results/crypto_timings.{md,json}`, raw `bench_raw.txt` | `make crypto-bench` |
| Table II symbolic totals | computed | the row expressions of the table, evaluated with the constants above | by hand |
| Table III storage totals | computed | element sizes of the implementation: $\|G_1\|$ = 48 B (384 bit), $\|G_2\|$ = 96 B (768 bit), $\|Z_q\|$ = 32 B (256 bit), ECDSA signature 64 B (512 bit) | by hand, see the table caption |
| Table IV commit latency / throughput; tampered-transaction tests; 6.4 ms vs 1.9 ms chaincode time | measured | `testbed/results_v2/` (`SUMMARY.md`, `TABLES.md`, `bench.json`, `tamper_*.json`) | `testbed/README.md` |
| Section IX-E follower / peer / leader kill trials | measured | `testbed/results/` (non-verifying chaincode) and `testbed/results_v2/` (verifying chaincode); ten orderer trials per scenario in total | `testbed/README.md` |
| Table V, Table VI, Section VIII-B (common cause, organisation outage), VIII-D (mission reliability) | analytical | `sim/analytic_availability.py` -> `sim/results/analytic_*.csv`, `sim/tables/tab_rel.tex`, `tab_sensitivity.tex`, `tab_mission.tex` | `make sim` |
| Tables VII and VIII, Section IX-F | simulated | `sim/fabric_fault_sim.py` -> `sim/results/fabric_*`, `sim/tables/` | `make sim` |
| Testbed-matched Raft variant quoted in Section IX-F (13.7-15.2 s, $P_{succ}$ = 0.924) | simulated | `sim/results_testbed/`, `sim/results_testbed_tables/` | `python3 sim/fabric_fault_sim.py --outdir <dir> --election-scale 2.5` |
| Section IX-B trust model | simulated | `sim/trust_sim.py` -> `sim/results/trust_*`, `sim/tables/tab_trust*.tex` | `make sim` |
| Sanity checks quoted in Section IX-F | simulated | `sim/validate.py` (51 checks), log in `sim/results/validate.log` | `make sim` |
