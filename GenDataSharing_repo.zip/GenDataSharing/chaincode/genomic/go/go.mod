module github.com/tvle0101/GenDataSharing/chaincode/genomic

go 1.24

require github.com/hyperledger/fabric-contract-api-go v1.2.2

require (
	github.com/go-openapi/jsonpointer v0.20.0 // indirect
	github.com/go-openapi/jsonreference v0.20.2 // indirect
	github.com/go-openapi/spec v0.20.9 // indirect
	github.com/go-openapi/swag v0.22.4 // indirect
	github.com/gobuffalo/envy v1.10.2 // indirect
	github.com/gobuffalo/packd v1.0.2 // indirect
	github.com/gobuffalo/packr v1.30.1 // indirect
	github.com/golang/protobuf v1.5.4 // indirect
	github.com/hyperledger/fabric-chaincode-go v0.0.0-20230731094759-d626e9ab09b9
	github.com/hyperledger/fabric-protos-go v0.3.0 // indirect
	github.com/joho/godotenv v1.5.1 // indirect
	github.com/josharian/intern v1.0.0 // indirect
	github.com/mailru/easyjson v0.7.7 // indirect
	github.com/rogpeppe/go-internal v1.11.0 // indirect
	github.com/xeipuuv/gojsonpointer v0.0.0-20190905194746-02993c407bfb // indirect
	github.com/xeipuuv/gojsonreference v0.0.0-20180127040603-bd5ef7bd5415 // indirect
	github.com/xeipuuv/gojsonschema v1.2.0 // indirect
	golang.org/x/crypto v0.37.0 // indirect
	golang.org/x/mod v0.17.0 // indirect
	golang.org/x/net v0.32.0 // indirect
	golang.org/x/sys v0.32.0 // indirect
	golang.org/x/text v0.24.0 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20241202173237-19429a94021a // indirect
	google.golang.org/grpc v1.59.0 // indirect
	google.golang.org/protobuf v1.36.5
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

replace (
	go.uber.org/multierr => github.com/uber-go/multierr v1.11.0
	go.uber.org/zap => github.com/uber-go/zap v1.27.0
	golang.org/x/crypto => github.com/golang/crypto v0.37.0
	golang.org/x/exp => github.com/golang/exp v0.0.0-20240119083558-1b970713d09a
	golang.org/x/mod => github.com/golang/mod v0.17.0
	golang.org/x/net => github.com/golang/net v0.39.0
	golang.org/x/oauth2 => github.com/golang/oauth2 v0.27.0
	golang.org/x/sync => github.com/golang/sync v0.13.0
	golang.org/x/sys => github.com/golang/sys v0.32.0
	golang.org/x/telemetry => github.com/golang/telemetry v0.0.0-20240228155512-f48c80bd79b2
	golang.org/x/term => github.com/golang/term v0.31.0
	golang.org/x/text => github.com/golang/text v0.24.0
	golang.org/x/time => github.com/golang/time v0.11.0
	golang.org/x/tools => github.com/golang/tools v0.21.1-0.20240508182429-e35e4ccd0d2d
	golang.org/x/xerrors => github.com/golang/xerrors v0.0.0-20191204190536-9bdfabe68543
	google.golang.org/genproto/googleapis/rpc => github.com/googleapis/go-genproto/googleapis/rpc v0.0.0-20250224174004-546df14abb99
	google.golang.org/grpc => github.com/grpc/grpc-go v1.70.0
	google.golang.org/protobuf => github.com/protocolbuffers/protobuf-go v1.36.5
	gopkg.in/check.v1 => github.com/go-check/check v0.0.0-20201130134442-10cb98267c6c
	gopkg.in/errgo.v2 => github.com/go-errgo/errgo v0.0.0-20180823071505-f768c5ab0476
	gopkg.in/yaml.v2 => github.com/go-yaml/yaml v0.0.0-20201117154620-7649d4548cb5
	gopkg.in/yaml.v3 => github.com/go-yaml/yaml v0.0.0-20220527083530-f6f7691b1fde
)

require github.com/cloudflare/circl v1.6.1 // indirect

require github.com/tvle0101/GenDataSharing/cryptobench v0.0.0

replace github.com/tvle0101/GenDataSharing/cryptobench => ../../../cryptobench
