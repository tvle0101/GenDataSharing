// Package main implements the Genomic Sequencing Contract (GSC) and the
// Data Sharing Contract (DSC) of the manuscript as Hyperledger Fabric
// chaincode (fabric-contract-api-go).
//
// SeqPriVer / SeqTxnFin / ShaPriVer / ShaTxnFin execute the cryptographic
// checks of Section V on-chain: the ECDSA wrapper signature is verified under
// the supplied public key and the BLS-style pairing equation
// e(H, sigma_1) == e(sigma_2, g) is evaluated on BLS12-381 (package
// cryptobench).  Timestamps come from the transaction proposal
// (GetTxTimestamp), never from the system clock, so that every endorsing peer
// produces an identical read/write set.  Duplicate record identifiers are
// rejected, so a retried submission cannot create a second record.  Function
// and field names follow the paper (sigma_b1, sigma_b2, sigma_d2, ...).
//
// Public keys are passed as hex-encoded uncompressed P-256 points.  In the
// deployed system they would be looked up from the CA's registry; passing
// them explicitly keeps the benchmark self-contained and costs one argument.
package main

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"time"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"

	cb "github.com/tvle0101/GenDataSharing/cryptobench"
)

// ============================================================
//  Ledger records
// ============================================================

// SeqRecord is a genomic sequencing transaction record (Blk_s subset).
type SeqRecord struct {
	RecordID       string `json:"recordID"`
	DataOwnerID    string `json:"dataOwnerID"`
	GCsID          string `json:"gcsID"`
	AlphaK         string `json:"alphaK"`
	SigmaB1        string `json:"sigmaB1"`        // hex, G1
	SigmaB2        string `json:"sigmaB2"`        // hex, G2 (aggregate of sigma_a2 and GC share)
	SigmaSeqPriAcc string `json:"sigmaSeqPriAcc"` // hex, ECDSA by DO
	SigmaSeqPriCfm string `json:"sigmaSeqPriCfm"` // hex, ECDSA by GC
	PukGC          string `json:"pukGC"`          // hex, P-256
	MACDO          string `json:"macDO"`
	MACGC          string `json:"macGC"`
	TSeqPriCfm     string `json:"tSeqPriCfm"`
	SigmaD1        string `json:"sigmaD1,omitempty"`
	SigmaD2        string `json:"sigmaD2,omitempty"`
	SigmaConfS     string `json:"sigmaConfS,omitempty"`
	ConfS          string `json:"confS,omitempty"`
	TxTimestamp    string `json:"txTimestamp"` // from the transaction proposal
	Status         string `json:"status"`      // PENDING | COMPLETED
	AmountPaid     string `json:"amountPaid,omitempty"`
}

// ShareRecord is a genomic data sharing transaction record (Blk_t subset).
type ShareRecord struct {
	RecordID       string `json:"recordID"`
	DataOwnerID    string `json:"dataOwnerID"`
	DataBuyerID    string `json:"dataBuyerID"`
	GCsID          string `json:"gcsID"`
	DeltaK         string `json:"deltaK"`
	SigmaF1        string `json:"sigmaF1"`
	SigmaF2        string `json:"sigmaF2"`
	SigmaShaPriSet string `json:"sigmaShaPriSet"`
	SigmaShaPriAcc string `json:"sigmaShaPriAcc"`
	PukDB          string `json:"pukDB"`
	MACDO          string `json:"macDO"`
	MACDB          string `json:"macDB"`
	TShaPriAcc     string `json:"tShaPriAcc"`
	SigmaW1        string `json:"sigmaW1,omitempty"`
	SigmaW2        string `json:"sigmaW2,omitempty"`
	SigmaConfT     string `json:"sigmaConfT,omitempty"`
	ConfT          string `json:"confT,omitempty"`
	TxTimestamp    string `json:"txTimestamp"`
	Status         string `json:"status"`
	AmountPaid     string `json:"amountPaid,omitempty"`
}

// ============================================================
//  helpers
// ============================================================

func txTime(ctx contractapi.TransactionContextInterface) (string, error) {
	ts, err := ctx.GetStub().GetTxTimestamp()
	if err != nil {
		return "", fmt.Errorf("transaction timestamp unavailable: %w", err)
	}
	return time.Unix(ts.Seconds, int64(ts.Nanos)).UTC().Format(time.RFC3339Nano), nil
}

func hexBytes(name, s string) ([]byte, error) {
	b, err := hex.DecodeString(s)
	if err != nil || len(b) == 0 {
		return nil, fmt.Errorf("%s: invalid hex encoding", name)
	}
	return b, nil
}

// parseSigmaB decodes the on-wire form of sigma_B (and sigma_F, which has
// the same structure) and the verifying public key.
func parseSigmaB(alphaK, s1Hex, s2Hex, wrapInnerHex, wrapOuterHex, mac, t, pukHex string) (*cb.SigmaB, error) {
	s1, err := hexBytes("sigma_1", s1Hex)
	if err != nil {
		return nil, err
	}
	s2, err := hexBytes("sigma_2", s2Hex)
	if err != nil {
		return nil, err
	}
	sig, err := cb.ParseAggSig(s1, s2)
	if err != nil {
		return nil, fmt.Errorf("aggregate signature: %w", err)
	}
	inner, err := hexBytes("inner ECDSA signature", wrapInnerHex)
	if err != nil {
		return nil, err
	}
	outer, err := hexBytes("outer ECDSA signature", wrapOuterHex)
	if err != nil {
		return nil, err
	}
	_ = pukHex
	return &cb.SigmaB{AlphaK: []byte(alphaK), Sig: sig, SigmaSeqPriAcc: inner, SigmaSeqPriCfm: outer, MACGC: mac, TSeqPriCfm: t}, nil
}

func parseSigmaD(confS, s1Hex, s2Hex, wrapHex, mac, t string) (*cb.SigmaD, error) {
	s1, err := hexBytes("sigma_1", s1Hex)
	if err != nil {
		return nil, err
	}
	s2, err := hexBytes("sigma_2", s2Hex)
	if err != nil {
		return nil, err
	}
	sig, err := cb.ParseAggSig(s1, s2)
	if err != nil {
		return nil, fmt.Errorf("aggregate signature: %w", err)
	}
	wrap, err := hexBytes("confirmation ECDSA signature", wrapHex)
	if err != nil {
		return nil, err
	}
	return &cb.SigmaD{ConfS: []byte(confS), Sig: sig, SigmaConfS: wrap, MACDO: mac, TConfS: t}, nil
}

func putJSON(ctx contractapi.TransactionContextInterface, key string, v interface{}) error {
	b, err := json.Marshal(v)
	if err != nil {
		return fmt.Errorf("marshal: %w", err)
	}
	return ctx.GetStub().PutState(key, b)
}

// ============================================================
//  Genomic Sequencing Contract (GSC)
// ============================================================

// GSContract implements the GSC.
type GSContract struct {
	contractapi.Contract
}

// SeqPriVer (Section V-B): verifies sigma_SeqPriCfm under puk_GC and the
// pairing equation e(h(alpha_k), sigma_b1) == e(sigma_b2, g), then stores a
// PENDING sequencing record.
func (gsc *GSContract) SeqPriVer(ctx contractapi.TransactionContextInterface,
	recordID, dataOwnerID, gcsID, alphaK,
	sigmaB1, sigmaB2, sigmaSeqPriAcc, sigmaSeqPriCfm,
	macDO, macGC, tSeqPriCfm, pukGC string) error {

	existing, err := ctx.GetStub().GetState(recordID)
	if err != nil {
		return fmt.Errorf("failed to read ledger: %w", err)
	}
	if existing != nil {
		return fmt.Errorf("record %s already exists", recordID)
	}

	puk, err := cb.ParsePubHex(pukGC)
	if err != nil {
		return fmt.Errorf("puk_GC: %w", err)
	}
	b, err := parseSigmaB(alphaK, sigmaB1, sigmaB2, sigmaSeqPriAcc, sigmaSeqPriCfm, macGC, tSeqPriCfm, pukGC)
	if err != nil {
		return fmt.Errorf("sigma_B: %w", err)
	}
	if err := cb.SeqPriVer(b, puk); err != nil { // ECDSA check + 2 pairings
		return fmt.Errorf("SeqPriVer verification failed: %w", err)
	}

	ts, err := txTime(ctx)
	if err != nil {
		return err
	}
	rec := SeqRecord{
		RecordID: recordID, DataOwnerID: dataOwnerID, GCsID: gcsID, AlphaK: alphaK,
		SigmaB1: sigmaB1, SigmaB2: sigmaB2, SigmaSeqPriAcc: sigmaSeqPriAcc, SigmaSeqPriCfm: sigmaSeqPriCfm,
		PukGC: pukGC, MACDO: macDO, MACGC: macGC, TSeqPriCfm: tSeqPriCfm,
		TxTimestamp: ts, Status: "PENDING",
	}
	return putJSON(ctx, recordID, rec)
}

// SeqTxnFin (Section V-B): verifies sigma_conf_s under puk_DO and
// e(X, sigma_d1) == e(sigma_d2, g) with X = h(conf_s || MAC_GC || t_SeqSignCrypt),
// then completes the record.  MAC_GC is taken from the stored record.
func (gsc *GSContract) SeqTxnFin(ctx contractapi.TransactionContextInterface,
	recordID, confS, sigmaD1, sigmaD2, sigmaConfS, macDO, tConfS, tSeqSignCrypt, pukDO, amountPaid string) error {

	raw, err := ctx.GetStub().GetState(recordID)
	if err != nil || raw == nil {
		return fmt.Errorf("record %s not found", recordID)
	}
	var rec SeqRecord
	if err := json.Unmarshal(raw, &rec); err != nil {
		return fmt.Errorf("unmarshal: %w", err)
	}
	if rec.Status != "PENDING" {
		return fmt.Errorf("record %s is not PENDING", recordID)
	}
	puk, err := cb.ParsePubHex(pukDO)
	if err != nil {
		return fmt.Errorf("puk_DO: %w", err)
	}
	d, err := parseSigmaD(confS, sigmaD1, sigmaD2, sigmaConfS, macDO, tConfS)
	if err != nil {
		return fmt.Errorf("sigma_D: %w", err)
	}
	if err := cb.SeqTxnFin(d, puk, rec.MACGC, tSeqSignCrypt); err != nil {
		return fmt.Errorf("SeqTxnFin verification failed: %w", err)
	}
	ts, err := txTime(ctx)
	if err != nil {
		return err
	}
	rec.ConfS, rec.SigmaD1, rec.SigmaD2, rec.SigmaConfS = confS, sigmaD1, sigmaD2, sigmaConfS
	rec.AmountPaid, rec.Status, rec.TxTimestamp = amountPaid, "COMPLETED", ts
	return putJSON(ctx, recordID, rec)
}

// QuerySeqRecord returns a sequencing record.
func (gsc *GSContract) QuerySeqRecord(ctx contractapi.TransactionContextInterface, recordID string) (*SeqRecord, error) {
	raw, err := ctx.GetStub().GetState(recordID)
	if err != nil || raw == nil {
		return nil, fmt.Errorf("record %s not found", recordID)
	}
	var rec SeqRecord
	if err := json.Unmarshal(raw, &rec); err != nil {
		return nil, err
	}
	return &rec, nil
}

// ============================================================
//  Data Sharing Contract (DSC)
// ============================================================

// DSContract implements the DSC.
type DSContract struct {
	contractapi.Contract
}

// ShaPriVer (Section V-C): verifies sigma_ShaPriAcc under puk_DB and
// e(h(delta_k), sigma_f1) == e(sigma_f2, g), then stores a PENDING sharing record.
func (dsc *DSContract) ShaPriVer(ctx contractapi.TransactionContextInterface,
	recordID, dataOwnerID, dataBuyerID, gcsID, deltaK,
	sigmaF1, sigmaF2, sigmaShaPriSet, sigmaShaPriAcc,
	macDO, macDB, tShaPriAcc, pukDB string) error {

	key := "share_" + recordID
	existing, err := ctx.GetStub().GetState(key)
	if err != nil {
		return fmt.Errorf("failed to read ledger: %w", err)
	}
	if existing != nil {
		return fmt.Errorf("share record %s already exists", recordID)
	}
	puk, err := cb.ParsePubHex(pukDB)
	if err != nil {
		return fmt.Errorf("puk_DB: %w", err)
	}
	f, err := parseSigmaB(deltaK, sigmaF1, sigmaF2, sigmaShaPriSet, sigmaShaPriAcc, macDB, tShaPriAcc, pukDB)
	if err != nil {
		return fmt.Errorf("sigma_F: %w", err)
	}
	if err := cb.ShaPriVer(f, puk); err != nil {
		return fmt.Errorf("ShaPriVer verification failed: %w", err)
	}
	ts, err := txTime(ctx)
	if err != nil {
		return err
	}
	rec := ShareRecord{
		RecordID: recordID, DataOwnerID: dataOwnerID, DataBuyerID: dataBuyerID, GCsID: gcsID, DeltaK: deltaK,
		SigmaF1: sigmaF1, SigmaF2: sigmaF2, SigmaShaPriSet: sigmaShaPriSet, SigmaShaPriAcc: sigmaShaPriAcc,
		PukDB: pukDB, MACDO: macDO, MACDB: macDB, TShaPriAcc: tShaPriAcc, TxTimestamp: ts, Status: "PENDING",
	}
	return putJSON(ctx, key, rec)
}

// ShaTxnFin (Section V-C): verifies sigma_conf_t under puk_DB and
// e(h(conf_t), sigma_w1) == e(sigma_w2, g), then completes the record.
func (dsc *DSContract) ShaTxnFin(ctx contractapi.TransactionContextInterface,
	recordID, confT, sigmaW1, sigmaW2, sigmaConfT, macDB, tConfT, pukDB, amountPaid string) error {

	key := "share_" + recordID
	raw, err := ctx.GetStub().GetState(key)
	if err != nil || raw == nil {
		return fmt.Errorf("share record %s not found", recordID)
	}
	var rec ShareRecord
	if err := json.Unmarshal(raw, &rec); err != nil {
		return fmt.Errorf("unmarshal: %w", err)
	}
	if rec.Status != "PENDING" {
		return fmt.Errorf("record %s is not PENDING", recordID)
	}
	puk, err := cb.ParsePubHex(pukDB)
	if err != nil {
		return fmt.Errorf("puk_DB: %w", err)
	}
	w, err := parseSigmaD(confT, sigmaW1, sigmaW2, sigmaConfT, macDB, tConfT)
	if err != nil {
		return fmt.Errorf("sigma_W: %w", err)
	}
	if err := cb.ShaTxnFin(w, puk); err != nil {
		return fmt.Errorf("ShaTxnFin verification failed: %w", err)
	}
	ts, err := txTime(ctx)
	if err != nil {
		return err
	}
	rec.ConfT, rec.SigmaW1, rec.SigmaW2, rec.SigmaConfT = confT, sigmaW1, sigmaW2, sigmaConfT
	rec.AmountPaid, rec.Status, rec.TxTimestamp = amountPaid, "COMPLETED", ts
	return putJSON(ctx, key, rec)
}

// QueryShareRecord returns a sharing record.
func (dsc *DSContract) QueryShareRecord(ctx contractapi.TransactionContextInterface, recordID string) (*ShareRecord, error) {
	raw, err := ctx.GetStub().GetState("share_" + recordID)
	if err != nil || raw == nil {
		return nil, fmt.Errorf("share record %s not found", recordID)
	}
	var rec ShareRecord
	if err := json.Unmarshal(raw, &rec); err != nil {
		return nil, err
	}
	return &rec, nil
}
