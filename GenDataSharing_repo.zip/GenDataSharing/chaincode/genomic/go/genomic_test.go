package main

import (
	"encoding/hex"
	"strings"
	"testing"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
	"google.golang.org/protobuf/types/known/timestamppb"

	cb "github.com/tvle0101/GenDataSharing/cryptobench"
)

// fakeStub implements only the stub methods the chaincode uses; the embedded
// interface makes any other call panic, which is what we want in a test.
type fakeStub struct {
	shim.ChaincodeStubInterface
	state map[string][]byte
}

func (f *fakeStub) GetState(k string) ([]byte, error) { return f.state[k], nil }
func (f *fakeStub) PutState(k string, v []byte) error { f.state[k] = v; return nil }
func (f *fakeStub) GetTxTimestamp() (*timestamppb.Timestamp, error) {
	return &timestamppb.Timestamp{Seconds: 1_700_000_000}, nil
}

func newCtx() (*contractapi.TransactionContext, *fakeStub) {
	st := &fakeStub{state: map[string][]byte{}}
	ctx := &contractapi.TransactionContext{}
	ctx.SetStub(st)
	return ctx, st
}

func seqArgs(t *testing.T) (do, gc *cb.SigmaB, prkDO, prkGC string, b *cb.SigmaB, pukGCHex string) {
	kDO, kGC := cb.GenerateKey(), cb.GenerateKey()
	a := cb.SeqPriAcc([]byte("alphaK:wgs,price=100"), kDO, "macDO", "t1")
	sb, err := cb.SeqPriCfm(a, &kDO.PublicKey, kGC, "macGC", "t2")
	if err != nil {
		t.Fatal(err)
	}
	return nil, nil, "", "", sb, cb.PubHex(&kGC.PublicKey)
}

func TestSeqPriVer_ValidAndTampered(t *testing.T) {
	_, _, _, _, b, pukGC := seqArgs(t)
	s1, s2 := b.Sig.Bytes()
	gsc := &GSContract{}
	ctx, st := newCtx()
	call := func(rec, alphaK, s1h, s2h, inner, outer string) error {
		return gsc.SeqPriVer(ctx, rec, "DO1", "GC1", alphaK, s1h, s2h, inner, outer, "macDO", b.MACGC, b.TSeqPriCfm, pukGC)
	}
	s1h, s2h := hex.EncodeToString(s1), hex.EncodeToString(s2)
	inner, outer := hex.EncodeToString(b.SigmaSeqPriAcc), hex.EncodeToString(b.SigmaSeqPriCfm)
	if err := call("r1", string(b.AlphaK), s1h, s2h, inner, outer); err != nil {
		t.Fatalf("valid sigma_B rejected: %v", err)
	}
	if _, ok := st.state["r1"]; !ok {
		t.Fatal("record not stored")
	}
	if !strings.Contains(string(st.state["r1"]), `"txTimestamp":"2023-11-14T22:13:20Z"`) {
		t.Fatalf("timestamp must come from the proposal, got %s", st.state["r1"])
	}
	// duplicate
	if err := call("r1", string(b.AlphaK), s1h, s2h, inner, outer); err == nil {
		t.Fatal("duplicate record accepted")
	}
	// tampered alpha_k (price raised): pairing check must fail
	if err := call("r2", "alphaK:wgs,price=999", s1h, s2h, inner, outer); err == nil || !strings.Contains(err.Error(), "pairing") {
		t.Fatalf("tampered alpha_k accepted or wrong error: %v", err)
	}
	// tampered outer ECDSA signature
	bad := []byte(b.SigmaSeqPriCfm)
	bad[5] ^= 0x01
	if err := call("r3", string(b.AlphaK), s1h, s2h, inner, hex.EncodeToString(bad)); err == nil || !strings.Contains(err.Error(), "ECDSA") && !strings.Contains(err.Error(), "verify") {
		t.Fatalf("tampered ECDSA wrapper accepted or wrong error: %v", err)
	}
	// wrong public key
	other := cb.GenerateKey()
	if err := gsc.SeqPriVer(ctx, "r4", "DO1", "GC1", string(b.AlphaK), s1h, s2h, inner, outer, "macDO", b.MACGC, b.TSeqPriCfm, cb.PubHex(&other.PublicKey)); err == nil {
		t.Fatal("wrong puk_GC accepted")
	}
	// malformed group element
	if err := call("r5", string(b.AlphaK), "00ff", s2h, inner, outer); err == nil {
		t.Fatal("malformed sigma_b1 accepted")
	}
}

func TestSeqTxnFin_RoundTrip(t *testing.T) {
	kDO, kGC := cb.GenerateKey(), cb.GenerateKey()
	a := cb.SeqPriAcc([]byte("alphaK"), kDO, "macDO", "t1")
	sb, _ := cb.SeqPriCfm(a, &kDO.PublicKey, kGC, "macGC", "t2")
	s1, s2 := sb.Sig.Bytes()
	gsc := &GSContract{}
	ctx, _ := newCtx()
	if err := gsc.SeqPriVer(ctx, "r", "DO1", "GC1", "alphaK", hex.EncodeToString(s1), hex.EncodeToString(s2),
		hex.EncodeToString(sb.SigmaSeqPriAcc), hex.EncodeToString(sb.SigmaSeqPriCfm), "macDO", "macGC", "t2", cb.PubHex(&kGC.PublicKey)); err != nil {
		t.Fatal(err)
	}
	dc := cb.SeqSignCrypt([]byte("GD"), []byte("PD"), []byte("conf_s"), kGC, &kDO.PublicKey, "macGC", "t3")
	_, _, sd, err := cb.SeqUnsignCrypt(dc, kDO, &kGC.PublicKey, "macDO", "t4")
	if err != nil {
		t.Fatal(err)
	}
	d1, d2 := sd.Sig.Bytes()
	if err := gsc.SeqTxnFin(ctx, "r", "conf_s", hex.EncodeToString(d1), hex.EncodeToString(d2), hex.EncodeToString(sd.SigmaConfS),
		"macDO", "t4", "t3", cb.PubHex(&kDO.PublicKey), "100"); err != nil {
		t.Fatalf("valid sigma_D rejected: %v", err)
	}
	rec, err := gsc.QuerySeqRecord(ctx, "r")
	if err != nil || rec.Status != "COMPLETED" {
		t.Fatalf("record not completed: %v %+v", err, rec)
	}
	// wrong conf_s must fail the pairing check
	ctx2, _ := newCtx()
	_ = gsc.SeqPriVer(ctx2, "r", "DO1", "GC1", "alphaK", hex.EncodeToString(s1), hex.EncodeToString(s2),
		hex.EncodeToString(sb.SigmaSeqPriAcc), hex.EncodeToString(sb.SigmaSeqPriCfm), "macDO", "macGC", "t2", cb.PubHex(&kGC.PublicKey))
	if err := gsc.SeqTxnFin(ctx2, "r", "conf_X", hex.EncodeToString(d1), hex.EncodeToString(d2), hex.EncodeToString(sd.SigmaConfS),
		"macDO", "t4", "t3", cb.PubHex(&kDO.PublicKey), "100"); err == nil {
		t.Fatal("tampered conf_s accepted")
	}
}

func TestShaPriVer_And_ShaTxnFin(t *testing.T) {
	kDO, kDB := cb.GenerateKey(), cb.GenerateKey()
	e := cb.ShaPriSet([]byte("deltaK"), kDO, "macDO", "t1")
	f, err := cb.ShaPriAcc(e, &kDO.PublicKey, kDB, "macDB", "t2")
	if err != nil {
		t.Fatal(err)
	}
	f1, f2 := f.Sig.Bytes()
	dsc := &DSContract{}
	ctx, _ := newCtx()
	if err := dsc.ShaPriVer(ctx, "s", "DO1", "DB1", "GC1", "deltaK", hex.EncodeToString(f1), hex.EncodeToString(f2),
		hex.EncodeToString(f.SigmaSeqPriAcc), hex.EncodeToString(f.SigmaSeqPriCfm), "macDO", "macDB", "t2", cb.PubHex(&kDB.PublicKey)); err != nil {
		t.Fatalf("valid sigma_F rejected: %v", err)
	}
	dr := cb.ShaSignCrypt([]byte("GD"), []byte("conf_t"), kDO, &kDB.PublicKey, "macDO", "t3")
	_, sw, err := cb.ShaUnsignCrypt(dr, kDB, &kDO.PublicKey, "macDB", "t4")
	if err != nil {
		t.Fatal(err)
	}
	w1, w2 := sw.Sig.Bytes()
	if err := dsc.ShaTxnFin(ctx, "s", "conf_t", hex.EncodeToString(w1), hex.EncodeToString(w2), hex.EncodeToString(sw.SigmaConfS),
		"macDB", "t4", cb.PubHex(&kDB.PublicKey), "50"); err != nil {
		t.Fatalf("valid sigma_W rejected: %v", err)
	}
	rec, _ := dsc.QueryShareRecord(ctx, "s")
	if rec.Status != "COMPLETED" {
		t.Fatal("share record not completed")
	}
}
