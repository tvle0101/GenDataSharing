package main

import (
	"fmt"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

func main() {
	chaincode, err := contractapi.NewChaincode(&GSContract{}, &DSContract{})
	if err != nil {
		panic(fmt.Sprintf("error creating genomic chaincode: %v", err))
	}
	if err := chaincode.Start(); err != nil {
		panic(fmt.Sprintf("error starting genomic chaincode: %v", err))
	}
}
