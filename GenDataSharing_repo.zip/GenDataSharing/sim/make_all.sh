#!/usr/bin/env bash
# Regenerates every number, table and figure used in the reliability / fault-tolerance sections.
# Usage:  bash make_all.sh            (defaults: 30 cycles per condition, seed 20261027)
#         TRIALS=10 bash make_all.sh  (quicker smoke run)
set -euo pipefail
SIM="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TRIALS="${TRIALS:-30}"
SEED="${SEED:-20261027}"
mkdir -p "$SIM/results" "$SIM/tables" "$SIM/figures"
echo "== analytic availability model"
python3 "$SIM/analytic_availability.py" --outdir "$SIM"
echo "== discrete-event fault simulation (T=$TRIALS cycles/condition)"
python3 "$SIM/fabric_fault_sim.py" --outdir "$SIM" --trials "$TRIALS" --seed "$SEED" | tee "$SIM/results/fabric_run.log"
echo "== trust-score simulation"
python3 "$SIM/trust_sim.py" --outdir "$SIM" --trials "$TRIALS" --seed "$SEED" | tee "$SIM/results/trust_run.log"
echo "== validation"
python3 "$SIM/validate.py" | tee "$SIM/results/validate.log"
echo "done: tables in $SIM/tables, figures in $SIM/figures, raw results in $SIM/results"
