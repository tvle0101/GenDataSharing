#!/usr/bin/env python3
"""
fabric_fault_sim.py -- discrete-event simulation (own heapq event loop, no simpy) of a
Hyperledger Fabric-style consortium with a Raft ordering service, used to produce the
node-failure / link-failure / failure-recovery tables of the manuscript.

Model summary (see README.md and METHODS.tex for the full description)
---------------------------------------------------------------------
* N consortium nodes (genomic companies). Node i hosts ONE Raft orderer and ONE endorsing
  peer. A node crash takes down both (host-level, common-cause for that node).
* Raft (etcd/raft semantics, simplified but with terms, votes, log matching, majority
  commit, election restriction): TickInterval 0.5 s, ElectionTick 10, HeartbeatTick 1
  (Fabric v2.x defaults) => heartbeat every 0.5 s, randomised election timeout
  U[5 s, 10 s). A --election-scale factor rescales both bounds (e.g. 0.03 => 150-300 ms).
* Block cutting at the leader: MaxMessageCount (default 10) or BatchTimeout (default 2 s).
* Clients (one per submitting organisation) run: endorse (k-of-f over f peers of distinct
  nodes: the serving GC's peer plus f-1 counterparty peers) -> submit envelope to an orderer
  (own org's first, then others round-robin; followers forward to the leader) -> wait for
  commit notification from any endorsing peer.  Attempt timeout T_out (default 10 s),
  up to r retries (default 3) with exponential back-off b*2^i (b = 0.5 s) + jitter.
* Failure injection:  --crash-ratio  (fraction of nodes crashed at a common random time
  t_f ~ U[0.2,0.8]*T_arrival in 'burst' mode; independent times in 'staggered' mode),
  --leader-eligible / --non-leader-only;  crashed nodes restart after --mttr (30 s).
  --link-ratio p: 'random' mode drops every message independently with prob p;
  'persistent' mode disables each directed link for the whole cycle with prob p.
* Metrics per cycle: P_succ (any attempt committed before the request is given up and
  before cycle end), first-attempt success, mean retries, latency, T_rec (commit time of
  the first request submitted after t_f that eventually commits minus t_f; right-censored
  if no such commit before cycle end), infrastructure component (time from t_f until a
  leader exists), retry component (time the T_rec request spent in failed attempts and
  back-off), number of elections, late/duplicate commits.
* T independent cycles per condition (default 30), seed = base_seed + 1000*cond_idx + cycle.
  Reported: mean +- std over cycles, Wilson 95% CI on pooled P_succ.
"""
import argparse
import csv
import hashlib
import heapq
import json
import math
import os
import random
import sys
import time
from multiprocessing import Pool

# --------------------------------------------------------------------------- defaults
DEFAULTS = dict(
    N=20, requests=1000, rate=100.0, timeout=10.0, retries=3, backoff=0.5, backoff_cap=8.0,
    endorse_timeout=2.0, submit_ack_timeout=1.5, relay_timeout=1.0, k=1, f=2,
    tick=0.5, election_tick=10, heartbeat_tick=1, election_scale=1.0,
    net_delay_ms=20.0, exec_ms=10.0, max_msg=10, batch_timeout=2.0,
    mttr=30.0, cycle_length=120.0, crash_ratio=0.0, link_ratio=0.0,
    crash_mode="burst", link_mode="random", leader_eligible=True, reselect_on_retry=False,
    p_chaincode_fail=0.0,
)

FOLLOWER, CANDIDATE, LEADER = 0, 1, 2


class Request:
    __slots__ = ("rid", "org", "endorsers", "t_arrive", "attempts", "status", "t_commit",
                 "retries", "attempt", "fail_reason", "commit_attempt", "n_commits", "retry_time")

    def __init__(self, rid, org, endorsers, t):
        self.rid = rid
        self.org = org
        self.endorsers = endorsers
        self.t_arrive = t
        self.attempts = []           # list of Attempt
        self.status = "pending"      # pending | success | failed
        self.t_commit = None
        self.retries = 0
        self.attempt = None
        self.fail_reason = None
        self.commit_attempt = None
        self.n_commits = 0           # commits observed (incl. late / duplicate)
        self.retry_time = 0.0        # time spent in failed attempts + backoff


class Attempt:
    __slots__ = ("aid", "req", "t_start", "phase", "endorsements", "orderer_idx", "order_list",
                 "deadline", "token", "committed")

    def __init__(self, aid, req, t):
        self.aid = aid
        self.req = req
        self.t_start = t
        self.phase = "endorse"
        self.endorsements = 0
        self.orderer_idx = 0
        self.order_list = None
        self.deadline = None
        self.token = 0
        self.committed = False


class Node:
    __slots__ = ("id", "alive", "state", "term", "voted_for", "log", "commit_index", "leader_id",
                 "election_deadline", "election_token", "votes", "next_index", "match_index",
                 "pending", "batch_start", "batch_token", "hb_token", "peer_height", "delivered",
                 "restart_at", "last_leader_contact", "last_ack", "prevotes", "cq_token")

    def __init__(self, i):
        self.id = i
        self.alive = True
        self.state = FOLLOWER
        self.term = 1
        self.voted_for = None
        self.log = []                 # list of (term, block) ; block = list of attempt ids
        self.commit_index = 0         # number of committed entries
        self.leader_id = None
        self.election_deadline = 0.0
        self.election_token = 0
        self.votes = set()
        self.next_index = {}
        self.match_index = {}
        self.pending = []             # leader: tx (attempt ids) waiting for block cut
        self.batch_start = None
        self.batch_token = 0
        self.hb_token = 0
        self.peer_height = 0          # peer: number of blocks delivered to this node's peer
        self.delivered = {}           # leader: node -> blocks delivered to its peer
        self.restart_at = None
        self.last_leader_contact = 0.0   # follower lease (PreVote)
        self.last_ack = {}               # leader: follower -> last AppendResp time (CheckQuorum)
        self.prevotes = set()
        self.cq_token = 0


class Sim:
    def __init__(self, p, seed):
        self.p = p
        # integer seeds that differ by small amounts give correlated Mersenne-Twister streams,
        # so the generator is keyed with a SHA-256 digest of the seed (seed itself is recorded).
        self.rng = random.Random(hashlib.sha256(f"fabric-fault-sim:{seed}".encode()).digest())
        self.seed = seed
        self.now = 0.0
        self.heap = []
        self.seq = 0
        N = p["N"]
        self.N = N
        self.nodes = [Node(i) for i in range(N)]
        self.requests = []
        self.attempts = {}
        self.pending_fwd = {}         # follower id -> {(client_org, aid): True}
        self.aid_counter = 0
        self.majority = N // 2 + 1
        tick = p["tick"] * p["election_scale"]       # TickInterval (scaled)
        self.hb_interval = tick * p["heartbeat_tick"]
        self.el_min = tick * p["election_tick"]
        self.el_max = 2 * self.el_min
        self.t_arrival_end = p["requests"] / p["rate"]
        # stats
        self.n_elections = 0
        self.leader_history = []      # (time, node, term)
        self.fault_time = None
        self.crash_set = []
        self.leader_crashed = False
        self.leader_available_from = None   # first time a leader exists after fault
        self.msgs_sent = 0
        self.msgs_dropped = 0
        self.late_commits = 0
        self.dup_commits = 0
        self.done_requests = 0
        self.finished = False
        self.end_time = None
        # link failures
        self.link_down = set()
        if p["link_mode"] == "persistent" and p["link_ratio"] > 0:
            for i in range(N):
                for j in range(N):
                    if i != j and self.rng.random() < p["link_ratio"]:
                        self.link_down.add((i, j))
                if self.rng.random() < p["link_ratio"]:
                    self.link_down.add(("c", i))      # client_i <-> node_i link (both directions)
        # initial steady state: leader elected already (random node), term 1
        leader = self.rng.randrange(N)
        L = self.nodes[leader]
        L.state = LEADER
        for n in self.nodes:
            n.leader_id = leader
            n.term = 1
        L.next_index = {i: 0 for i in range(N) if i != leader}
        L.match_index = {i: 0 for i in range(N) if i != leader}
        L.delivered = {i: 0 for i in range(N)}
        self.leader_history.append((0.0, leader, 1))
        L.last_ack = {i: 0.0 for i in range(N) if i != leader}
        L.cq_token += 1
        self.schedule(self.el_min, "cq", (leader, L.cq_token))
        self.schedule(0.0, "hb", (leader, L.hb_token))
        for n in self.nodes:
            if n.id != leader:
                self.reset_election_timer(n)
        # request arrivals (Poisson process with given rate, exactly `requests` arrivals)
        t = 0.0
        for rid in range(p["requests"]):
            t += self.rng.expovariate(p["rate"])
            self.schedule(t, "arrive", rid)
        self.t_arrival_end = t
        # failure injection
        m = int(round(p["crash_ratio"] * N))
        if m > 0:
            t_f = self.rng.uniform(0.2, 0.8) * self.t_arrival_end
            self.fault_time = t_f
            if p["leader_eligible"]:
                cand = list(range(N))
            else:
                cand = [i for i in range(N) if i != leader]
            self.crash_set = self.rng.sample(cand, min(m, len(cand)))
            for i in self.crash_set:
                tc = t_f if p["crash_mode"] == "burst" else self.rng.uniform(0.2, 0.8) * self.t_arrival_end
                self.schedule(tc, "crash", i)
            if p["crash_mode"] == "staggered":
                # fault time = first crash
                self.fault_time = min(ev[0] for ev in self.heap if ev[2] == "crash")
        elif p["link_ratio"] > 0 and p["link_mode"] == "persistent":
            self.fault_time = 0.0
        self.schedule(p["cycle_length"], "end", None)

    # ------------------------------------------------------------------ infrastructure
    def schedule(self, t, kind, data):
        self.seq += 1
        heapq.heappush(self.heap, (t, self.seq, kind, data))

    def delay(self):
        d = self.p["net_delay_ms"] / 1000.0
        return self.rng.uniform(0.5 * d, 1.5 * d)

    CLIENT_MSGS = frozenset(("Propose", "Submit", "Endorse", "SubmitResp", "DeliverCommit"))

    def send(self, src, dst, msg):
        """src/dst are node ids. The client application of organisation i is a separate host that
        talks to node i over a (lossy) link as well, so every client message is subject to loss;
        only node-internal deliveries (src == dst, non-client) are loss-free."""
        self.msgs_sent += 1
        client = msg[0] in self.CLIENT_MSGS
        if src != dst or client:
            p = self.p
            if p["link_mode"] == "random" and p["link_ratio"] > 0 and self.rng.random() < p["link_ratio"]:
                self.msgs_dropped += 1
                return
            if self.link_down:
                key = (src, dst) if src != dst else ("c", src)
                if key in self.link_down:
                    self.msgs_dropped += 1
                    return
            self.schedule(self.now + self.delay(), "msg", (dst, msg))
        else:
            self.schedule(self.now + 1e-4, "msg", (dst, msg))

    def reset_election_timer(self, n):
        n.election_token += 1
        n.election_deadline = self.now + self.rng.uniform(self.el_min, self.el_max)
        self.schedule(n.election_deadline, "elec", (n.id, n.election_token))

    # ------------------------------------------------------------------ Raft
    def become_follower(self, n, term, leader_id=None):
        if n.state == LEADER:
            n.hb_token += 1
            n.cq_token += 1
            n.pending = []
            n.batch_start = None
        n.state = FOLLOWER
        n.prevotes = set()
        n.term = term
        n.voted_for = None
        n.leader_id = leader_id
        self.reset_election_timer(n)

    def start_prevote(self, n):
        """etcd/raft PreVote (enabled in Fabric's etcdraft): probe for a majority before bumping the term."""
        n.state = FOLLOWER if n.state != CANDIDATE else CANDIDATE
        n.leader_id = None
        n.prevotes = {n.id}
        last_term = n.log[-1][0] if n.log else 0
        for j in range(self.N):
            if j != n.id:
                self.send(n.id, j, ("PreVote", n.id, n.term + 1, len(n.log), last_term))
        self.reset_election_timer(n)
        if self.N == 1:
            self.start_election(n)

    def start_election(self, n):
        n.state = CANDIDATE
        n.term += 1
        n.voted_for = n.id
        n.votes = {n.id}
        n.leader_id = None
        n.prevotes = set()
        self.n_elections += 1
        last_term = n.log[-1][0] if n.log else 0
        for j in range(self.N):
            if j != n.id:
                self.send(n.id, j, ("RequestVote", n.id, n.term, len(n.log), last_term))
        self.reset_election_timer(n)
        if self.N == 1:
            self.become_leader(n)

    def check_quorum(self, n):
        """etcd/raft CheckQuorum: a leader that has not heard from a majority within one election
        timeout steps down (avoids a partitioned leader accepting transactions it cannot commit)."""
        if not n.alive or n.state != LEADER:
            return
        heard = 1 + sum(1 for j, t in n.last_ack.items() if self.now - t < self.el_min)
        if heard < self.majority:
            self.become_follower(n, n.term, None)
            return
        n.cq_token += 1
        self.schedule(self.now + self.el_min, "cq", (n.id, n.cq_token))

    def become_leader(self, n):
        n.state = LEADER
        n.leader_id = n.id
        n.next_index = {i: len(n.log) for i in range(self.N) if i != n.id}
        n.match_index = {i: 0 for i in range(self.N) if i != n.id}
        n.delivered = {i: 0 for i in range(self.N)}
        n.delivered[n.id] = self.nodes[n.id].peer_height
        n.last_ack = {i: self.now for i in range(self.N) if i != n.id}
        n.pending = []
        n.batch_start = None
        n.election_token += 1   # cancel timer
        n.cq_token += 1
        self.schedule(self.now + self.el_min, "cq", (n.id, n.cq_token))
        self.leader_history.append((self.now, n.id, n.term))
        if self.fault_time is not None and self.now >= self.fault_time and self.leader_available_from is None:
            self.leader_available_from = self.now
        n.hb_token += 1
        self.schedule(self.now, "hb", (n.id, n.hb_token))

    def heartbeat(self, n, tok):
        """Leader: send AppendEntries (with any missing entries) + block deliveries to everyone."""
        if not n.alive or n.state != LEADER or tok != n.hb_token:
            return
        for j in range(self.N):
            if j == n.id:
                continue
            self.send_append(n, j)
            # block delivery (peer pull, re-delivered until acked implicitly via height)
            if n.delivered[j] < n.commit_index:
                blocks = [b for (_, b) in n.log[n.delivered[j]:n.commit_index]]
                self.send(n.id, j, ("Deliver", n.id, n.delivered[j], blocks))
        self.schedule(self.now + self.hb_interval, "hb", (n.id, n.hb_token))

    def send_append(self, n, j):
        ni = n.next_index[j]
        prev_term = n.log[ni - 1][0] if ni > 0 else 0
        entries = n.log[ni:]
        self.send(n.id, j, ("AppendEntries", n.id, n.term, ni, prev_term, entries, n.commit_index))

    def on_msg(self, nid, msg):
        n = self.nodes[nid]
        t = msg[0]
        # client-bound messages: the client application of organisation `nid` is a separate
        # process (Fabric SDK/gateway client) and does not crash with the node's peer/orderer.
        if t == "Endorse":
            self.client_on_endorse(msg[2], msg[1])
            return
        if t == "SubmitResp":
            self.client_on_submit_resp(msg[2], msg[3])
            return
        if t == "DeliverCommit":
            self.client_on_commit(msg[2])
            return
        if not n.alive:
            if t == "Forward":   # connection refused by a dead leader -> relay fails fast
                self.send(nid, msg[1], ("ForwardAck", nid, msg[2], msg[3], False))
            return
        if t == "PreVote":
            _, cid, term, c_loglen, c_lastterm = msg
            my_last = n.log[-1][0] if n.log else 0
            up_to_date = (c_lastterm > my_last) or (c_lastterm == my_last and c_loglen >= len(n.log))
            lease_expired = (n.leader_id is None) or (self.now - n.last_leader_contact >= self.el_min)
            grant = (term >= n.term) and up_to_date and n.state != LEADER and lease_expired
            self.send(nid, cid, ("PreVoteResp", nid, term, grant))
        elif t == "PreVoteResp":
            _, vid, term, grant = msg
            if grant and n.state != LEADER and n.prevotes and term == n.term + 1:
                n.prevotes.add(vid)
                if len(n.prevotes) >= self.majority:
                    self.start_election(n)
        elif t == "RequestVote":
            _, cid, term, c_loglen, c_lastterm = msg
            if term > n.term:
                self.become_follower(n, term)
            grant = False
            if term == n.term and n.state != LEADER and n.voted_for in (None, cid):
                my_last = n.log[-1][0] if n.log else 0
                up_to_date = (c_lastterm > my_last) or (c_lastterm == my_last and c_loglen >= len(n.log))
                if up_to_date:
                    grant = True
                    n.voted_for = cid
                    self.reset_election_timer(n)
            self.send(nid, cid, ("Vote", nid, n.term, grant))
        elif t == "Vote":
            _, vid, term, grant = msg
            if term > n.term:
                self.become_follower(n, term)
                return
            if n.state == CANDIDATE and term == n.term and grant:
                n.votes.add(vid)
                if len(n.votes) >= self.majority:
                    self.become_leader(n)
        elif t == "AppendEntries":
            _, lid, term, prev_idx, prev_term, entries, leader_commit = msg
            if term > n.term or (term == n.term and n.state != FOLLOWER):
                self.become_follower(n, term, lid)
            if term < n.term:
                self.send(nid, lid, ("AppendResp", nid, n.term, False, len(n.log)))
                return
            n.leader_id = lid
            n.last_leader_contact = self.now
            n.prevotes = set()
            self.reset_election_timer(n)
            ok = prev_idx == 0 or (len(n.log) >= prev_idx and n.log[prev_idx - 1][0] == prev_term)
            if ok:
                # log matching: truncate conflicts and append
                if entries:
                    for idx, e in enumerate(entries):
                        pos = prev_idx + idx
                        if pos < len(n.log):
                            if n.log[pos][0] != e[0]:
                                del n.log[pos:]
                                n.log.append(e)
                        else:
                            n.log.append(e)
                matched = prev_idx + len(entries)
                n.commit_index = max(n.commit_index, min(leader_commit, matched))
                self.send(nid, lid, ("AppendResp", nid, n.term, True, matched))
            else:
                self.send(nid, lid, ("AppendResp", nid, n.term, False, len(n.log)))
        elif t == "AppendResp":
            _, fid, term, ok, flen = msg
            if term > n.term:
                self.become_follower(n, term)
                return
            if n.state != LEADER:
                return
            n.last_ack[fid] = self.now
            if ok:
                if flen > n.match_index[fid]:
                    n.match_index[fid] = flen
                n.next_index[fid] = max(n.next_index[fid], flen)
                self.advance_commit(n)
            else:
                n.next_index[fid] = min(flen, max(0, n.next_index[fid] - 1))
                self.send_append(n, fid)
        elif t == "Deliver":
            _, lid, start, blocks = msg
            if start <= n.peer_height:
                for b in blocks[n.peer_height - start:]:
                    n.peer_height += 1
                    self.peer_commit_block(n, b)
        elif t == "Propose":
            _, client_org, aid = msg
            # endorsing peer executes chaincode and returns endorsement (simulate exec delay)
            self.schedule(self.now + self.rng.uniform(0.5, 1.5) * self.p["exec_ms"] / 1000.0,
                          "endorse_done", (nid, client_org, aid))
        elif t == "Submit":
            _, client_org, aid = msg
            self.orderer_on_submit(n, client_org, aid)
        elif t == "Forward":
            _, fwd, client_org, aid = msg
            if n.state == LEADER:
                self.leader_accept(n, aid)
                self.send(nid, fwd, ("ForwardAck", nid, client_org, aid, True))
            else:
                self.send(nid, fwd, ("ForwardAck", nid, client_org, aid, False))
        elif t == "ForwardAck":
            _, lid, client_org, aid, ok = msg
            key = (client_org, aid)
            if key in self.pending_fwd.get(nid, {}):
                del self.pending_fwd[nid][key]
                self.send(nid, client_org, ("SubmitResp", nid, aid, ok))

    def advance_commit(self, n):
        # highest index replicated on a majority with entry term == current term
        for idx in range(len(n.log), n.commit_index, -1):
            if n.log[idx - 1][0] != n.term:
                break
            cnt = 1 + sum(1 for v in n.match_index.values() if v >= idx)
            if cnt >= self.majority:
                old = n.commit_index
                n.commit_index = idx
                # leader's own peer receives committed blocks immediately
                for (_, b) in n.log[old:idx]:
                    self.nodes[n.id].peer_height += 1
                    self.peer_commit_block(self.nodes[n.id], b)
                n.delivered[n.id] = n.commit_index
                # push to peers now (also re-pushed on heartbeat if lost)
                for j in range(self.N):
                    if j != n.id:
                        blocks = [b for (_, b) in n.log[n.delivered[j]:idx]]
                        self.send(n.id, j, ("Deliver", n.id, n.delivered[j], blocks))
                break

    def peer_commit_block(self, n, block):
        # peer validates block; notifies the clients whose transactions it endorsed/listens for
        for aid in block:
            a = self.attempts.get(aid)
            if a is None:
                continue
            if n.id in a.req.endorsers:
                self.send(n.id, a.req.org, ("DeliverCommit", n.id, aid))

    # ------------------------------------------------------------------ ordering service
    def orderer_on_submit(self, n, client_org, aid):
        if n.state == LEADER:
            self.leader_accept(n, aid)
            self.send(n.id, client_org, ("SubmitResp", n.id, aid, True))
        elif n.leader_id is not None and n.state == FOLLOWER:
            # synchronous relay to the leader (Fabric etcdraft follower forwards Submit); the client
            # is answered only when the leader acknowledges, else SERVICE_UNAVAILABLE after relay timeout
            self.pending_fwd.setdefault(n.id, {})[(client_org, aid)] = True
            self.send(n.id, n.leader_id, ("Forward", n.id, client_org, aid))
            self.schedule(self.now + self.p["relay_timeout"], "fwd_timeout", (n.id, client_org, aid))
        else:
            self.send(n.id, client_org, ("SubmitResp", n.id, aid, False))

    def leader_accept(self, n, aid):
        if self.p["p_chaincode_fail"] > 0 and self.rng.random() < self.p["p_chaincode_fail"]:
            return  # validation failure: tx marked invalid (never commits)
        n.pending.append(aid)
        if n.batch_start is None:
            n.batch_start = self.now
            n.batch_token += 1
            self.schedule(self.now + self.p["batch_timeout"], "batch", (n.id, n.batch_token))
        if len(n.pending) >= self.p["max_msg"]:
            self.cut_block(n)

    def cut_block(self, n):
        if not n.pending or n.state != LEADER or not n.alive:
            return
        block = n.pending
        n.pending = []
        n.batch_start = None
        n.batch_token += 1
        n.log.append((n.term, block))
        for j in range(self.N):
            if j != n.id:
                self.send_append(n, j)
        if self.N == 1:
            self.advance_commit(n)

    # ------------------------------------------------------------------ client
    def new_attempt(self, req):
        self.aid_counter += 1
        a = Attempt(self.aid_counter, req, self.now)
        self.attempts[a.aid] = a
        req.attempts.append(a)
        req.attempt = a
        a.token += 1
        self.schedule(self.now + self.p["endorse_timeout"], "ctimer", (a.aid, a.token, "endorse"))
        for pid in req.endorsers:
            self.send(req.org, pid, ("Propose", req.org, a.aid))

    def client_on_endorse(self, aid, pid):
        a = self.attempts[aid]
        if a.phase != "endorse":
            return
        a.endorsements += 1
        if a.endorsements >= self.p["k"]:
            a.phase = "submit"
            a.deadline = a.t_start + self.p["timeout"]
            others = [i for i in range(self.N) if i != a.req.org]
            self.rng.shuffle(others)
            a.order_list = [a.req.org] + others
            a.orderer_idx = 0
            self.submit_to_next(a)

    def submit_to_next(self, a):
        if a.phase != "submit":
            return
        if self.now >= a.deadline:
            self.attempt_failed(a, "timeout")
            return
        oid = a.order_list[a.orderer_idx % len(a.order_list)]
        a.orderer_idx += 1
        self.send(a.req.org, oid, ("Submit", a.req.org, a.aid))
        a.token += 1
        self.schedule(min(self.now + self.p["submit_ack_timeout"], a.deadline), "ctimer", (a.aid, a.token, "ack"))

    def client_on_submit_resp(self, aid, accepted):
        a = self.attempts[aid]
        if a.phase != "submit":
            return
        if accepted:
            a.phase = "wait_commit"
            a.token += 1
            self.schedule(a.deadline, "ctimer", (a.aid, a.token, "commit"))
        else:
            # orderer has no leader: try the next orderer after a short pause
            a.token += 1
            self.schedule(min(self.now + 0.5, a.deadline), "ctimer", (a.aid, a.token, "ack"))

    def client_on_commit(self, aid):
        a = self.attempts[aid]
        if a.committed:
            return
        a.committed = True
        req = a.req
        req.n_commits += 1
        if req.status == "success":
            self.dup_commits += 1
            return
        if req.status == "failed":
            self.late_commits += 1
            return
        req.status = "success"
        req.t_commit = self.now
        req.commit_attempt = a.aid
        if req.attempt is not a:
            # an earlier (timed-out) attempt committed while a later one is in flight
            pass
        req.attempt.token += 1  # cancel pending timers of the active attempt
        self.request_done(req)

    def attempt_failed(self, a, reason):
        req = a.req
        if req.status != "pending" or req.attempt is not a:
            return
        a.phase = "failed"
        req.retry_time += self.now - a.t_start
        if req.retries < self.p["retries"]:
            req.retries += 1
            back = min(self.p["backoff"] * (2 ** (req.retries - 1)), self.p["backoff_cap"])
            back *= self.rng.uniform(0.8, 1.2)
            req.retry_time += back
            if self.p["reselect_on_retry"]:
                req.endorsers = self.pick_endorsers(req.org)
            self.schedule(self.now + back, "retry", req.rid)
        else:
            req.status = "failed"
            req.fail_reason = reason
            self.request_done(req)

    def request_done(self, req):
        self.done_requests += 1
        if self.done_requests >= self.p["requests"]:
            self.finished = True

    def pick_endorsers(self, org):
        others = [i for i in range(self.N) if i != org]
        return [org] + self.rng.sample(others, self.p["f"] - 1)

    # ------------------------------------------------------------------ main loop
    def run(self):
        p = self.p
        heap = self.heap
        while heap:
            t, _, kind, data = heapq.heappop(heap)
            self.now = t
            if kind == "msg":
                self.on_msg(data[0], data[1])
            elif kind == "hb":
                self.heartbeat(self.nodes[data[0]], data[1])
            elif kind == "elec":
                nid, tok = data
                n = self.nodes[nid]
                if n.alive and tok == n.election_token and n.state != LEADER:
                    self.start_prevote(n)
            elif kind == "batch":
                nid, tok = data
                n = self.nodes[nid]
                if tok == n.batch_token:
                    self.cut_block(n)
            elif kind == "fwd_timeout":
                nid, client_org, aid = data
                if (client_org, aid) in self.pending_fwd.get(nid, {}):
                    del self.pending_fwd[nid][(client_org, aid)]
                    if self.nodes[nid].alive:
                        self.send(nid, client_org, ("SubmitResp", nid, aid, False))
            elif kind == "cq":
                nid, tok = data
                n = self.nodes[nid]
                if tok == n.cq_token:
                    self.check_quorum(n)
            elif kind == "arrive":
                rid = data
                org = self.rng.randrange(self.N)
                req = Request(rid, org, self.pick_endorsers(org), t)
                self.requests.append(req)
                self.new_attempt(req)
            elif kind == "retry":
                req = self.requests[data]
                if req.status == "pending":
                    self.new_attempt(req)
            elif kind == "ctimer":
                aid, tok, what = data
                a = self.attempts[aid]
                if tok != a.token or a.req.status != "pending":
                    continue
                if what == "endorse":
                    if a.phase == "endorse":
                        self.attempt_failed(a, "endorsement")
                elif what == "ack":
                    if a.phase == "submit":
                        self.submit_to_next(a)
                elif what == "commit":
                    if a.phase == "wait_commit":
                        self.attempt_failed(a, "timeout")
            elif kind == "endorse_done":
                pid, client_org, aid = data
                n = self.nodes[pid]
                if n.alive:
                    self.send(pid, client_org, ("Endorse", pid, aid))
            elif kind == "crash":
                n = self.nodes[data]
                if n.state == LEADER:
                    self.leader_crashed = True
                n.alive = False
                n.state = FOLLOWER
                n.leader_id = None
                n.pending = []
                n.batch_start = None
                n.election_token += 1
                n.hb_token += 1
                n.cq_token += 1
                n.prevotes = set()
                self.schedule(t + p["mttr"], "restart", data)
            elif kind == "restart":
                n = self.nodes[data]
                n.alive = True
                n.voted_for = None
                n.leader_id = None
                n.last_leader_contact = -1e9
                self.reset_election_timer(n)
            elif kind == "end":
                self.finished = True
            if self.finished:
                self.end_time = t
                break
        if self.end_time is None:
            self.end_time = self.now
        # leader availability after fault if the leader survived
        if self.fault_time is not None and self.leader_available_from is None:
            # was there a live leader at the fault time?
            live_leader = any(n.alive and n.state == LEADER for n in self.nodes)
            if not self.leader_crashed and live_leader:
                self.leader_available_from = self.fault_time
        return self.collect()

    # ------------------------------------------------------------------ metrics
    def collect(self):
        reqs = self.requests
        n_req = self.p["requests"]
        n_succ = sum(1 for r in reqs if r.status == "success")
        n_first = sum(1 for r in reqs if r.status == "success" and r.commit_attempt == r.attempts[0].aid and r.retries == 0)
        retries = [r.retries for r in reqs]
        lat = [r.t_commit - r.t_arrive for r in reqs if r.status == "success"]
        res = dict(
            seed=self.seed, n_req=n_req, n_succ=n_succ, n_fail=n_req - n_succ,
            n_unresolved=sum(1 for r in reqs if r.status == "pending") + (n_req - len(reqs)),
            p_succ=n_succ / n_req, p_first=n_first / n_req,
            mean_retries=sum(retries) / max(1, len(retries)),
            mean_latency=(sum(lat) / len(lat)) if lat else float("nan"),
            p95_latency=(sorted(lat)[int(0.95 * (len(lat) - 1))]) if lat else float("nan"),
            n_elections=self.n_elections, leader_crashed=int(self.leader_crashed),
            fault_time=self.fault_time, cycle_end=self.end_time,
            msgs_sent=self.msgs_sent, msgs_dropped=self.msgs_dropped,
            late_commits=self.late_commits, dup_commits=self.dup_commits,
            fail_reasons={},
            t_rec=float("nan"), t_rec_censored=0, t_infra=float("nan"), t_retry=float("nan"),
            t_rec_base=float("nan"),
        )
        for r in reqs:
            if r.status == "failed":
                res["fail_reasons"][r.fail_reason] = res["fail_reasons"].get(r.fail_reason, 0) + 1
        if self.fault_time is not None:
            after = [r for r in reqs if r.t_arrive >= self.fault_time]
            committed_after = [r for r in after if r.status == "success"]
            if committed_after:
                first = min(committed_after, key=lambda r: r.t_arrive)
                res["t_rec"] = first.t_commit - self.fault_time
                res["t_retry"] = first.retry_time
                last_attempt = self.attempts[first.commit_attempt]
                res["t_rec_base"] = first.t_commit - last_attempt.t_start
                res["t_rec_arrival_offset"] = first.t_arrive - self.fault_time
            else:
                res["t_rec_censored"] = 1
                res["t_rec_censor_at"] = self.end_time - self.fault_time
            if self.leader_available_from is not None:
                res["t_infra"] = self.leader_available_from - self.fault_time
            else:
                res["t_infra"] = float("nan")
                res["t_infra_censored"] = 1
        return res


# --------------------------------------------------------------------------- driver
def run_one(args):
    p, seed = args
    t0 = time.time()
    r = Sim(p, seed).run()
    r["wall"] = time.time() - t0
    return r


def wilson(k, n, z=1.959963984540054):
    if n == 0:
        return (float("nan"), float("nan"))
    ph = k / n
    den = 1 + z * z / n
    centre = (ph + z * z / (2 * n)) / den
    half = z * math.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / den
    return (centre - half, centre + half)


def mean_std(xs):
    xs = [x for x in xs if x == x]  # drop nan
    if not xs:
        return float("nan"), float("nan"), 0
    m = sum(xs) / len(xs)
    s = math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else 0.0
    return m, s, len(xs)


def percentile(xs, q):
    xs = sorted(x for x in xs if x == x)
    if not xs:
        return float("nan")
    i = (len(xs) - 1) * q
    lo, hi = int(math.floor(i)), int(math.ceil(i))
    return xs[lo] + (xs[hi] - xs[lo]) * (i - lo)


def summarise(cond, results):
    T = len(results)
    n_req = sum(r["n_req"] for r in results)
    n_succ = sum(r["n_succ"] for r in results)
    lo, hi = wilson(n_succ, n_req)
    ps = [r["p_succ"] for r in results]
    pm, psd, _ = mean_std(ps)
    pf, pfsd, _ = mean_std([r["p_first"] for r in results])
    rm, rsd, _ = mean_std([r["mean_retries"] for r in results])
    lm, lsd, _ = mean_std([r["mean_latency"] for r in results])
    trec = [r["t_rec"] for r in results]
    trm, trsd, ntr = mean_std(trec)
    tim, tisd, _ = mean_std([r["t_infra"] for r in results])
    tretm, tretsd, _ = mean_std([r["t_retry"] for r in results])
    tbm, _, _ = mean_std([r["t_rec_base"] for r in results])
    trlc_m, trlc_s, trlc_n = mean_std([r["t_rec"] for r in results if r["leader_crashed"]])
    trls_m, trls_s, trls_n = mean_std([r["t_rec"] for r in results if not r["leader_crashed"]])
    reasons = {}
    for r in results:
        for k, v in r["fail_reasons"].items():
            reasons[k] = reasons.get(k, 0) + v
    return dict(
        **cond, trials=T, n_req=n_req, n_succ=n_succ, commits_per_1000=n_succ / T,
        p_succ=n_succ / n_req, p_succ_cycle_mean=pm, p_succ_cycle_std=psd,
        wilson_lo=lo, wilson_hi=hi, p_first=pf, p_first_std=pfsd, lambda_tx=1 - n_succ / n_req,
        mean_retries=rm, mean_retries_std=rsd, mean_latency=lm, mean_latency_std=lsd,
        t_rec_mean=trm, t_rec_std=trsd, t_rec_median=percentile(trec, 0.5), t_rec_p95=percentile(trec, 0.95),
        t_rec_n=ntr, t_rec_censored=sum(r["t_rec_censored"] for r in results),
        t_infra_mean=tim, t_infra_std=tisd, t_retry_mean=tretm, t_retry_std=tretsd, t_base_mean=tbm,
        t_rec_leader_crashed_mean=trlc_m, t_rec_leader_crashed_std=trlc_s, t_rec_leader_crashed_n=trlc_n,
        t_rec_leader_survived_mean=trls_m, t_rec_leader_survived_std=trls_s, t_rec_leader_survived_n=trls_n,
        leader_crashed_cycles=sum(r["leader_crashed"] for r in results),
        elections_mean=mean_std([r["n_elections"] for r in results])[0],
        late_commits=sum(r["late_commits"] for r in results), dup_commits=sum(r["dup_commits"] for r in results),
        unresolved=sum(r["n_unresolved"] for r in results),
        msgs_dropped_frac=(sum(r["msgs_dropped"] for r in results) / max(1, sum(r["msgs_sent"] for r in results))),
        fail_reasons=json.dumps(reasons), wall_s=sum(r["wall"] for r in results),
    )


def fmt_pm(m, s, nd=3):
    if m != m:
        return "--"
    return f"{m:.{nd}f} $\\pm$ {s:.{nd}f}"


def write_tables(summaries, tab_dir, N_table, variant_tag=""):
    """LaTeX fragments in the manuscript's column layout plus CI / +- columns."""
    def rows_for(exp, N, extra=None):
        rs = [s for s in summaries if s["experiment"] == exp and s["N"] == N]
        if extra:
            rs = [s for s in rs if all(s.get(k) == v for k, v in extra.items())]
        return sorted(rs, key=lambda s: s["ratio"])

    # --- node failure
    rs = rows_for("node", N_table, dict(variant="leader-eligible"))
    with open(os.path.join(tab_dir, f"tab_node_failure{variant_tag}.tex"), "w") as fh:
        fh.write(f"% generated by fabric_fault_sim.py (N={N_table}, T={rs[0]['trials'] if rs else '?'} cycles, leader-eligible crashes)\n")
        fh.write("\\begin{tabular*}{\\columnwidth}{@{\\extracolsep{\\fill}}ccccccc@{}}\n\\toprule\n")
        fh.write("\\makecell[c]{\\textbf{Node Failure}\\\\\\textbf{Ratio (\\%)}} & \\textbf{Requests} & \\makecell[c]{\\textbf{Commits}\\\\(mean/cycle)} & "
                 "\\makecell[c]{\\textbf{Success}\\\\\\textbf{Probability}} & \\makecell[c]{\\textbf{Wilson}\\\\\\textbf{95\\% CI}} & "
                 "\\makecell[c]{\\textbf{First-attempt}\\\\\\textbf{success}} & \\makecell[c]{\\textbf{Mean}\\\\\\textbf{retries}} \\\\\n\\midrule\n")
        for s in rs:
            fh.write(f"{int(round(s['ratio']*100))} & {s['n_req']//s['trials']} & {s['commits_per_1000']:.1f} & "
                     f"{s['p_succ']:.4f} $\\pm$ {s['p_succ_cycle_std']:.4f} & [{s['wilson_lo']:.4f}, {s['wilson_hi']:.4f}] & "
                     f"{s['p_first']:.3f} & {s['mean_retries']:.3f} \\\\\n")
        fh.write("\\bottomrule\n\\end{tabular*}\n")

    # --- link failure
    rs = rows_for("link", N_table, dict(variant="random"))
    with open(os.path.join(tab_dir, f"tab_link_failure{variant_tag}.tex"), "w") as fh:
        fh.write(f"% generated by fabric_fault_sim.py (N={N_table}, independent per-message loss)\n")
        fh.write("\\begin{tabular*}{\\columnwidth}{@{\\extracolsep{\\fill}}ccccccc@{}}\n\\toprule\n")
        fh.write("\\makecell[c]{\\textbf{Link Failure}\\\\\\textbf{Ratio (\\%)}} & \\textbf{Requests} & \\makecell[c]{\\textbf{Commits}\\\\(mean/cycle)} & "
                 "\\makecell[c]{\\textbf{Success}\\\\\\textbf{Probability}} & \\makecell[c]{\\textbf{Wilson}\\\\\\textbf{95\\% CI}} & "
                 "\\makecell[c]{\\textbf{First-attempt}\\\\\\textbf{success}} & \\makecell[c]{\\textbf{Mean latency}\\\\\\textbf{(s)}} \\\\\n\\midrule\n")
        for s in rs:
            fh.write(f"{int(round(s['ratio']*100))} & {s['n_req']//s['trials']} & {s['commits_per_1000']:.1f} & "
                     f"{s['p_succ']:.4f} $\\pm$ {s['p_succ_cycle_std']:.4f} & [{s['wilson_lo']:.4f}, {s['wilson_hi']:.4f}] & "
                     f"{s['p_first']:.3f} & {fmt_pm(s['mean_latency'], s['mean_latency_std'], 2)} \\\\\n")
        fh.write("\\bottomrule\n\\end{tabular*}\n")

    # --- failure / recovery
    rs = rows_for("node", N_table, dict(variant="leader-eligible"))
    with open(os.path.join(tab_dir, f"tab_failure_recovery{variant_tag}.tex"), "w") as fh:
        fh.write(f"% generated by fabric_fault_sim.py (N={N_table}; T_rec right-censored at cycle end)\n")
        fh.write("\\begin{tabular*}{\\columnwidth}{@{\\extracolsep{\\fill}}cccccccc@{}}\n\\toprule\n")
        fh.write("\\makecell[c]{\\textbf{Node Failure}\\\\\\textbf{Ratio (\\%)}} & \\makecell[c]{\\textbf{Failure}\\\\\\textbf{Rate}} & "
                 "\\makecell[c]{\\textbf{Recovery}\\\\\\textbf{Time (s)}\\\\mean $\\pm$ std} & \\makecell[c]{$T_{rec}$\\\\median} & \\makecell[c]{$T_{rec}$\\\\95th pct.} & "
                 "\\makecell[c]{Infrastructure\\\\component (s)} & \\makecell[c]{Retry\\\\component (s)} & \\makecell[c]{Censored\\\\/ cycles} \\\\\n\\midrule\n")
        for s in rs:
            if s["ratio"] == 0:
                fh.write(f"0 & {s['lambda_tx']:.4f} & -- & -- & -- & -- & -- & -- \\\\\n")
                continue
            fh.write(f"{int(round(s['ratio']*100))} & {s['lambda_tx']:.4f} & {fmt_pm(s['t_rec_mean'], s['t_rec_std'], 2)} & {s['t_rec_median']:.2f} & {s['t_rec_p95']:.2f} & "
                     f"{fmt_pm(s['t_infra_mean'], s['t_infra_std'], 2)} & {fmt_pm(s['t_retry_mean'], s['t_retry_std'], 2)} & {s['t_rec_censored']}/{s['trials']} \\\\\n")
        fh.write("\\bottomrule\n\\end{tabular*}\n")


def write_split_table(summaries, tab_dir, N_table):
    rs = sorted([s for s in summaries if s["experiment"] == "node" and s["N"] == N_table and s["variant"] == "leader-eligible" and s["ratio"] > 0], key=lambda s: s["ratio"])
    with open(os.path.join(tab_dir, "tab_recovery_split.tex"), "w") as fh:
        fh.write(f"% generated by fabric_fault_sim.py (N={N_table}) -- T_rec conditional on whether the Raft leader was among the crashed nodes\n")
        fh.write("\\begin{tabular}{cccc}\n\\toprule\n")
        fh.write("\\makecell[c]{Node Failure\\\\Ratio (\\%)} & \\makecell[c]{Cycles with\\\\leader crash} & \\makecell[c]{$T_{rec}$ (s), leader survived\\\\mean $\\pm$ std} & \\makecell[c]{$T_{rec}$ (s), leader crashed\\\\mean $\\pm$ std} \\\\\n\\midrule\n")
        for s in rs:
            fh.write(f"{int(round(s['ratio']*100))} & {s['leader_crashed_cycles']}/{s['trials']} & {fmt_pm(s['t_rec_leader_survived_mean'], s['t_rec_leader_survived_std'], 2)} & {fmt_pm(s['t_rec_leader_crashed_mean'], s['t_rec_leader_crashed_std'], 2)} \\\\\n")
        fh.write("\\bottomrule\n\\end{tabular}\n")


def make_figure(summaries, fig_dir, Ns):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.9))
    markers = ["o", "s", "^", "D"]
    for ax, exp, var, xlabel in ((axes[0], "node", "leader-eligible", "Node-failure ratio (%)"),
                                 (axes[1], "link", "random", "Link-failure ratio (%)")):
        for mi, N in enumerate(Ns):
            rs = sorted([s for s in summaries if s["experiment"] == exp and s["N"] == N and s["variant"] == var], key=lambda s: s["ratio"])
            if not rs:
                continue
            x = [100 * s["ratio"] for s in rs]
            y = [s["p_succ_cycle_mean"] for s in rs]
            e = [s["p_succ_cycle_std"] for s in rs]
            yf = [s["p_first"] for s in rs]
            ef = [s["p_first_std"] for s in rs]
            col = f"C{mi}"
            ax.errorbar(x, y, yerr=e, marker=markers[mi % 4], color=col, capsize=3, lw=1.2, ms=4, label=f"N = {N}")
            ax.errorbar(x, yf, yerr=ef, marker=markers[mi % 4], color=col, capsize=2, lw=0.9, ms=3, ls="--", mfc="none")
        ax.set_xlabel(xlabel)
        ax.set_ylabel("Transaction success probability $P_{succ}$")
        ax.grid(True, alpha=0.3)
        ax.set_ylim(0.80, 1.01)
    axes[0].legend(fontsize=8, loc="lower left")
    from matplotlib.lines import Line2D
    axes[1].legend(handles=[Line2D([], [], color="k", ls="-", label="with retries ($r=3$)"),
                            Line2D([], [], color="k", ls="--", label="first attempt only")], fontsize=8, loc="lower left")
    axes[0].set_title("(a) Node crashes", fontsize=9)
    axes[1].set_title("(b) Independent message loss", fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join(fig_dir, "fig_psucc_failures.pdf"))
    plt.close(fig)


def build_conditions(args):
    conds = []
    node_ratios = [0.0, 0.1, 0.2, 0.3, 0.4]
    link_ratios = [0.0, 0.05, 0.10, 0.15, 0.20]
    for N in args.N_list:
        for r in node_ratios:
            conds.append(dict(experiment="node", N=N, ratio=r, variant="leader-eligible"))
        for r in link_ratios:
            conds.append(dict(experiment="link", N=N, ratio=r, variant="random"))
    if not args.no_variants:
        Nt = args.N_table
        for r in node_ratios[1:]:
            conds.append(dict(experiment="node", N=Nt, ratio=r, variant="non-leader-only"))
        for r in link_ratios[1:]:
            conds.append(dict(experiment="link", N=Nt, ratio=r, variant="persistent"))
        # sensitivity: no retries, staggered crashes, re-selection of endorsers, fast election timeout
        for r in node_ratios[1:]:
            conds.append(dict(experiment="node", N=Nt, ratio=r, variant="no-retry"))
            conds.append(dict(experiment="node", N=Nt, ratio=r, variant="staggered"))
            conds.append(dict(experiment="node", N=Nt, ratio=r, variant="reselect"))
            conds.append(dict(experiment="node", N=Nt, ratio=r, variant="fast-election"))
        for r in link_ratios[1:]:
            conds.append(dict(experiment="link", N=Nt, ratio=r, variant="no-retry"))
    return conds


def params_for(cond, args):
    p = dict(DEFAULTS)
    p.update(dict(N=cond["N"], requests=args.requests, rate=args.rate, timeout=args.timeout, retries=args.retries,
                  k=args.k, f=args.f, election_scale=args.election_scale, mttr=args.mttr,
                  cycle_length=args.cycle_length, net_delay_ms=args.net_delay_ms, max_msg=args.max_msg,
                  batch_timeout=args.batch_timeout, p_chaincode_fail=args.p_chaincode_fail))
    v = cond["variant"]
    if cond["experiment"] == "node":
        p["crash_ratio"] = cond["ratio"]
        p["leader_eligible"] = (v != "non-leader-only")
        if v == "no-retry":
            p["retries"] = 0
        if v == "staggered":
            p["crash_mode"] = "staggered"
        if v == "reselect":
            p["reselect_on_retry"] = True
        if v == "fast-election":
            p["election_scale"] = 0.03   # 150-300 ms
    else:
        p["link_ratio"] = cond["ratio"]
        p["link_mode"] = "persistent" if v == "persistent" else "random"
        if v == "no-retry":
            p["retries"] = 0
    return p


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--outdir", default=os.path.dirname(os.path.abspath(__file__)))
    ap.add_argument("--trials", type=int, default=30, help="independent cycles per condition (default 30)")
    ap.add_argument("--seed", type=int, default=20261027, help="base seed (default 20261027)")
    ap.add_argument("--N-list", type=int, nargs="+", default=[10, 20, 30, 50], help="consortium sizes (default 10 20 30 50)")
    ap.add_argument("--N-table", type=int, default=20, help="N used for the LaTeX tables (default 20)")
    ap.add_argument("--requests", type=int, default=1000)
    ap.add_argument("--rate", type=float, default=100.0, help="request arrival rate per second (default 100)")
    ap.add_argument("--timeout", type=float, default=10.0, help="per-attempt timeout in s (default 10)")
    ap.add_argument("--retries", type=int, default=3, help="max client retries (default 3)")
    ap.add_argument("--k", type=int, default=1)
    ap.add_argument("--f", type=int, default=2)
    ap.add_argument("--election-scale", type=float, default=1.0, help="scale of election timeout (1.0 => 5-10 s Fabric default; 0.03 => 150-300 ms)")
    ap.add_argument("--mttr", type=float, default=30.0, help="node restart time after crash in s (default 30)")
    ap.add_argument("--cycle-length", type=float, default=120.0, help="censoring horizon per cycle in s (default 120)")
    ap.add_argument("--net-delay-ms", type=float, default=20.0)
    ap.add_argument("--max-msg", type=int, default=10)
    ap.add_argument("--batch-timeout", type=float, default=2.0)
    ap.add_argument("--p-chaincode-fail", type=float, default=0.0)
    ap.add_argument("--no-variants", action="store_true", help="skip the N_table-only variants/sensitivity runs")
    ap.add_argument("--workers", type=int, default=max(1, os.cpu_count() or 1))
    ap.add_argument("--single", type=str, default=None, help="run one condition only, e.g. node:20:0.4:leader-eligible, print JSON")
    args = ap.parse_args()

    res_dir = os.path.join(args.outdir, "results")
    tab_dir = os.path.join(args.outdir, "tables")
    fig_dir = os.path.join(args.outdir, "figures")
    for d in (res_dir, tab_dir, fig_dir):
        os.makedirs(d, exist_ok=True)

    if args.single:
        e, N, r, v = args.single.split(":")
        cond = dict(experiment=e, N=int(N), ratio=float(r), variant=v)
        p = params_for(cond, args)
        rs = [run_one((p, args.seed + i)) for i in range(args.trials)]
        print(json.dumps(summarise(cond, rs), indent=1))
        return

    conds = build_conditions(args)
    jobs = []
    for ci, cond in enumerate(conds):
        p = params_for(cond, args)
        for t in range(args.trials):
            jobs.append((ci, (p, args.seed + 1000 * ci + t)))
    t0 = time.time()
    print(f"{len(conds)} conditions x {args.trials} cycles = {len(jobs)} cycles on {args.workers} workers", flush=True)
    if args.workers > 1:
        with Pool(args.workers) as pool:
            outs = pool.map(run_one, [j[1] for j in jobs], chunksize=4)
    else:
        outs = [run_one(j[1]) for j in jobs]
    per_cond = {}
    for (ci, _), o in zip(jobs, outs):
        per_cond.setdefault(ci, []).append(o)
    summaries = [summarise(conds[ci], per_cond[ci]) for ci in range(len(conds))]
    wall = time.time() - t0
    print(f"simulation wall time {wall:.1f} s", flush=True)

    # raw per-cycle CSV
    with open(os.path.join(res_dir, "fabric_cycles.csv"), "w", newline="") as fh:
        keys = ["experiment", "N", "ratio", "variant", "seed", "n_req", "n_succ", "p_succ", "p_first", "mean_retries",
                "mean_latency", "p95_latency", "n_elections", "leader_crashed", "fault_time", "cycle_end", "t_rec",
                "t_rec_censored", "t_infra", "t_retry", "t_rec_base", "msgs_sent", "msgs_dropped", "late_commits",
                "dup_commits", "n_unresolved", "fail_reasons", "wall"]
        w = csv.writer(fh)
        w.writerow(keys)
        for ci, cond in enumerate(conds):
            for o in per_cond[ci]:
                row = dict(o)
                row["fail_reasons"] = json.dumps(row["fail_reasons"])
                w.writerow([cond["experiment"], cond["N"], cond["ratio"], cond["variant"]] + [row.get(k, "") for k in keys[4:]])
    with open(os.path.join(res_dir, "fabric_summary.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(summaries[0].keys()))
        w.writeheader()
        w.writerows(summaries)
    with open(os.path.join(res_dir, "fabric_summary.json"), "w") as fh:
        json.dump(dict(args=vars(args), defaults=DEFAULTS, wall_s=wall, summaries=summaries), fh, indent=1)

    write_tables(summaries, tab_dir, args.N_table)
    write_split_table(summaries, tab_dir, args.N_table)
    make_figure(summaries, fig_dir, args.N_list)

    # console digest
    for s in summaries:
        print(f"{s['experiment']:4s} N={s['N']:2d} ratio={s['ratio']:.2f} {s['variant']:16s} "
              f"P={s['p_succ']:.4f}±{s['p_succ_cycle_std']:.4f} CI=[{s['wilson_lo']:.4f},{s['wilson_hi']:.4f}] "
              f"first={s['p_first']:.3f} retries={s['mean_retries']:.3f} lat={s['mean_latency']:.2f} "
              f"Trec={s['t_rec_mean']:.2f}±{s['t_rec_std']:.2f} med={s['t_rec_median']:.2f} p95={s['t_rec_p95']:.2f} "
              f"infra={s['t_infra_mean']:.2f} retry={s['t_retry_mean']:.2f} cens={s['t_rec_censored']} "
              f"ldrX={s['leader_crashed_cycles']} fails={s['fail_reasons']}")


if __name__ == "__main__":
    main()
