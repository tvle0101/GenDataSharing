#!/usr/bin/env python3
"""
validate.py -- statistical / sanity checks on the generated results.
  1. Wilson 95% CI implementation vs scipy.stats.binomtest(...).proportion_ci(method="wilson").
  2. P_succ at 0% node / link failure must be exactly 1.0 (no failure mechanism is active).
  3. Analytic availability reproduces the manuscript's 0.999896 (scaled) and 0.9979 (baseline).
  4. Trust simulation: |T_net_mean - closed-form expectation| <= 3 * std/sqrt(T) for every condition.
  5. Fault simulation: first-attempt success under independent message loss p (no-retry variant)
     is compared with the closed-form endorsement bound 1 - (1 - (1-p)^2)^2 (upper bound: other
     losses are recovered by in-attempt resubmission, so simulated <= bound is expected).
  6. Recovery events: report number censored; cycles with unresolved requests must be 0.
Exit status 1 if any hard check fails.
"""
import json
import math
import os
import sys

from scipy.stats import binomtest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from fabric_fault_sim import wilson  # noqa: E402

ok = True


def check(cond, msg):
    global ok
    print(("PASS " if cond else "FAIL ") + msg)
    ok = ok and cond


# 1. Wilson
for k, n in [(0, 30000), (29990, 30000), (27823, 30000), (5, 10), (1000, 1000)]:
    lo, hi = wilson(k, n)
    ci = binomtest(k, n).proportion_ci(confidence_level=0.95, method="wilson")
    check(abs(lo - ci.low) < 1e-9 and abs(hi - ci.high) < 1e-9, f"Wilson CI k={k} n={n}: ours=({lo:.6f},{hi:.6f}) scipy=({ci.low:.6f},{ci.high:.6f})")

# 2./5./6. fault simulation
S = json.load(open(os.path.join(HERE, "results", "fabric_summary.json")))["summaries"]
for s in S:
    if s["ratio"] == 0:
        check(s["p_succ"] == 1.0, f"P_succ at 0% ({s['experiment']}, N={s['N']}) = {s['p_succ']}")
check(all(s["unresolved"] == 0 for s in S), "no unresolved requests at cycle end in any condition")
cens = {(s["experiment"], s["N"], s["ratio"], s["variant"]): s["t_rec_censored"] for s in S if s["t_rec_censored"]}
print("INFO censored recovery events:", cens if cens else "none")
for s in S:
    if s["experiment"] == "link" and s["variant"] == "no-retry":
        p = s["ratio"]
        bound = 1 - (1 - (1 - p) ** 2) ** 2
        check(s["p_first"] <= bound + 0.01, f"link p={p}: first-attempt success {s['p_first']:.4f} <= endorsement bound {bound:.4f}")

# 3. analytic
A = json.load(open(os.path.join(HERE, "results", "analytic_all.json")))["table_rel"]
check(abs(A[1]["A_sys"] - 0.999896) < 5e-7, f"scaled A_sys = {A[1]['A_sys']:.6f} (manuscript 0.999896)")
check(abs(A[0]["A_sys"] - 0.9979) < 5e-5, f"baseline A_sys = {A[0]['A_sys']:.6f} (manuscript 0.9980; exact 0.997901)")

# 4. trust
T = json.load(open(os.path.join(HERE, "results", "trust_summary.json")))["summaries"]
for s in T:
    se = s["T_net_std"] / math.sqrt(s["trials"]) if s["T_net_std"] > 0 else 1e-9
    d = abs(s["T_net_mean"] - s["T_net_expected"])
    check(d <= max(3 * se, 1e-3), f"trust {s['weights'][:8]} N={s['N']} rho={s['rho']}: sim {s['T_net_mean']:.4f} vs E {s['T_net_expected']:.4f} (|d|={d:.4f}, 3se={3*se:.4f})")

print("ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED")
sys.exit(0 if ok else 1)
