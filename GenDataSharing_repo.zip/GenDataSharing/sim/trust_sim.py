#!/usr/bin/env python3
"""
trust_sim.py -- application-layer consortium trust model (manuscript Section "Malicious Nodes",
Fig. F6).  This model is INDEPENDENT of the Raft ordering service: Raft tolerates crash faults
only; misbehaving-but-certified nodes are handled by endorsement policy + this trust score.

Model (exactly as in the manuscript)
------------------------------------
  T_i = alpha*T_file + beta*T_tx + gamma*T_delay + delta*T_rep,   T_net = (1/N) sum_i T_i
  T_file  = N_auth / N_file          T_tx    = N_valid / N_tx
  T_delay = 1 - N_delay / N_service  T_rep   = 1 - N_abnormal / N_rating
Per cycle: a consortium of N nodes, N_m = round(rho_m * N) malicious nodes chosen uniformly at
random. Every node performs S files, S transactions, S services and receives S ratings (S=100).
A malicious node makes each file inauthentic w.p. 0.40, each transaction response invalid w.p.
0.30, each service delayed w.p. 0.20 and each received rating abnormal (collusive inflation)
w.p. 0.10 (the manuscript's attack probabilities).  Honest nodes have a small background error
rate eps (default 0.01) on every component (genuine data-quality issues, network delays, noisy
ratings).  All counts are Binomial draws; T cycles (default 30) with distinct seeds.

Outputs: results/trust_summary.csv|json, results/trust_cycles.csv, tables/tab_trust.tex,
figures/fig_trust_net.pdf (T_net vs rho_m, one line per N, mean +- std error bars),
figures/fig_trust_weights.pdf (weight-vector sensitivity, N=20).
Expected value check: E[T_net] = 1 - eps*(1-rho) - rho*(alpha*0.4+beta*0.3+gamma*0.2+delta*0.1)
(for rho = N_m/N exactly), printed next to the simulated values.
"""
import argparse
import csv
import hashlib
import json
import os
import random

ATTACK_P = dict(file=0.40, tx=0.30, delay=0.20, rep=0.10)
WEIGHT_SETS = {
    "paper (0.4,0.3,0.2,0.1)": (0.4, 0.3, 0.2, 0.1),
    "uniform (0.25,0.25,0.25,0.25)": (0.25, 0.25, 0.25, 0.25),
    "integrity-heavy (0.5,0.3,0.1,0.1)": (0.5, 0.3, 0.1, 0.1),
}


def binom(rng, n, p):
    # exact Binomial via inversion is slow for n=100; use sum of Bernoulli (n small)
    return sum(1 for _ in range(n) if rng.random() < p)


def run_cycle(N, rho, S, eps, weights, seed):
    rng = random.Random(hashlib.sha256(f"trust-sim:{seed}".encode()).digest())
    n_m = int(round(rho * N))
    malicious = set(rng.sample(range(N), n_m))
    a, b, g, d = weights
    T = []
    comp = dict(file=[], tx=[], delay=[], rep=[])
    for i in range(N):
        if i in malicious:
            p = dict(ATTACK_P)
        else:
            p = dict(file=eps, tx=eps, delay=eps, rep=eps)
        n_inauth = binom(rng, S, p["file"])
        n_invalid = binom(rng, S, p["tx"])
        n_delay = binom(rng, S, p["delay"])
        n_abn = binom(rng, S, p["rep"])
        t_file = (S - n_inauth) / S
        t_tx = (S - n_invalid) / S
        t_delay = 1 - n_delay / S
        t_rep = 1 - n_abn / S
        comp["file"].append(t_file)
        comp["tx"].append(t_tx)
        comp["delay"].append(t_delay)
        comp["rep"].append(t_rep)
        T.append(a * t_file + b * t_tx + g * t_delay + d * t_rep)
    t_net = sum(T) / N
    t_hon = [T[i] for i in range(N) if i not in malicious]
    t_mal = [T[i] for i in range(N) if i in malicious]
    return dict(seed=seed, N=N, rho=rho, n_m=n_m, T_net=t_net,
                T_honest=sum(t_hon) / len(t_hon) if t_hon else float("nan"),
                T_malicious=sum(t_mal) / len(t_mal) if t_mal else float("nan"),
                **{f"T_{k}": sum(v) / N for k, v in comp.items()})


def expected_tnet(N, rho, eps, weights):
    n_m = int(round(rho * N))
    r = n_m / N
    a, b, g, d = weights
    mal = a * ATTACK_P["file"] + b * ATTACK_P["tx"] + g * ATTACK_P["delay"] + d * ATTACK_P["rep"]
    return 1 - (1 - r) * eps - r * mal


def mean_std(xs):
    m = sum(xs) / len(xs)
    s = (sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) ** 0.5 if len(xs) > 1 else 0.0
    return m, s


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--outdir", default=os.path.dirname(os.path.abspath(__file__)))
    ap.add_argument("--trials", type=int, default=30, help="cycles per condition (default 30)")
    ap.add_argument("--seed", type=int, default=20261027)
    ap.add_argument("--N-list", type=int, nargs="+", default=[10, 20, 30, 50])
    ap.add_argument("--rho-list", type=float, nargs="+", default=[0.0, 0.1, 0.2, 0.3, 0.4])
    ap.add_argument("--S", type=int, default=100, help="files/transactions/services/ratings per node per cycle (default 100)")
    ap.add_argument("--eps", type=float, default=0.01, help="honest-node background error rate per action (default 0.01)")
    ap.add_argument("--N-sens", type=int, default=20, help="N used for the weight-sensitivity run")
    args = ap.parse_args()

    res_dir = os.path.join(args.outdir, "results")
    tab_dir = os.path.join(args.outdir, "tables")
    fig_dir = os.path.join(args.outdir, "figures")
    for d in (res_dir, tab_dir, fig_dir):
        os.makedirs(d, exist_ok=True)

    cycles = []
    summaries = []
    ci = 0
    for wname, w in WEIGHT_SETS.items():
        Ns = args.N_list if wname.startswith("paper") else [args.N_sens]
        for N in Ns:
            for rho in args.rho_list:
                rs = [run_cycle(N, rho, args.S, args.eps, w, args.seed + 1000 * ci + t) for t in range(args.trials)]
                ci += 1
                for r in rs:
                    cycles.append(dict(weights=wname, **r))
                m, s = mean_std([r["T_net"] for r in rs])
                mh, sh = mean_std([r["T_honest"] for r in rs])
                mm_list = [r["T_malicious"] for r in rs if r["T_malicious"] == r["T_malicious"]]
                mm, sm = mean_std(mm_list) if mm_list else (float("nan"), float("nan"))
                summaries.append(dict(weights=wname, alpha=w[0], beta=w[1], gamma=w[2], delta=w[3], N=N, rho=rho,
                                      n_m=rs[0]["n_m"], trials=args.trials, T_net_mean=m, T_net_std=s,
                                      T_net_expected=expected_tnet(N, rho, args.eps, w),
                                      T_honest_mean=mh, T_malicious_mean=mm,
                                      T_file=mean_std([r["T_file"] for r in rs])[0], T_tx=mean_std([r["T_tx"] for r in rs])[0],
                                      T_delay=mean_std([r["T_delay"] for r in rs])[0], T_rep=mean_std([r["T_rep"] for r in rs])[0]))

    with open(os.path.join(res_dir, "trust_cycles.csv"), "w", newline="") as fh:
        wtr = csv.DictWriter(fh, fieldnames=list(cycles[0].keys()))
        wtr.writeheader()
        wtr.writerows(cycles)
    with open(os.path.join(res_dir, "trust_summary.csv"), "w", newline="") as fh:
        wtr = csv.DictWriter(fh, fieldnames=list(summaries[0].keys()))
        wtr.writeheader()
        wtr.writerows(summaries)
    with open(os.path.join(res_dir, "trust_summary.json"), "w") as fh:
        json.dump(dict(args=vars(args), attack_p=ATTACK_P, summaries=summaries), fh, indent=1)

    # LaTeX table: T_net mean +- std, rows rho, columns N (paper weights) + expected value
    paper = [s for s in summaries if s["weights"].startswith("paper")]
    with open(os.path.join(tab_dir, "tab_trust.tex"), "w") as fh:
        fh.write(f"% generated by trust_sim.py (S={args.S}, eps={args.eps}, T={args.trials} cycles)\n")
        fh.write("\\begin{tabular}{c" + "c" * len(args.N_list) + "}\n\\toprule\n")
        fh.write("$\\rho_m$ (\\%) & " + " & ".join(f"$N={N}$" for N in args.N_list) + " \\\\\n\\midrule\n")
        for rho in args.rho_list:
            cells = []
            for N in args.N_list:
                s = [x for x in paper if x["N"] == N and x["rho"] == rho][0]
                cells.append(f"{s['T_net_mean']:.4f} $\\pm$ {s['T_net_std']:.4f}")
            fh.write(f"{int(round(rho*100))} & " + " & ".join(cells) + " \\\\\n")
        fh.write("\\bottomrule\n\\end{tabular}\n")
    # weight sensitivity table
    with open(os.path.join(tab_dir, "tab_trust_weights.tex"), "w") as fh:
        fh.write(f"% generated by trust_sim.py (N={args.N_sens})\n")
        fh.write("\\begin{tabular}{l" + "c" * len(args.rho_list) + "}\n\\toprule\n")
        fh.write("Weights $(\\alpha,\\beta,\\gamma,\\delta)$ & " + " & ".join(f"$\\rho_m={int(round(r*100))}\\%$" for r in args.rho_list) + " \\\\\n\\midrule\n")
        for wname in WEIGHT_SETS:
            rs = [s for s in summaries if s["weights"] == wname and s["N"] == args.N_sens]
            fh.write(wname.split(" ", 1)[1].replace("(", "$(").replace(")", ")$") + " & " + " & ".join(f"{s['T_net_mean']:.4f}" for s in sorted(rs, key=lambda s: s["rho"])) + " \\\\\n")
        fh.write("\\bottomrule\n\\end{tabular}\n")

    # figures
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(4.2, 3.0))
    markers = ["o", "s", "^", "D"]
    for mi, N in enumerate(args.N_list):
        rs = sorted([s for s in paper if s["N"] == N], key=lambda s: s["rho"])
        ax.errorbar([100 * s["rho"] for s in rs], [s["T_net_mean"] for s in rs], yerr=[s["T_net_std"] for s in rs],
                    marker=markers[mi % 4], capsize=3, lw=1.2, ms=4, label=f"N = {N}")
    ax.set_xlabel("Malicious-node ratio $\\rho_m$ (%)")
    ax.set_ylabel("Average consortium trust $T_{net}$")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(fig_dir, "fig_trust_net.pdf"))
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(4.2, 3.0))
    for mi, wname in enumerate(WEIGHT_SETS):
        rs = sorted([s for s in summaries if s["weights"] == wname and s["N"] == args.N_sens], key=lambda s: s["rho"])
        ax.errorbar([100 * s["rho"] for s in rs], [s["T_net_mean"] for s in rs], yerr=[s["T_net_std"] for s in rs],
                    marker=markers[mi % 4], capsize=3, lw=1.2, ms=4, label=wname)
    ax.set_xlabel("Malicious-node ratio $\\rho_m$ (%)")
    ax.set_ylabel(f"$T_{{net}}$ (N = {args.N_sens})")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(os.path.join(fig_dir, "fig_trust_weights.pdf"))
    plt.close(fig)

    for s in summaries:
        print(f"{s['weights'][:8]:8s} N={s['N']:2d} rho={s['rho']:.1f} (N_m={s['n_m']:2d}) T_net={s['T_net_mean']:.4f}±{s['T_net_std']:.4f} "
              f"expected={s['T_net_expected']:.4f} honest={s['T_honest_mean']:.4f} malicious={s['T_malicious_mean']:.4f}")


if __name__ == "__main__":
    main()
