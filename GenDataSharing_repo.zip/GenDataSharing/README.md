# GenDataSharing: code behind the manuscript

Reliable peer-to-peer genomic sequencing and data sharing with smart contracts in a consortium blockchain
(IEEE Transactions on Reliability, manuscript TR-2026-044, second revision).
This repository replaces the earlier release (`benchmark.go`, `genomic.go`); see `CHANGES.md` for the defects of the old
code and why it was replaced. `docs/PAPER_MAP.md` maps every table and number of the paper to the file that produces it.

## Layout

| Directory | Contents |
|---|---|
| `cryptobench/` | the scheme on BLS12-381 ([cloudflare/circl](https://github.com/cloudflare/circl)) + ECDSA P-256 + AES-256-GCM/HMAC: all sequencing and sharing algorithms, unit tests, benchmarks; `results/` holds the measured unit costs |
| `chaincode/genomic/go/` | `GSContract` (`SeqPriVer`, `SeqTxnFin`, `QuerySeqRecord`) and `DSContract` (`ShaPriVer`, `ShaTxnFin`, `QueryShareRecord`) for Hyperledger Fabric 2.5; verifies the ECDSA and pairing equations on-chain, uses the transaction timestamp, rejects duplicate record IDs; unit tests |
| `testbed/` | scripts, Gateway-SDK client and raw results of the single-host Fabric testbed (Table IV, Section IX-E) |
| `sim/` | analytic availability model, discrete-event Raft consortium fault simulator, trust-score simulator, validation script; regenerates Tables V-VIII |
| `docs/` | `PAPER_MAP.md` |

## Quick start

Requirements: Go >= 1.24, Python 3 with numpy, matplotlib and scipy.

```bash
make test         # unit tests: scheme and chaincode (seconds)
make sim-quick    # smoke run, 10 cycles per condition (~30 s), in a scratch copy under /tmp/gds_sim
make sim          # the paper's 30 cycles (~100 s); regenerates the files in sim/
make crypto-bench # Table II unit costs (~5 min)
```

Simulations are seeded (default seed 20261027) and reproducible bit-for-bit; `sim/validate.py` runs 51 consistency checks.
The Fabric testbed needs a local Fabric build and is described in `testbed/README.md`.

## Go modules and the `replace` lines

`cryptobench/go.mod` and `chaincode/genomic/go/go.mod` contain `replace` lines that point `golang.org/x/*`, `google.golang.org/*`
and `gopkg.in/*` to their GitHub mirrors. They were needed on the build host, which could not reach the Go module proxy, and
the pinned versions are the ones the reported numbers were produced with. On a machine with normal access you can delete the
`replace` block and run `go mod tidy`.

## What is not in this repository

* Fabric binaries, `fabric-samples` and generated crypto material (see `.gitignore`).
* A license: add the `LICENSE` the authors agree on before making the repository public.
* Measurements on a geographically distributed multi-organization network; the paper states that these were not made.
