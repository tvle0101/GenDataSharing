// Package cryptobench implements the cryptographic scheme of the manuscript
// "P2P genomic sequencing and data sharing on a consortium blockchain"
// (Section "Proposed Cryptographic Scheme") on concrete, standard curves:
//
//   - the BLS-style aggregate signatures (sigma_x1 = g^s in G1,
//     sigma_x2 = H^s in G2, verified by e(sigma_x1, H) == e(g, sigma_x2))
//     on the pairing-friendly curve BLS12-381 (≈128-bit security), using
//     github.com/cloudflare/circl/ecc/bls12381;
//   - the conventional signatures Sig_prk(.) that wrap every message, as
//     ECDSA over NIST P-256 with SHA-256 (crypto/ecdsa);
//   - the EC-based signcryption (K = s*puk, SE = AES-256-GCM,
//     hmac = HMAC-SHA256) over P-256.
//
// The manuscript is written for a symmetric (type-A) pairing
// e: G1 x G1 -> G2.  BLS12-381 is an asymmetric (type-3) pairing
// e: G1 x G2 -> GT, so the paper's "g" lives in G1 and the hash outputs
// H = h(.) live in G2 (hash-to-curve, RFC 9380).  The verification equation
// e(H, sigma_1) = e(sigma_2, g) of the paper is therefore evaluated as
// e(sigma_1, H) = e(g, sigma_2).  Every other step is exactly as written.
//
// All encodings are deterministic (compressed points, big-endian scalars,
// length-prefixed concatenation for hashing) so that the chaincode, which
// re-executes verification on every endorsing peer, is deterministic.
package cryptobench

import (
	"crypto/rand"
	"encoding/binary"
	"errors"
	"io"

	"github.com/cloudflare/circl/ecc/bls12381"
)

// DST is the domain-separation tag for hash-to-G2 (RFC 9380, Section 3.1).
// It must be identical in the chaincode and in the clients.
const DST = "GENDATASHARING-V01-CS01-with-BLS12381G2_XMD:SHA-256_SSWU_RO_"

var (
	errNotOnG1 = errors.New("cryptobench: invalid G1 element")
	errNotOnG2 = errors.New("cryptobench: invalid G2 element")
)

// Sizes of the compressed encodings used on the wire and on the ledger.
const (
	G1Size = bls12381.G1SizeCompressed // 48 bytes
	G2Size = bls12381.G2SizeCompressed // 96 bytes
)

// G1Gen returns the generator g of G1.
func G1Gen() *bls12381.G1 { return bls12381.G1Generator() }

// RandomScalar draws s uniformly from Z_q (q = order of BLS12-381 groups).
func RandomScalar() *bls12381.Scalar {
	s := new(bls12381.Scalar)
	if err := s.Random(rand.Reader); err != nil {
		panic("cryptobench: entropy source failed: " + err.Error())
	}
	return s
}

// HashToG2 implements the paper's H = h(m) in G2 (RFC 9380 hash_to_curve,
// XMD:SHA-256, SSWU, random-oracle variant) with the fixed DST above.
func HashToG2(msg []byte) *bls12381.G2 {
	h := new(bls12381.G2)
	h.Hash(msg, []byte(DST))
	return h
}

// AggSig is a (possibly aggregated) BLS-style signature pair
// (sigma_1 in G1, sigma_2 in G2).
type AggSig struct {
	S1 *bls12381.G1
	S2 *bls12381.G2
}

// Sign computes sigma_1 = g^s, sigma_2 = H^s for a fresh random s and the
// given H (= h(m)).  It is the "Initial sign" of Table TC (one E1, one E2).
// The scalar is returned because the signcryption algorithms reuse it.
func Sign(H *bls12381.G2) (*bls12381.Scalar, *AggSig) {
	s := RandomScalar()
	return s, SignWithScalar(H, s)
}

// SignWithScalar is Sign with a caller-chosen s.
func SignWithScalar(H *bls12381.G2, s *bls12381.Scalar) *AggSig {
	s1 := new(bls12381.G1)
	s1.ScalarMult(s, bls12381.G1Generator())
	s2 := new(bls12381.G2)
	s2.ScalarMult(s, H)
	return &AggSig{S1: s1, S2: s2}
}

// Aggregate multiplies the inputs component-wise (additive notation in
// circl): sigma_1 = prod sigma_1_i, sigma_2 = prod sigma_2_i.  Used for
// sigma_b1 = sigma_a1 * g^{s_b}, sigma_b2 = sigma_a2 * H^{s_b} and for the
// n-user batch of Remarks 1-3.
func Aggregate(sigs ...*AggSig) *AggSig {
	out := &AggSig{S1: new(bls12381.G1), S2: new(bls12381.G2)}
	out.S1.SetIdentity()
	out.S2.SetIdentity()
	for _, s := range sigs {
		out.S1.Add(out.S1, s.S1)
		out.S2.Add(out.S2, s.S2)
	}
	return out
}

// AggregateSign is the "Batch sign" of Table TC: it adds a fresh
// contribution (g^s, H^s) to prev and returns the new scalar and the sum.
func AggregateSign(H *bls12381.G2, prev *AggSig) (*bls12381.Scalar, *AggSig) {
	s, mine := Sign(H)
	return s, Aggregate(prev, mine)
}

// Verify checks the paper's equation e(H, sigma_1) == e(sigma_2, g), i.e.
// e(sigma_1, H) == e(g, sigma_2) on the type-3 curve.  It performs two
// full pairings, which is exactly the 2*P_e accounted for in Table TC.
// It rejects the identity in sigma_1 (which would make the check vacuous).
func Verify(H *bls12381.G2, sig *AggSig) bool {
	if sig == nil || sig.S1 == nil || sig.S2 == nil || H == nil {
		return false
	}
	if sig.S1.IsIdentity() || H.IsIdentity() {
		return false
	}
	lhs := bls12381.Pair(sig.S1, H)
	rhs := bls12381.Pair(bls12381.G1Generator(), sig.S2)
	return lhs.IsEqual(rhs)
}

// VerifyFast is the same check with one Miller loop pair and a single final
// exponentiation: e(sigma_1, H) * e(g, sigma_2)^{-1} == 1.  It is offered
// for implementers; the benchmarks report both.
func VerifyFast(H *bls12381.G2, sig *AggSig) bool {
	if sig == nil || sig.S1 == nil || sig.S2 == nil || H == nil {
		return false
	}
	if sig.S1.IsIdentity() || H.IsIdentity() {
		return false
	}
	r := bls12381.ProdPairFrac(
		[]*bls12381.G1{sig.S1, bls12381.G1Generator()},
		[]*bls12381.G2{H, sig.S2},
		[]int{1, -1})
	return r.IsIdentity()
}

// Bytes returns the compressed encodings (48 + 96 bytes).
func (a *AggSig) Bytes() (s1, s2 []byte) {
	return a.S1.BytesCompressed(), a.S2.BytesCompressed()
}

// ParseG1 decodes a (compressed or uncompressed) G1 element and checks
// that it is on the curve and in the prime-order subgroup.
func ParseG1(b []byte) (*bls12381.G1, error) {
	p := new(bls12381.G1)
	if err := p.SetBytes(b); err != nil {
		return nil, errNotOnG1
	}
	return p, nil
}

// ParseG2 decodes a G2 element with subgroup check.
func ParseG2(b []byte) (*bls12381.G2, error) {
	p := new(bls12381.G2)
	if err := p.SetBytes(b); err != nil {
		return nil, errNotOnG2
	}
	return p, nil
}

// ParseAggSig decodes (sigma_1, sigma_2).
func ParseAggSig(s1, s2 []byte) (*AggSig, error) {
	p1, err := ParseG1(s1)
	if err != nil {
		return nil, err
	}
	p2, err := ParseG2(s2)
	if err != nil {
		return nil, err
	}
	return &AggSig{S1: p1, S2: p2}, nil
}

// concat is the canonical, injective encoding used for every hash and
// signature input: for each part, a 4-byte big-endian length then the bytes.
func concat(parts ...[]byte) []byte {
	n := 0
	for _, p := range parts {
		n += 4 + len(p)
	}
	out := make([]byte, 0, n)
	var l [4]byte
	for _, p := range parts {
		binary.BigEndian.PutUint32(l[:], uint32(len(p)))
		out = append(out, l[:]...)
		out = append(out, p...)
	}
	return out
}

// Concat is exported for the chaincode, which must reproduce the exact
// byte strings that were signed.
func Concat(parts ...[]byte) []byte { return concat(parts...) }

// randomBytes fills a buffer from crypto/rand.
func randomBytes(n int) []byte {
	b := make([]byte, n)
	if _, err := io.ReadFull(rand.Reader, b); err != nil {
		panic("cryptobench: entropy source failed: " + err.Error())
	}
	return b
}
