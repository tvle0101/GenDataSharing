package cryptobench

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/hmac"
	"crypto/sha256"
	"errors"
	"math/big"

	"github.com/cloudflare/circl/ecc/bls12381"
)

// Signcryption (SeqSignCrypt / SeqUnsignCrypt and the identical
// ShaSignCrypt / ShaUnsignCrypt), following the paper verbatim:
//
//	sigma_1 = g^s,  X = h(ctx),  sigma_2 = X^s                      (BLS12-381)
//	k = h(s || puk_S || puk_R),  C_data = SE_k(m)                   (AES-256-GCM)
//	K = s * puk_R,  b = h(K),  C_k = b XOR k                        (P-256)
//	u = hmac_k(m, K, sigma_2, puk_S, puk_R)                         (HMAC-SHA256)
//	v = s^{-1} (u + prk_S)  mod n
//
// Unsigncryption:
//
//	z = v^{-1},  L = u z * puk_R + z * puk_S * prk_R   ( = s * puk_R = K )
//	b' = h(L),  k = b' XOR C_k,  m = SD_k(C_data),  check u == hmac_k(m, L, ...)
//
// S denotes the sender (GC_s in SeqSignCrypt, DO_i in ShaSignCrypt) and R
// the receiver (DO_i, resp. DB_j).
//
// The scalar s is shared between the BLS12-381 group (order r ≈ 2^255) and
// P-256 (order n ≈ 2^256); it is drawn uniformly from [1, 2^248) so that it
// is a valid, unreduced scalar in both groups.

// Signcrypted is the paper's delta_C / delta_R.
type Signcrypted struct {
	Sigma1 *bls12381.G1 // sigma_c1 / sigma_r1
	Sigma2 *bls12381.G2 // sigma_c2 / sigma_r2
	CData  []byte       // C_data (12-byte GCM nonce || ciphertext || tag)
	CK     []byte       // C_k (32 bytes)
	U      []byte       // u (32 bytes, HMAC-SHA256 output)
	V      []byte       // v (32 bytes, big-endian mod n)
}

var p256 = elliptic.P256()

// randomSharedScalar draws s in [1, 2^248).
func randomSharedScalar() (*big.Int, *bls12381.Scalar) {
	for {
		b := randomBytes(31)
		x := new(big.Int).SetBytes(b)
		if x.Sign() == 0 {
			continue
		}
		s := new(bls12381.Scalar)
		s.SetBytes(b) // < 2^248 < r, so no reduction happens
		return x, s
	}
}

// pointBytes encodes a P-256 affine point uncompressed (65 bytes).
func pointBytes(x, y *big.Int) []byte {
	out := make([]byte, 65)
	out[0] = 4
	x.FillBytes(out[1:33])
	y.FillBytes(out[33:65])
	return out
}

func seal(k, plaintext []byte) []byte {
	blk, err := aes.NewCipher(k)
	if err != nil {
		panic(err)
	}
	gcm, err := cipher.NewGCM(blk)
	if err != nil {
		panic(err)
	}
	nonce := randomBytes(gcm.NonceSize())
	return gcm.Seal(nonce, nonce, plaintext, nil)
}

func open(k, c []byte) ([]byte, error) {
	blk, err := aes.NewCipher(k)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(blk)
	if err != nil {
		return nil, err
	}
	if len(c) < gcm.NonceSize() {
		return nil, errors.New("cryptobench: ciphertext too short")
	}
	return gcm.Open(nil, c[:gcm.NonceSize()], c[gcm.NonceSize():], nil)
}

func xor32(a, b []byte) []byte {
	out := make([]byte, 32)
	for i := range out {
		out[i] = a[i] ^ b[i]
	}
	return out
}

// Signcrypt runs the sender side.  hashInput is the pre-image of X
// (conf_s || MAC_GC || t_SeqSignCrypt for the sequencing service, conf_t
// for the sharing service).  It returns delta and the scalar s (needed by
// nothing else; exposed for tests).
func Signcrypt(senderKey *ecdsa.PrivateKey, receiverPub *ecdsa.PublicKey, m, hashInput []byte) (*Signcrypted, *bls12381.Scalar) {
	sInt, sBLS := randomSharedScalar()

	// sigma_1 = g^s, X = h(.), sigma_2 = X^s
	X := HashToG2(hashInput)
	sig := SignWithScalar(X, sBLS)

	pukS := PubBytes(&senderKey.PublicKey)
	pukR := PubBytes(receiverPub)

	// k = h(s || puk_S || puk_R)
	sBytes := make([]byte, 32)
	sInt.FillBytes(sBytes)
	kArr := sha256.Sum256(concat(sBytes, pukS, pukR))
	k := kArr[:]

	// C_data = SE_k(m)
	cData := seal(k, m)

	// K = s * puk_R, b = h(K), C_k = b XOR k
	Kx, Ky := p256.ScalarMult(receiverPub.X, receiverPub.Y, sBytes)
	K := pointBytes(Kx, Ky)
	b := sha256.Sum256(K)
	cK := xor32(b[:], k)

	// u = hmac_k(m, K, sigma_2, puk_S, puk_R)
	mac := hmac.New(sha256.New, k)
	mac.Write(concat(m, K, sig.S2.BytesCompressed(), pukS, pukR))
	u := mac.Sum(nil)

	// v = s^{-1} (u + prk_S) mod n
	n := p256.Params().N
	uInt := new(big.Int).SetBytes(u)
	uInt.Mod(uInt, n)
	t := new(big.Int).Add(uInt, senderKey.D)
	t.Mod(t, n)
	sInv := new(big.Int).ModInverse(sInt, n)
	v := new(big.Int).Mul(sInv, t)
	v.Mod(v, n)
	vBytes := make([]byte, 32)
	v.FillBytes(vBytes)

	return &Signcrypted{Sigma1: sig.S1, Sigma2: sig.S2, CData: cData, CK: cK, U: u, V: vBytes}, sBLS
}

// Unsigncrypt runs the receiver side and returns m, or an error if the
// authentication tag u does not verify (or decryption fails).
func Unsigncrypt(receiverKey *ecdsa.PrivateKey, senderPub *ecdsa.PublicKey, d *Signcrypted) ([]byte, error) {
	if d == nil || len(d.CK) != 32 || len(d.U) != 32 || len(d.V) != 32 || d.Sigma2 == nil {
		return nil, errors.New("cryptobench: malformed signcrypted message")
	}
	n := p256.Params().N
	v := new(big.Int).SetBytes(d.V)
	if v.Sign() == 0 || v.Cmp(n) >= 0 {
		return nil, errors.New("cryptobench: invalid v")
	}
	// z = v^{-1}
	z := new(big.Int).ModInverse(v, n)
	// L = (u z) * puk_R + (z * prk_R) * puk_S
	uInt := new(big.Int).SetBytes(d.U)
	uInt.Mod(uInt, n)
	uz := new(big.Int).Mul(uInt, z)
	uz.Mod(uz, n)
	zd := new(big.Int).Mul(z, receiverKey.D)
	zd.Mod(zd, n)
	uzB := make([]byte, 32)
	uz.FillBytes(uzB)
	zdB := make([]byte, 32)
	zd.FillBytes(zdB)
	ax, ay := p256.ScalarMult(receiverKey.PublicKey.X, receiverKey.PublicKey.Y, uzB)
	bx, by := p256.ScalarMult(senderPub.X, senderPub.Y, zdB)
	Lx, Ly := p256.Add(ax, ay, bx, by)
	L := pointBytes(Lx, Ly)

	// b' = h(L), k = b' XOR C_k, m = SD_k(C_data)
	bp := sha256.Sum256(L)
	k := xor32(bp[:], d.CK)
	m, err := open(k, d.CData)
	if err != nil {
		return nil, errors.New("cryptobench: decryption failed (wrong key or tampered ciphertext)")
	}

	// u ?= hmac_k(m, L, sigma_2, puk_S, puk_R)
	pukS := PubBytes(senderPub)
	pukR := PubBytes(&receiverKey.PublicKey)
	mac := hmac.New(sha256.New, k)
	mac.Write(concat(m, L, d.Sigma2.BytesCompressed(), pukS, pukR))
	if !hmac.Equal(mac.Sum(nil), d.U) {
		return nil, errors.New("cryptobench: authentication tag u mismatch")
	}
	return m, nil
}
