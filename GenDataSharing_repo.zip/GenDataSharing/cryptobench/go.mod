module github.com/tvle0101/GenDataSharing/cryptobench

go 1.22.0

toolchain go1.24.7

require github.com/cloudflare/circl v1.6.1

require (
	golang.org/x/crypto v0.11.1-0.20230711161743-2e82bdd1719d // indirect
	golang.org/x/sys v0.28.0 // indirect
)

// This build host cannot resolve golang.org/x/* import metadata, only
// github.com clones; the official GitHub mirrors of the same modules are
// used instead.  Remove these two lines on a host with normal module access.
replace golang.org/x/sys => github.com/golang/sys v0.28.0

replace golang.org/x/crypto => github.com/golang/crypto v0.31.0
