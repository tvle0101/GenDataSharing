package cryptobench

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/ecdsa"
	"crypto/sha256"
	"fmt"
	"testing"

	"github.com/cloudflare/circl/ecc/bls12381"
)

// Benchmarks for the primitive operations named in the paper
// (E1, E2, Pe, EC_s, S) and for every phase of the scheme.
// Run:  go test -run '^$' -bench . -benchtime 200x -count 5
// The names are parsed by ../tools/summarize_bench.py.

var sinkG1 bls12381.G1
var sinkG2 bls12381.G2
var sinkGt *bls12381.Gt
var sinkBool bool
var sinkBytes []byte

// ---- primitives ----

func BenchmarkPrim_E1_G1ScalarMult(b *testing.B) {
	s := RandomScalar()
	g := bls12381.G1Generator()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sinkG1.ScalarMult(s, g)
	}
}

func BenchmarkPrim_E2_G2ScalarMult(b *testing.B) {
	s := RandomScalar()
	H := HashToG2([]byte("m"))
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sinkG2.ScalarMult(s, H)
	}
}

func BenchmarkPrim_Pe_Pairing(b *testing.B) {
	_, sig := Sign(HashToG2([]byte("m")))
	H := HashToG2([]byte("m"))
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sinkGt = bls12381.Pair(sig.S1, H)
	}
}

func BenchmarkPrim_HashToG2(b *testing.B) {
	m := []byte("technique=WGS;price=500")
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sinkG2 = *HashToG2(m)
	}
}

func BenchmarkPrim_ECs_ECDSASign(b *testing.B) {
	k := GenerateKey()
	m := []byte("message")
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sinkBytes = SignECDSA(k, m)
	}
}

func BenchmarkPrim_ECs_ECDSAVerify(b *testing.B) {
	k := GenerateKey()
	m := []byte("message")
	sig := SignECDSA(k, m)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sinkBool = VerifyECDSA(&k.PublicKey, sig, m)
	}
}

func BenchmarkPrim_P256ScalarMult(b *testing.B) {
	k := GenerateKey()
	s := randomBytes(32)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		p256.ScalarMult(k.PublicKey.X, k.PublicKey.Y, s)
	}
}

func BenchmarkPrim_S_AESGCM_1MB(b *testing.B) {
	key := sha256.Sum256([]byte("k"))
	blk, _ := aes.NewCipher(key[:])
	gcm, _ := cipher.NewGCM(blk)
	nonce := make([]byte, 12)
	m := bytes.Repeat([]byte("ACGT"), 1<<18) // 1 MiB
	out := make([]byte, 0, len(m)+16)
	b.SetBytes(int64(len(m)))
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sinkBytes = gcm.Seal(out[:0], nonce, m, nil)
	}
}

// ---- sequencing-service phases ----

var (
	benchAlphaK = []byte("technique=WGS;price=500")
	benchConfS  = []byte("conf_s-0001")
)

func BenchmarkPhase_SeqPriAcc(b *testing.B) {
	do := GenerateKey()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = SeqPriAcc(benchAlphaK, do, "mac-do", "t1")
	}
}

func BenchmarkPhase_SeqPriCfm(b *testing.B) {
	do, gc := GenerateKey(), GenerateKey()
	a := SeqPriAcc(benchAlphaK, do, "mac-do", "t1")
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if _, err := SeqPriCfm(a, &do.PublicKey, gc, "mac-gc", "t2"); err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkPhase_SeqPriVer(b *testing.B) {
	do, gc := GenerateKey(), GenerateKey()
	a := SeqPriAcc(benchAlphaK, do, "mac-do", "t1")
	sb, _ := SeqPriCfm(a, &do.PublicKey, gc, "mac-gc", "t2")
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if err := SeqPriVer(sb, &gc.PublicKey); err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkPhase_SeqPriVer_PairingOnlyFast(b *testing.B) {
	do, gc := GenerateKey(), GenerateKey()
	a := SeqPriAcc(benchAlphaK, do, "mac-do", "t1")
	sb, _ := SeqPriCfm(a, &do.PublicKey, gc, "mac-gc", "t2")
	H := HashToG2(benchAlphaK)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sinkBool = VerifyFast(H, sb.Sig)
	}
}

func batchSetup(n int) ([]*SigmaA, []*ecdsa.PublicKey, *ecdsa.PrivateKey) {
	gc := GenerateKey()
	as := make([]*SigmaA, n)
	puks := make([]*ecdsa.PublicKey, n)
	for i := 0; i < n; i++ {
		k := GenerateKey()
		as[i] = SeqPriAcc(benchAlphaK, k, "mac-do", "t1")
		puks[i] = &k.PublicKey
	}
	return as, puks, gc
}

// Batch sign (Remark 1): GC checks n ECDSA wrappers, aggregates n
// contributions, adds its own, signs once.
func BenchmarkBatch_SeqPriCfmBatch(b *testing.B) {
	for _, n := range []int{1, 10, 50, 100} {
		as, puks, gc := batchSetup(n)
		b.Run(fmt.Sprintf("n=%d", n), func(b *testing.B) {
			for i := 0; i < b.N; i++ {
				if _, err := SeqPriCfmBatch(as, puks, gc, "mac-gc", "t2"); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}

// Batch verify (Remark 1): one ECDSA check + one pairing equation
// regardless of n.
func BenchmarkBatch_SeqPriVerBatch(b *testing.B) {
	for _, n := range []int{1, 10, 50, 100} {
		as, puks, gc := batchSetup(n)
		sb, err := SeqPriCfmBatch(as, puks, gc, "mac-gc", "t2")
		if err != nil {
			b.Fatal(err)
		}
		b.Run(fmt.Sprintf("n=%d", n), func(b *testing.B) {
			for i := 0; i < b.N; i++ {
				if err := SeqPriVer(sb, &gc.PublicKey); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}

// Reference: verifying the n signatures one by one (n ECDSA + n pairing
// equations), to quantify the saving of Remark 1.
func BenchmarkBatch_NaiveVerify(b *testing.B) {
	for _, n := range []int{1, 10, 50, 100} {
		as, puks, gc := batchSetup(n)
		sbs := make([]*SigmaB, n)
		for i := range as {
			sbs[i], _ = SeqPriCfm(as[i], puks[i], gc, "mac-gc", "t2")
		}
		b.Run(fmt.Sprintf("n=%d", n), func(b *testing.B) {
			for i := 0; i < b.N; i++ {
				for _, sb := range sbs {
					if err := SeqPriVer(sb, &gc.PublicKey); err != nil {
						b.Fatal(err)
					}
				}
			}
		})
	}
}

func signcryptSetup(size int) ([]byte, []byte, *ecdsa.PrivateKey, *ecdsa.PrivateKey) {
	gd := bytes.Repeat([]byte("ACGT"), size/4)
	pd := []byte("phenotype: xyz")
	return gd, pd, GenerateKey(), GenerateKey()
}

func BenchmarkPhase_SeqSignCrypt(b *testing.B) {
	for _, size := range []int{1 << 10, 1 << 20} {
		gd, pd, gc, do := signcryptSetup(size)
		b.Run(fmt.Sprintf("payload=%dB", size), func(b *testing.B) {
			for i := 0; i < b.N; i++ {
				_ = SeqSignCrypt(gd, pd, benchConfS, gc, &do.PublicKey, "mac-gc", "t3")
			}
		})
	}
}

func BenchmarkPhase_SeqUnsignCrypt(b *testing.B) {
	for _, size := range []int{1 << 10, 1 << 20} {
		gd, pd, gc, do := signcryptSetup(size)
		dc := SeqSignCrypt(gd, pd, benchConfS, gc, &do.PublicKey, "mac-gc", "t3")
		b.Run(fmt.Sprintf("payload=%dB", size), func(b *testing.B) {
			for i := 0; i < b.N; i++ {
				if _, _, _, err := SeqUnsignCrypt(dc, do, &gc.PublicKey, "mac-do", "t4"); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}

func BenchmarkPhase_SeqTxnFin(b *testing.B) {
	gd, pd, gc, do := signcryptSetup(1 << 10)
	dc := SeqSignCrypt(gd, pd, benchConfS, gc, &do.PublicKey, "mac-gc", "t3")
	_, _, d, err := SeqUnsignCrypt(dc, do, &gc.PublicKey, "mac-do", "t4")
	if err != nil {
		b.Fatal(err)
	}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if err := SeqTxnFin(d, &do.PublicKey, "mac-gc", "t3"); err != nil {
			b.Fatal(err)
		}
	}
}

// ---- data-sharing phases (same arithmetic; measured for completeness) ----

func BenchmarkPhase_ShaPriVer(b *testing.B) {
	do, db := GenerateKey(), GenerateKey()
	e := ShaPriSet([]byte("price=50"), do, "mac-do", "t1")
	f, _ := ShaPriAcc(e, &do.PublicKey, db, "mac-db", "t2")
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if err := ShaPriVer(f, &db.PublicKey); err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkPhase_ShaTxnFin(b *testing.B) {
	do, db := GenerateKey(), GenerateKey()
	r := ShaSignCrypt(bytes.Repeat([]byte("ACGT"), 256), []byte("conf_t"), do, &db.PublicKey, "mac-do", "t3")
	_, w, err := ShaUnsignCrypt(r, db, &do.PublicKey, "mac-db", "t4")
	if err != nil {
		b.Fatal(err)
	}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if err := ShaTxnFin(w, &db.PublicKey); err != nil {
			b.Fatal(err)
		}
	}
}
