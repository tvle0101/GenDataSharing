package cryptobench

import (
	"crypto/ecdsa"
	"errors"

	"github.com/cloudflare/circl/ecc/bls12381"
)

// This file implements the phases of Section "Proposed Cryptographic
// Scheme" with the paper's names.  The sharing-service algorithms
// (ShaPriSet, ShaPriAcc, ShaPriVer, ShaSignCrypt, ShaUnsignCrypt,
// ShaTxnFin) are structurally identical to the sequencing-service ones with
// the roles (DO_i, GC_s) replaced by (DO_i, DB_j) and (alpha_k, conf_s,
// MAC_GC || t) replaced by (delta_k, conf_t); they are therefore thin
// wrappers over the same code so that both services provably run the same
// arithmetic.

// ---------------------------------------------------------------------
// Genomic sequencing service
// ---------------------------------------------------------------------

// SigmaA is sigma_A = {alpha_k, sigma_a1, sigma_a2, sigma_SeqPriAcc, MAC_DO, t_SeqPriAcc}.
type SigmaA struct {
	AlphaK         []byte
	Sig            *AggSig // sigma_a1, sigma_a2
	SigmaSeqPriAcc []byte  // ECDSA by DO over (sigma_a2, MAC_DO, t_SeqPriAcc)
	MACDO          string
	TSeqPriAcc     string
}

// SigmaB is sigma_B = {alpha_k, sigma_b1, sigma_b2, sigma_SeqPriCfm, MAC_GC, t_SeqPriCfm}
// plus sigma_SeqPriAcc, which SeqPriVer needs in order to recompute the
// signed tuple (sigma_b2, sigma_SeqPriAcc, MAC_GC, t_SeqPriCfm).
type SigmaB struct {
	AlphaK         []byte
	Sig            *AggSig // sigma_b1, sigma_b2
	SigmaSeqPriAcc []byte
	SigmaSeqPriCfm []byte // ECDSA by GC over (sigma_b2, sigma_SeqPriAcc, MAC_GC, t_SeqPriCfm)
	MACGC          string
	TSeqPriCfm     string
}

// SeqPriAcc(alpha_k, PuK), run by DO_i:
// sigma_a1 = g^{s_a}, H = h(alpha_k), sigma_a2 = H^{s_a},
// sigma_SeqPriAcc = Sig_prk_DO(sigma_a2, MAC_DO, t_SeqPriAcc).
func SeqPriAcc(alphaK []byte, prkDO *ecdsa.PrivateKey, macDO, t string) *SigmaA {
	H := HashToG2(alphaK)
	_, sig := Sign(H)
	wrap := SignECDSA(prkDO, sig.S2.BytesCompressed(), []byte(macDO), []byte(t))
	return &SigmaA{AlphaK: alphaK, Sig: sig, SigmaSeqPriAcc: wrap, MACDO: macDO, TSeqPriAcc: t}
}

// SeqPriCfm(sigma_A, PuK), run by GC_s: checks sigma_SeqPriAcc with puk_DO,
// then sigma_b1 = sigma_a1 g^{s_b}, sigma_b2 = sigma_a2 H^{s_b},
// sigma_SeqPriCfm = Sig_prk_GC(sigma_b2, sigma_SeqPriAcc, MAC_GC, t_SeqPriCfm).
func SeqPriCfm(a *SigmaA, pukDO *ecdsa.PublicKey, prkGC *ecdsa.PrivateKey, macGC, t string) (*SigmaB, error) {
	if !VerifyECDSA(pukDO, a.SigmaSeqPriAcc, a.Sig.S2.BytesCompressed(), []byte(a.MACDO), []byte(a.TSeqPriAcc)) {
		return nil, errors.New("SeqPriCfm: sigma_SeqPriAcc does not verify under puk_DO")
	}
	H := HashToG2(a.AlphaK)
	_, agg := AggregateSign(H, a.Sig)
	wrap := SignECDSA(prkGC, agg.S2.BytesCompressed(), a.SigmaSeqPriAcc, []byte(macGC), []byte(t))
	return &SigmaB{AlphaK: a.AlphaK, Sig: agg, SigmaSeqPriAcc: a.SigmaSeqPriAcc, SigmaSeqPriCfm: wrap, MACGC: macGC, TSeqPriCfm: t}, nil
}

// SeqPriCfmBatch is Remark 1: n data owners submitted sigma_A_i for the
// same alpha_k; GC_s checks each ECDSA wrapper, then forms
// sigma_b1 = prod sigma_a1_i * g^{s_b}, sigma_b2 = prod sigma_a2_i * H^{s_b}
// and signs once.  sigma_SeqPriAcc in the output is the concatenation of
// the n wrappers (so that the GC's signature still binds all of them).
func SeqPriCfmBatch(as []*SigmaA, pukDOs []*ecdsa.PublicKey, prkGC *ecdsa.PrivateKey, macGC, t string) (*SigmaB, error) {
	if len(as) == 0 || len(as) != len(pukDOs) {
		return nil, errors.New("SeqPriCfmBatch: bad input sizes")
	}
	alphaK := as[0].AlphaK
	sigs := make([]*AggSig, 0, len(as)+1)
	wrappers := make([][]byte, 0, len(as))
	for i, a := range as {
		if string(a.AlphaK) != string(alphaK) {
			return nil, errors.New("SeqPriCfmBatch: all alpha_k must be equal for batching")
		}
		if !VerifyECDSA(pukDOs[i], a.SigmaSeqPriAcc, a.Sig.S2.BytesCompressed(), []byte(a.MACDO), []byte(a.TSeqPriAcc)) {
			return nil, errors.New("SeqPriCfmBatch: a sigma_SeqPriAcc does not verify")
		}
		sigs = append(sigs, a.Sig)
		wrappers = append(wrappers, a.SigmaSeqPriAcc)
	}
	H := HashToG2(alphaK)
	_, mine := Sign(H)
	sigs = append(sigs, mine)
	agg := Aggregate(sigs...)
	allWrappers := concat(wrappers...)
	wrap := SignECDSA(prkGC, agg.S2.BytesCompressed(), allWrappers, []byte(macGC), []byte(t))
	return &SigmaB{AlphaK: alphaK, Sig: agg, SigmaSeqPriAcc: allWrappers, SigmaSeqPriCfm: wrap, MACGC: macGC, TSeqPriCfm: t}, nil
}

// SeqPriVer(sigma_B, PuK), run by GSC: checks sigma_SeqPriCfm with puk_GC,
// then H = h(alpha_k) and e(H, sigma_b1) == e(sigma_b2, g).
// This is the function the chaincode executes on every endorsing peer.
func SeqPriVer(b *SigmaB, pukGC *ecdsa.PublicKey) error {
	if !VerifyECDSA(pukGC, b.SigmaSeqPriCfm, b.Sig.S2.BytesCompressed(), b.SigmaSeqPriAcc, []byte(b.MACGC), []byte(b.TSeqPriCfm)) {
		return errors.New("SeqPriVer: sigma_SeqPriCfm does not verify under puk_GC")
	}
	H := HashToG2(b.AlphaK)
	if !Verify(H, b.Sig) {
		return errors.New("SeqPriVer: pairing check e(H, sigma_b1) == e(sigma_b2, g) failed")
	}
	return nil
}

// DeltaC is delta_C = {sigma_c1, sigma_c2, C_data_s, C_k, u_s, v_s, MAC_GC, t_SeqSignCrypt}.
type DeltaC struct {
	*Signcrypted
	ConfS          []byte
	MACGC          string
	TSeqSignCrypt  string
}

// SeqSignCrypt(GD_i, PD_i, conf_s, PuK), run by GC_s with
// X = h(conf_s || MAC_GC || t_SeqSignCrypt) and m_s = {GD_i, PD_i, conf_s}.
func SeqSignCrypt(gd, pd, confS []byte, prkGC *ecdsa.PrivateKey, pukDO *ecdsa.PublicKey, macGC, t string) *DeltaC {
	m := concat(gd, pd, confS)
	x := concat(confS, []byte(macGC), []byte(t))
	sc, _ := Signcrypt(prkGC, pukDO, m, x)
	return &DeltaC{Signcrypted: sc, ConfS: confS, MACGC: macGC, TSeqSignCrypt: t}
}

// SigmaD is sigma_D = {conf_s, sigma_d1, sigma_d2, sigma_conf_s, MAC_DO, t_conf_s}.
type SigmaD struct {
	ConfS      []byte
	Sig        *AggSig // sigma_d1, sigma_d2
	SigmaConfS []byte  // ECDSA by DO over (sigma_d2, MAC_DO, t_conf_s)
	MACDO      string
	TConfS     string
}

// SeqUnsignCrypt(delta_C, PuK), run by DO_i: recovers m_s and, if the
// tag verifies, produces sigma_d1 = sigma_c1 g^{s_d}, sigma_d2 = sigma_c2 X^{s_d},
// sigma_conf_s = Sig_prk_DO(sigma_d2, MAC_DO, t_conf_s).  It returns the
// recovered (GD_i, PD_i) and sigma_D.
func SeqUnsignCrypt(d *DeltaC, prkDO *ecdsa.PrivateKey, pukGC *ecdsa.PublicKey, macDO, tConfS string) (gd, pd []byte, out *SigmaD, err error) {
	m, err := Unsigncrypt(prkDO, pukGC, d.Signcrypted)
	if err != nil {
		return nil, nil, nil, err
	}
	parts, err := split(m, 3)
	if err != nil {
		return nil, nil, nil, err
	}
	x := concat(d.ConfS, []byte(d.MACGC), []byte(d.TSeqSignCrypt))
	X := HashToG2(x)
	_, agg := AggregateSign(X, &AggSig{S1: d.Sigma1, S2: d.Sigma2})
	wrap := SignECDSA(prkDO, agg.S2.BytesCompressed(), []byte(macDO), []byte(tConfS))
	return parts[0], parts[1], &SigmaD{ConfS: d.ConfS, Sig: agg, SigmaConfS: wrap, MACDO: macDO, TConfS: tConfS}, nil
}

// SeqTxnFin(sigma_D, PuK), run by GSC: checks sigma_conf_s with puk_DO,
// then X = h(conf_s || MAC_GC || t_SeqSignCrypt) and e(X, sigma_d1) == e(sigma_d2, g).
// MAC_GC and t_SeqSignCrypt come from the GC side (on-chain record / delta_C).
func SeqTxnFin(d *SigmaD, pukDO *ecdsa.PublicKey, macGC, tSeqSignCrypt string) error {
	if !VerifyECDSA(pukDO, d.SigmaConfS, d.Sig.S2.BytesCompressed(), []byte(d.MACDO), []byte(d.TConfS)) {
		return errors.New("SeqTxnFin: sigma_conf_s does not verify under puk_DO")
	}
	X := HashToG2(concat(d.ConfS, []byte(macGC), []byte(tSeqSignCrypt)))
	if !Verify(X, d.Sig) {
		return errors.New("SeqTxnFin: pairing check e(X, sigma_d1) == e(sigma_d2, g) failed")
	}
	return nil
}

// ---------------------------------------------------------------------
// Data sharing service (same arithmetic, roles DO_i -> DB_j)
// ---------------------------------------------------------------------

// SigmaE = {delta_k, sigma_e1, sigma_e2, sigma_ShaPriSet, MAC_DO, t_ShaPriSet}.
type SigmaE = SigmaA

// SigmaF = {delta_k, sigma_f1, sigma_f2, sigma_ShaPriAcc, MAC_DB, t_ShaPriAcc} (+ sigma_ShaPriSet).
type SigmaF = SigmaB

// ShaPriSet(delta_k, PuK), run by DO_i.
func ShaPriSet(deltaK []byte, prkDO *ecdsa.PrivateKey, macDO, t string) *SigmaE {
	return SeqPriAcc(deltaK, prkDO, macDO, t)
}

// ShaPriAcc(sigma_E, PuK), run by DB_j.
func ShaPriAcc(e *SigmaE, pukDO *ecdsa.PublicKey, prkDB *ecdsa.PrivateKey, macDB, t string) (*SigmaF, error) {
	return SeqPriCfm(e, pukDO, prkDB, macDB, t)
}

// ShaPriAccBatch is Remark 2 (n owners, one delta_k).
func ShaPriAccBatch(es []*SigmaE, pukDOs []*ecdsa.PublicKey, prkDB *ecdsa.PrivateKey, macDB, t string) (*SigmaF, error) {
	return SeqPriCfmBatch(es, pukDOs, prkDB, macDB, t)
}

// ShaPriVer(sigma_F, PuK), run by DSC: checks sigma_ShaPriAcc with puk_DB,
// Y = h(delta_k), e(Y, sigma_f1) == e(sigma_f2, g).
func ShaPriVer(f *SigmaF, pukDB *ecdsa.PublicKey) error {
	return SeqPriVer(f, pukDB)
}

// DeltaR = {sigma_r1, sigma_r2, C_data_t, C_l, u_t, v_t} with conf_t.
type DeltaR struct {
	*Signcrypted
	ConfT []byte
}

// ShaSignCrypt(GD_i, conf_t, PuK), run by DO_i, Z = h(conf_t),
// m_t = {GD_i, conf_t, MAC_DO, t_ShaSignCrypt}.
func ShaSignCrypt(gd, confT []byte, prkDO *ecdsa.PrivateKey, pukDB *ecdsa.PublicKey, macDO, t string) *DeltaR {
	m := concat(gd, confT, []byte(macDO), []byte(t))
	sc, _ := Signcrypt(prkDO, pukDB, m, confT)
	return &DeltaR{Signcrypted: sc, ConfT: confT}
}

// SigmaW = {conf_t, sigma_w1, sigma_w2, sigma_conf_t, MAC_DB, t_conf_t}.
type SigmaW = SigmaD

// ShaUnsignCrypt(delta_R, PuK), run by DB_j; returns GD_i and sigma_W.
func ShaUnsignCrypt(r *DeltaR, prkDB *ecdsa.PrivateKey, pukDO *ecdsa.PublicKey, macDB, tConfT string) (gd []byte, out *SigmaW, err error) {
	m, err := Unsigncrypt(prkDB, pukDO, r.Signcrypted)
	if err != nil {
		return nil, nil, err
	}
	parts, err := split(m, 4)
	if err != nil {
		return nil, nil, err
	}
	Z := HashToG2(r.ConfT)
	_, agg := AggregateSign(Z, &AggSig{S1: r.Sigma1, S2: r.Sigma2})
	wrap := SignECDSA(prkDB, agg.S2.BytesCompressed(), []byte(macDB), []byte(tConfT))
	return parts[0], &SigmaW{ConfS: r.ConfT, Sig: agg, SigmaConfS: wrap, MACDO: macDB, TConfS: tConfT}, nil
}

// ShaTxnFin(sigma_W, PuK), run by DSC: checks sigma_conf_t with puk_DB,
// Z = h(conf_t), e(Z, sigma_w1) == e(sigma_w2, g).
func ShaTxnFin(w *SigmaW, pukDB *ecdsa.PublicKey) error {
	if !VerifyECDSA(pukDB, w.SigmaConfS, w.Sig.S2.BytesCompressed(), []byte(w.MACDO), []byte(w.TConfS)) {
		return errors.New("ShaTxnFin: sigma_conf_t does not verify under puk_DB")
	}
	Z := HashToG2(w.ConfS)
	if !Verify(Z, w.Sig) {
		return errors.New("ShaTxnFin: pairing check e(Z, sigma_w1) == e(sigma_w2, g) failed")
	}
	return nil
}

// ---------------------------------------------------------------------

// split inverts concat for a known number of parts.
func split(b []byte, n int) ([][]byte, error) {
	out := make([][]byte, 0, n)
	for i := 0; i < n; i++ {
		if len(b) < 4 {
			return nil, errors.New("cryptobench: malformed message")
		}
		l := int(uint32(b[0])<<24 | uint32(b[1])<<16 | uint32(b[2])<<8 | uint32(b[3]))
		b = b[4:]
		if len(b) < l {
			return nil, errors.New("cryptobench: malformed message")
		}
		out = append(out, b[:l])
		b = b[l:]
	}
	if len(b) != 0 {
		return nil, errors.New("cryptobench: trailing bytes in message")
	}
	return out, nil
}

// Scalar re-exports the group scalar type for callers.
type Scalar = bls12381.Scalar
