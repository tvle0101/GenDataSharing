package cryptobench

import (
	"crypto/ecdh"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"math/big"
)

// The conventional signature Sig_prk(.) of the paper is ECDSA over NIST
// P-256 (secp256r1) with SHA-256, ASN.1/DER-encoded (r, s).  The same key
// pair is used by an entity for ECDSA and for the EC signcryption, so that
// puk_DO, puk_GC, puk_DB are single P-256 public keys as in the paper's PuK.

// GenerateKey creates a P-256 key pair.
func GenerateKey() *ecdsa.PrivateKey {
	k, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		panic("cryptobench: key generation failed: " + err.Error())
	}
	return k
}

// SignECDSA signs SHA-256(concat(parts...)) with prk.  The parts are the
// tuple written in the paper, e.g. Sig_prk_DO(sigma_a2, MAC_DO, t) is
// SignECDSA(prkDO, sigmaA2Bytes, []byte(macDO), []byte(t)).
func SignECDSA(prk *ecdsa.PrivateKey, parts ...[]byte) []byte {
	d := sha256.Sum256(concat(parts...))
	sig, err := ecdsa.SignASN1(rand.Reader, prk, d[:])
	if err != nil {
		panic("cryptobench: ECDSA signing failed: " + err.Error())
	}
	return sig
}

// VerifyECDSA checks an ECDSA signature produced by SignECDSA.
func VerifyECDSA(puk *ecdsa.PublicKey, sig []byte, parts ...[]byte) bool {
	if puk == nil || len(sig) == 0 {
		return false
	}
	d := sha256.Sum256(concat(parts...))
	return ecdsa.VerifyASN1(puk, d[:], sig)
}

// PubBytes returns the uncompressed SEC1 encoding (65 bytes, 0x04||X||Y).
func PubBytes(puk *ecdsa.PublicKey) []byte {
	ek, err := puk.ECDH()
	if err != nil {
		panic("cryptobench: public key not on P-256: " + err.Error())
	}
	return ek.Bytes()
}

// PubHex is the hex form of PubBytes, the format the chaincode registry
// stores.
func PubHex(puk *ecdsa.PublicKey) string { return hex.EncodeToString(PubBytes(puk)) }

// ParsePub decodes an uncompressed P-256 public key, validating that the
// point is on the curve (crypto/ecdh performs the check).
func ParsePub(b []byte) (*ecdsa.PublicKey, error) {
	if _, err := ecdh.P256().NewPublicKey(b); err != nil {
		return nil, errors.New("cryptobench: invalid P-256 public key: " + err.Error())
	}
	// 0x04 || X (32) || Y (32), already validated above.
	return &ecdsa.PublicKey{
		Curve: elliptic.P256(),
		X:     new(big.Int).SetBytes(b[1:33]),
		Y:     new(big.Int).SetBytes(b[33:65]),
	}, nil
}

// ParsePubHex is ParsePub on a hex string.
func ParsePubHex(s string) (*ecdsa.PublicKey, error) {
	b, err := hex.DecodeString(s)
	if err != nil {
		return nil, errors.New("cryptobench: public key is not hex")
	}
	return ParsePub(b)
}
