# Measured cryptographic unit and phase costs

CPU: Intel(R) Xeon(R) Processor @ 2.10GHz; Go 1.24.7; curve BLS12-381 (circl v1.6.1), ECDSA P-256, AES-256-GCM. Command: `go test -bench . -count=5 -run '^$' ./cryptobench`; values are mean ± population std of the 5 runs (each run is Go's auto-scaled ns/op).

| Benchmark | mean ms | std ms |
|---|---|---|
| BenchmarkPrim_E1_G1ScalarMult | 0.2270 | 0.0083 |
| BenchmarkPrim_E2_G2ScalarMult | 0.6911 | 0.0247 |
| BenchmarkPrim_Pe_Pairing | 1.4704 | 0.0712 |
| BenchmarkPrim_HashToG2 | 0.6864 | 0.0239 |
| BenchmarkPrim_ECs_ECDSASign | 0.0375 | 0.0002 |
| BenchmarkPrim_ECs_ECDSAVerify | 0.0814 | 0.0041 |
| BenchmarkPrim_P256ScalarMult | 0.0611 | 0.0024 |
| BenchmarkPrim_S_AESGCM_1MB | 0.2331 | 0.0046 |
| BenchmarkPhase_SeqPriAcc | 1.8659 | 0.0709 |
| BenchmarkPhase_SeqPriCfm | 2.1689 | 0.1705 |
| BenchmarkPhase_SeqPriVer | 5.4856 | 1.6691 |
| BenchmarkPhase_SeqPriVer_PairingOnlyFast | 3.8433 | 0.3662 |
| BenchmarkBatch_SeqPriCfmBatch/n=1 | 2.5574 | 0.5598 |
| BenchmarkBatch_SeqPriCfmBatch/n=10 | 3.0596 | 0.2447 |
| BenchmarkBatch_SeqPriCfmBatch/n=50 | 8.3236 | 0.9180 |
| BenchmarkBatch_SeqPriCfmBatch/n=100 | 14.5303 | 1.1859 |
| BenchmarkBatch_SeqPriVerBatch/n=1 | 4.0142 | 0.1597 |
| BenchmarkBatch_SeqPriVerBatch/n=10 | 4.0822 | 0.3021 |
| BenchmarkBatch_SeqPriVerBatch/n=50 | 4.4724 | 0.1463 |
| BenchmarkBatch_SeqPriVerBatch/n=100 | 4.1370 | 0.2202 |
| BenchmarkBatch_NaiveVerify/n=1 | 4.4418 | 0.1427 |
| BenchmarkBatch_NaiveVerify/n=10 | 39.0172 | 1.4348 |
| BenchmarkBatch_NaiveVerify/n=50 | 210.0073 | 14.4585 |
| BenchmarkBatch_NaiveVerify/n=100 | 443.2719 | 52.4028 |
| BenchmarkPhase_SeqSignCrypt/payload=1024B | 1.8348 | 0.1481 |
| BenchmarkPhase_SeqSignCrypt/payload=1048576B | 4.4830 | 0.3769 |
| BenchmarkPhase_SeqUnsignCrypt/payload=1024B | 2.1344 | 0.1369 |
| BenchmarkPhase_SeqUnsignCrypt/payload=1048576B | 3.9561 | 0.2326 |
| BenchmarkPhase_SeqTxnFin | 3.7041 | 0.1002 |
| BenchmarkPhase_ShaPriVer | 3.8429 | 0.2710 |
| BenchmarkPhase_ShaTxnFin | 3.8701 | 0.2393 |

## Mapping to the paper's symbols (Table III)

| Symbol | Operation | ms |
|---|---|---|
| E1 | scalar multiplication in G1 | 0.227 |
| E2 | scalar multiplication in G2 | 0.691 |
| Pe | pairing | 1.470 |
| h(.) to G2 | hash-to-curve (RFC 9380) | 0.686 |
| EC_s | ECDSA P-256 verify (sign 0.037) | 0.081 |
| S | AES-256-GCM, 1 MB | 0.233 |

Symbolic totals of Table III evaluated with these constants: ours 5E1+2S = 1.135 + 2S ms; Zhang et al. 3E1 = 0.681 ms; Le et al. (4c+1)E1+E2+(2Ku+1)Pe+(Ku+2)E2 = 0.908c + 3.631Ku + 3.770 ms; Li et al. = i × (0.908c + 3.631Ku + 3.770 + 2S) ms.

The previous manuscript used Pe≈28.282, E1≈15.142, E2≈15.172 ms ('type-A curve, 128-bit') from an unknown source; those constants are withdrawn. Note that the symbolic counts omit hash-to-G2 and the G2 operation of the asymmetric instantiation, which is why measured phase costs (e.g. SeqSignCrypt+SeqUnsignCrypt = 3.97 ms at 1 kB) exceed the symbolic totals.