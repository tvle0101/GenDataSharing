package cryptobench

import (
	"bytes"
	"crypto/ecdsa"
	"testing"

	"github.com/cloudflare/circl/ecc/bls12381"
)

func TestAggSigVerifyAndTamper(t *testing.T) {
	H := HashToG2([]byte("alpha_k: WGS 30x, 500 genocoin"))
	_, sig := Sign(H)
	if !Verify(H, sig) {
		t.Fatal("valid signature rejected")
	}
	if !VerifyFast(H, sig) {
		t.Fatal("valid signature rejected by VerifyFast")
	}
	// wrong message
	if Verify(HashToG2([]byte("alpha_k: WGS 30x, 400 genocoin")), sig) {
		t.Fatal("signature accepted under a different alpha_k")
	}
	// tampered sigma_2
	bad := &AggSig{S1: sig.S1, S2: new(bls12381.G2)}
	bad.S2.ScalarMult(RandomScalar(), H)
	if Verify(H, bad) || VerifyFast(H, bad) {
		t.Fatal("tampered sigma_2 accepted")
	}
	// tampered sigma_1
	bad = &AggSig{S1: new(bls12381.G1), S2: sig.S2}
	bad.S1.Add(sig.S1, bls12381.G1Generator())
	if Verify(H, bad) {
		t.Fatal("tampered sigma_1 accepted")
	}
	// identity sigma_1 (vacuous) must be rejected
	id := &AggSig{S1: new(bls12381.G1), S2: new(bls12381.G2)}
	id.S1.SetIdentity()
	id.S2.SetIdentity()
	if Verify(H, id) {
		t.Fatal("identity signature accepted")
	}
	// round trip through the wire encoding + subgroup check
	s1, s2 := sig.Bytes()
	if len(s1) != G1Size || len(s2) != G2Size {
		t.Fatalf("unexpected sizes %d %d", len(s1), len(s2))
	}
	parsed, err := ParseAggSig(s1, s2)
	if err != nil || !Verify(H, parsed) {
		t.Fatal("parsed signature does not verify")
	}
	s2[5] ^= 1
	if _, err := ParseAggSig(s1, s2); err == nil {
		// a bit flip may still decode to a curve point; it must then fail Verify
		p, _ := ParseAggSig(s1, s2)
		if Verify(H, p) {
			t.Fatal("bit-flipped sigma_2 verified")
		}
	}
}

func TestBatchVerify(t *testing.T) {
	for _, n := range []int{1, 10, 100} {
		alphaK := []byte("alpha_k shared by all users")
		gc := GenerateKey()
		as := make([]*SigmaA, n)
		puks := make([]*ecdsa.PublicKey, n)
		for i := 0; i < n; i++ {
			k := GenerateKey()
			as[i] = SeqPriAcc(alphaK, k, "aa:bb:cc:dd:ee:01", "2026-10-27T00:00:00Z")
			puks[i] = &k.PublicKey
		}
		b, err := SeqPriCfmBatch(as, puks, gc, "aa:bb:cc:dd:ee:ff", "2026-10-27T00:00:01Z")
		if err != nil {
			t.Fatalf("n=%d: %v", n, err)
		}
		if err := SeqPriVer(b, &gc.PublicKey); err != nil {
			t.Fatalf("n=%d: batch verification failed: %v", n, err)
		}
		// drop one user's contribution from sigma_b1 -> must fail
		if n > 1 {
			bad := *b
			bad.Sig = &AggSig{S1: new(bls12381.G1), S2: b.Sig.S2}
			neg := *as[0].Sig.S1
			neg.Neg()
			bad.Sig.S1.Add(b.Sig.S1, &neg)
			if Verify(HashToG2(alphaK), bad.Sig) {
				t.Fatalf("n=%d: incomplete aggregate accepted", n)
			}
		}
		// wrong GC key for the wrapper
		other := GenerateKey()
		if err := SeqPriVer(b, &other.PublicKey); err == nil {
			t.Fatalf("n=%d: wrapper accepted under wrong puk_GC", n)
		}
	}
}

func TestSequencingServiceEndToEnd(t *testing.T) {
	do, gc := GenerateKey(), GenerateKey()
	alphaK := []byte("technique=WGS;price=500")
	a := SeqPriAcc(alphaK, do, "mac-do", "t1")
	b, err := SeqPriCfm(a, &do.PublicKey, gc, "mac-gc", "t2")
	if err != nil {
		t.Fatal(err)
	}
	if err := SeqPriVer(b, &gc.PublicKey); err != nil {
		t.Fatal(err)
	}
	// tampered alpha_k after signing
	bad := *b
	bad.AlphaK = []byte("technique=WGS;price=1")
	if err := SeqPriVer(&bad, &gc.PublicKey); err == nil {
		t.Fatal("tampered alpha_k accepted")
	}
	// forged wrapper from an impostor DO must be rejected by GC
	imp := GenerateKey()
	a2 := SeqPriAcc(alphaK, imp, "mac-do", "t1")
	if _, err := SeqPriCfm(a2, &do.PublicKey, gc, "mac-gc", "t2"); err == nil {
		t.Fatal("impostor sigma_SeqPriAcc accepted")
	}

	gd := bytes.Repeat([]byte("ACGT"), 256) // 1 KiB
	pd := []byte("phenotype: xyz")
	confS := []byte("conf_s-0001")
	dc := SeqSignCrypt(gd, pd, confS, gc, &do.PublicKey, "mac-gc", "t3")
	gd2, pd2, d, err := SeqUnsignCrypt(dc, do, &gc.PublicKey, "mac-do", "t4")
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(gd, gd2) || !bytes.Equal(pd, pd2) {
		t.Fatal("unsigncrypt did not recover the plaintext")
	}
	if err := SeqTxnFin(d, &do.PublicKey, "mac-gc", "t3"); err != nil {
		t.Fatal(err)
	}
	// wrong t_SeqSignCrypt -> X differs -> pairing fails
	if err := SeqTxnFin(d, &do.PublicKey, "mac-gc", "t9"); err == nil {
		t.Fatal("SeqTxnFin accepted wrong X pre-image")
	}
	// wrong receiver cannot unsigncrypt
	other := GenerateKey()
	if _, _, _, err := SeqUnsignCrypt(dc, other, &gc.PublicKey, "mac-do", "t4"); err == nil {
		t.Fatal("unsigncrypt succeeded with the wrong private key")
	}
	// tampered ciphertext
	dc2 := *dc
	sc := *dc.Signcrypted
	sc.CData = append([]byte{}, dc.CData...)
	sc.CData[len(sc.CData)/2] ^= 0x80
	dc2.Signcrypted = &sc
	if _, _, _, err := SeqUnsignCrypt(&dc2, do, &gc.PublicKey, "mac-do", "t4"); err == nil {
		t.Fatal("tampered ciphertext accepted")
	}
	// tampered u (sender forgery attempt)
	sc2 := *dc.Signcrypted
	sc2.U = append([]byte{}, dc.U...)
	sc2.U[0] ^= 1
	dc3 := *dc
	dc3.Signcrypted = &sc2
	if _, _, _, err := SeqUnsignCrypt(&dc3, do, &gc.PublicKey, "mac-do", "t4"); err == nil {
		t.Fatal("tampered u accepted")
	}
}

func TestSharingServiceEndToEnd(t *testing.T) {
	do, db := GenerateKey(), GenerateKey()
	deltaK := []byte("price=50;phenotype=abc")
	e := ShaPriSet(deltaK, do, "mac-do", "t1")
	f, err := ShaPriAcc(e, &do.PublicKey, db, "mac-db", "t2")
	if err != nil {
		t.Fatal(err)
	}
	if err := ShaPriVer(f, &db.PublicKey); err != nil {
		t.Fatal(err)
	}
	confT := []byte("conf_t-0001")
	gd := bytes.Repeat([]byte("ACGT"), 256)
	r := ShaSignCrypt(gd, confT, do, &db.PublicKey, "mac-do", "t3")
	gd2, w, err := ShaUnsignCrypt(r, db, &do.PublicKey, "mac-db", "t4")
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(gd, gd2) {
		t.Fatal("plaintext mismatch")
	}
	if err := ShaTxnFin(w, &db.PublicKey); err != nil {
		t.Fatal(err)
	}
	if err := ShaTxnFin(w, &do.PublicKey); err == nil {
		t.Fatal("sigma_conf_t accepted under wrong key")
	}
	// Remark 2 batch with 10 owners
	es := make([]*SigmaE, 10)
	puks := make([]*ecdsa.PublicKey, 10)
	for i := range es {
		k := GenerateKey()
		es[i] = ShaPriSet(deltaK, k, "m", "t")
		puks[i] = &k.PublicKey
	}
	fb, err := ShaPriAccBatch(es, puks, db, "mac-db", "t2")
	if err != nil {
		t.Fatal(err)
	}
	if err := ShaPriVer(fb, &db.PublicKey); err != nil {
		t.Fatal(err)
	}
}

func TestECDSAAndKeyEncoding(t *testing.T) {
	k := GenerateKey()
	sig := SignECDSA(k, []byte("a"), []byte("b"))
	if !VerifyECDSA(&k.PublicKey, sig, []byte("a"), []byte("b")) {
		t.Fatal("valid ECDSA rejected")
	}
	// concat is injective: ("a","b") != ("ab","")
	if VerifyECDSA(&k.PublicKey, sig, []byte("ab"), []byte("")) {
		t.Fatal("length-prefixing broken")
	}
	p, err := ParsePubHex(PubHex(&k.PublicKey))
	if err != nil || p.X.Cmp(k.PublicKey.X) != 0 || p.Y.Cmp(k.PublicKey.Y) != 0 {
		t.Fatal("public key round trip failed")
	}
	if _, err := ParsePubHex("04" + "00"); err == nil {
		t.Fatal("garbage key accepted")
	}
}
