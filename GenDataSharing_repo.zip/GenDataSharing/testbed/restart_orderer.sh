#!/bin/bash
n=$1
cd ${FABRIC_WORK:-$HOME/fabric-work}/fabric-samples/test-network-nano-bash
setsid ./orderer$n.sh >> logs/orderer$n.log 2>&1 &
for i in $(seq 1 60); do curl -s http://127.0.0.1:$((8442+n))/healthz | grep -q OK && break; sleep 0.5; done
