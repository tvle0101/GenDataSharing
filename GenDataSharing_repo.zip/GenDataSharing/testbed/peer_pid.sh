#!/bin/bash
# pid of peer N (CORE_PEER_ID: 1=peer0.org1 2=peer1.org1 3=peer0.org2 4=peer1.org2)
case $1 in 1) id=peer0.org1.example.com;; 2) id=peer1.org1.example.com;; 3) id=peer0.org2.example.com;; 4) id=peer1.org2.example.com;; esac
for p in $(pgrep -x peer); do
  if tr '\0' '\n' < /proc/$p/environ 2>/dev/null | grep -q "CORE_PEER_ID=$id$"; then echo $p; exit 0; fi
done
