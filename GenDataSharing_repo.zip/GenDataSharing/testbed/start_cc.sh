#!/bin/bash
cd ${FABRIC_WORK:-$HOME/fabric-work}
export CHAINCODE_SERVER_ADDRESS=127.0.0.1:9999
export CORE_CHAINCODE_ID_NAME=genomic_2.0:025365b0ea3751256ae720b92f52b80c42c788977a8f4ecebd55a28224e3ca10
export CORE_PEER_TLS_ENABLED=false
exec ${FABRIC_WORK:-$HOME/fabric-work}/chaincode_v2/genomic-ccaas
