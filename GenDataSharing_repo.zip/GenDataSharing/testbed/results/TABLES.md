## Benchmark: SeqPriVer commit latency and throughput (5 repetitions per level)

| Concurrency | Txs/rep | OK/Failed (total) | Throughput (tx/s) mean ± std | Commit latency mean (ms) mean ± std | p50 (ms) | p95 (ms) | max (ms) | blocks/rep |
|---|---|---|---|---|---|---|---|---|
| 1 | 20 | 100/0 | 0.49 ± 0.00 | 2028.16 ± 2.21 | 2026.40 ± 1.09 | 2041.65 ± 11.59 | 2049.22 ± 14.02 | 20.00 ± 0.00 |
| 10 | 200 | 1000/0 | 135.24 ± 3.92 | 73.95 ± 2.14 | 73.94 ± 2.74 | 92.20 ± 5.64 | 99.36 ± 5.13 | 20.00 ± 0.00 |
| 50 | 1000 | 5000/0 | 121.35 ± 4.86 | 410.07 ± 16.19 | 407.73 ± 19.86 | 566.72 ± 31.39 | 711.63 ± 71.79 | 100.00 ± 0.00 |
| 100 | 2000 | 10000/0 | 103.18 ± 4.94 | 965.14 ± 44.79 | 960.68 ± 39.10 | 1226.74 ± 99.90 | 1534.34 ± 139.28 | 200.00 ± 0.00 |

Per-repetition raw values:

| conc | rep | ok | failed | wall (s) | tps | lat mean (ms) | lat std (ms) | p95 (ms) | height start→end |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 20 | 0 | 40.59 | 0.49 | 2029.4 | 8.0 | 2040.1 | 16→36 |
| 1 | 2 | 20 | 0 | 40.59 | 0.49 | 2029.3 | 11.9 | 2059.7 | 36→56 |
| 1 | 3 | 20 | 0 | 40.53 | 0.49 | 2026.5 | 3.8 | 2034.5 | 56→76 |
| 1 | 4 | 20 | 0 | 40.50 | 0.49 | 2025.2 | 3.1 | 2029.4 | 76→96 |
| 1 | 5 | 20 | 0 | 40.61 | 0.49 | 2030.4 | 9.0 | 2044.5 | 96→116 |
| 10 | 1 | 200 | 0 | 1.50 | 133.74 | 74.7 | 11.6 | 97.0 | 116→136 |
| 10 | 2 | 200 | 0 | 1.49 | 134.06 | 74.6 | 10.0 | 90.4 | 136→156 |
| 10 | 3 | 200 | 0 | 1.45 | 138.07 | 72.4 | 8.5 | 85.5 | 156→176 |
| 10 | 4 | 200 | 0 | 1.43 | 140.15 | 71.3 | 10.8 | 89.0 | 176→196 |
| 10 | 5 | 200 | 0 | 1.54 | 130.17 | 76.8 | 12.9 | 99.0 | 196→216 |
| 50 | 1 | 1000 | 0 | 8.34 | 119.91 | 414.5 | 99.8 | 603.9 | 216→316 |
| 50 | 2 | 1000 | 0 | 8.46 | 118.24 | 420.6 | 89.1 | 575.5 | 316→416 |
| 50 | 3 | 1000 | 0 | 7.70 | 129.88 | 381.7 | 67.3 | 523.7 | 416→516 |
| 50 | 4 | 1000 | 0 | 8.45 | 118.40 | 420.1 | 100.5 | 583.0 | 516→616 |
| 50 | 5 | 1000 | 0 | 8.31 | 120.29 | 413.5 | 90.4 | 547.5 | 616→716 |
| 100 | 1 | 2000 | 0 | 17.93 | 111.53 | 890.3 | 152.1 | 1115.4 | 716→916 |
| 100 | 2 | 2000 | 0 | 20.34 | 98.35 | 1011.2 | 194.1 | 1337.7 | 916→1116 |
| 100 | 3 | 2000 | 0 | 19.66 | 101.75 | 978.0 | 149.1 | 1202.9 | 1116→1316 |
| 100 | 4 | 2000 | 0 | 19.52 | 102.45 | 970.2 | 140.7 | 1154.1 | 1316→1516 |
| 100 | 5 | 2000 | 0 | 19.64 | 101.83 | 975.9 | 190.8 | 1323.6 | 1516→1716 |

## Fault test: SIGKILL a Raft follower orderer (5 trials)

| Trial | killed pid | commits before kill | commits after kill (45 s window) | failed submissions | recovery A: first commit after kill (s) | recovery B: first commit of a tx started after kill (s) | max gap between commits (s) |
|---|---|---|---|---|---|---|---|
| follower_t1 | 12782 | 16 | 184 | 0 | 1.060 | 1.060 | 2.240 |
| follower_t2 | 12986 | 16 | 184 | 0 | 1.077 | 1.077 | 2.240 |
| follower_t3 | 13110 | 17 | 183 | 0 | 1.324 | 1.324 | 2.238 |
| follower_t4 | 15612 | 17 | 183 | 0 | 1.309 | 1.309 | 2.264 |
| follower_t5 | 15725 | 17 | 183 | 0 | 1.333 | 1.333 | 2.257 |
| **mean ± std** | | | | | **1.22 ± 0.14** | **1.22 ± 0.14** | **2.25 ± 0.01** |

## Fault test: SIGKILL the Raft leader orderer (5 trials)

| Trial | killed pid | commits before kill | commits after kill (45 s window) | failed submissions | recovery A: first commit after kill (s) | recovery B: first commit of a tx started after kill (s) | max gap between commits (s) |
|---|---|---|---|---|---|---|---|
| leader_t1 | 12528 | 17 | 150 | 33 | 11.831 | 11.831 | 12.527 |
| leader_t2 | 12672 | 16 | 160 | 24 | 13.108 | 13.108 | 14.056 |
| leader_t3 | 15936 | 17 | 33 | 150 | 44.050 | 44.050 | 44.750 |
| leader_t4 | 15831 | 16 | 156 | 27 | 12.613 | 12.613 | 13.572 |
| leader_t5 | 16046 | 16 | 85 | 99 | 25.880 | 25.880 | 26.827 |
| **mean ± std** | | | | | **21.50 ± 13.88** | **21.50 ± 13.88** | **22.35 ± 13.82** |

Distinct submission errors observed during these trials:

- `rpc error: code = DeadlineExceeded desc = context deadline exceeded`
- `rpc error: code = Unavailable desc = no orderers could successfully process transaction`

## Fault test: SIGKILL peer1.org1 (non-gateway Org1 peer)

- killed pid 5858; commits before kill: 17; commits in the 30 s after kill: 123; failed submissions: 0
- first commit after kill: 1.303 s; first commit of a tx started after kill: 1.303 s; max gap between commits: 2.258 s

## Fault test: SIGKILL peer0.org2 (Org2 peer)

- killed pid 5865; commits before kill: 15; commits in the 30 s after kill: 124; failed submissions: 0
- first commit after kill: 1.255 s; first commit of a tx started after kill: 1.255 s; max gap between commits: 2.252 s

