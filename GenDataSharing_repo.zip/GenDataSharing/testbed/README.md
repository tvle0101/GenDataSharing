# Fabric testbed (Section VII-A, IX-E; Table IV)

Everything here ran as plain OS processes on one host (no Docker): Hyperledger Fabric v2.5.13 built from source,
the `test-network-nano-bash` network of `hyperledger/fabric-samples` (channel `mychannel`, 3 etcdraft orderers,
2 organisations x 2 peers, TLS, endorsement policy `OR('Org1MSP.peer','Org2MSP.peer')`, BatchTimeout 2 s,
MaxMessageCount 10), the chaincode as an external service (CCaaS), and the Go client in `client/` using the Fabric Gateway
SDK (`SubmitTransaction` returns after commit).

All scripts take the working directory from the environment variable `FABRIC_WORK` (default `~/fabric-work`); it must contain
`fabric-samples/` with the nano-bash network already set up (peer/orderer binaries on `PATH`) and, for the chaincode, a
directory with the built `genomic-ccaas` binary. Build the binary with
`cd chaincode/genomic/go && go build -o $FABRIC_WORK/chaincode_v2/genomic-ccaas .`

| File | Purpose |
|---|---|
| `start_net.sh` | start 3 orderers and 4 peers |
| `upgrade_cc.sh <dir> [version] [sequence] [binary]` | package, install, approve, commit the chaincode and start it |
| `client/` | `go build -o fabclient .` in `client/`; modes `bench` (closed loop, concurrency list) and `fault` (open loop, SIGKILL of a process); `-args real` makes every transaction carry fresh BLS12-381 + ECDSA signatures; `-tamper` submits corrupted transactions |
| `fault_tests.sh`, `fault_tests_v2.sh` | 5 follower kills, 5 leader kills, 2 peer kills per run (v1 = non-verifying, v2 = verifying chaincode) |
| `leader.sh`, `orderer_pid.sh`, `peer_pid.sh`, `restart_orderer.sh` | helpers used by the fault scripts |
| `summarize.py`, `summarize2.py` | build `results*/TABLES.md` from the raw JSON |
| `results/`, `results_v2/` | the raw measurements and the run notes (`SUMMARY.md`) behind the paper's numbers; `results_v2/` is the final (verifying) run |

The `SUMMARY.md` files record the exact machine (2 vCPU Xeon 2.1 GHz, 7 GiB) and commands of each run. The numbers are
specific to that host and will differ on other hardware; the single-host topology means that all network hops are loopback.
