#!/usr/bin/env python3
"""Builds results/SUMMARY.md tables from results/bench.json and results/fault_*.json."""
import json, glob, os, statistics as st, sys

F = os.environ.get("FABRIC_WORK", os.path.expanduser("~/fabric-work"))
R = os.path.join(F, sys.argv[1] if len(sys.argv) > 1 else "results")

def ms(xs):
    m = st.mean(xs); s = st.stdev(xs) if len(xs) > 1 else 0.0
    return f"{m:.2f} ± {s:.2f}"

out = []
# ---- benchmark table
b = json.load(open(os.path.join(R, "bench.json")))
rows = {}
for rep in b["reps"]:
    rows.setdefault(rep["concurrency"], []).append(rep)
out.append("## Benchmark: SeqPriVer commit latency and throughput (5 repetitions per level)\n")
out.append("| Concurrency | Txs/rep | OK/Failed (total) | Throughput (tx/s) mean ± std | Commit latency mean (ms) mean ± std | p50 (ms) | p95 (ms) | max (ms) | blocks/rep |")
out.append("|---|---|---|---|---|---|---|---|---|")
for c in sorted(rows):
    rs = rows[c]
    ok = sum(r["ok"] for r in rs); fl = sum(r["failed"] for r in rs)
    tps = [r["throughput_tps"] for r in rs]
    lat = [r["lat_mean_ms"] for r in rs]
    p50 = [r["lat_p50_ms"] for r in rs]; p95 = [r["lat_p95_ms"] for r in rs]; mx = [r["lat_max_ms"] for r in rs]
    blocks = [r["end_height"] - r["start_height"] for r in rs]
    out.append(f"| {c} | {rs[0]['txs']} | {ok}/{fl} | {ms(tps)} | {ms(lat)} | {ms(p50)} | {ms(p95)} | {ms(mx)} | {ms(blocks)} |")
out.append("")
out.append("Per-repetition raw values:\n")
out.append("| conc | rep | ok | failed | wall (s) | tps | lat mean (ms) | lat std (ms) | p95 (ms) | height start→end |")
out.append("|---|---|---|---|---|---|---|---|---|---|")
for c in sorted(rows):
    for r in rows[c]:
        out.append(f"| {c} | {r['rep']} | {r['ok']} | {r['failed']} | {r['wall_sec']:.2f} | {r['throughput_tps']:.2f} | {r['lat_mean_ms']:.1f} | {r['lat_std_ms']:.1f} | {r['lat_p95_ms']:.1f} | {r['start_height']}→{r['end_height']} |")
out.append("")

# ---- fault tables
def fault_group(prefix, title):
    files = sorted(glob.glob(os.path.join(R, f"fault_{prefix}_t*.json")))
    if not files:
        return
    out.append(f"## {title} ({len(files)} trials)\n")
    out.append("| Trial | killed pid | commits before kill | commits after kill (45 s window) | failed submissions | recovery A: first commit after kill (s) | recovery B: first commit of a tx started after kill (s) | max gap between commits (s) |")
    out.append("|---|---|---|---|---|---|---|---|")
    A, B, G = [], [], []
    for f in files:
        d = json.load(open(f))
        A.append(d["recovery_sec_first_commit_after_kill"]); B.append(d["recovery_sec_first_tx_started_after_kill"]); G.append(d["max_gap_between_commits_sec"])
        out.append(f"| {d['label']} | {d['killed_pid']} | {d['ok_before_kill']} | {d['ok_after_kill']} | {d['failed']} | {A[-1]:.3f} | {B[-1]:.3f} | {G[-1]:.3f} |")
    out.append(f"| **mean ± std** | | | | | **{ms(A)}** | **{ms(B)}** | **{ms(G)}** |")
    out.append("")
    errs = set()
    for f in files:
        for e in json.load(open(f)).get("errors") or []:
            errs.add(e.split(": ", 1)[1][:160])
    if errs:
        out.append("Distinct submission errors observed during these trials:\n")
        for e in sorted(errs):
            out.append(f"- `{e}`")
        out.append("")

fault_group("follower", "Fault test: SIGKILL a Raft follower orderer")
fault_group("leader", "Fault test: SIGKILL the Raft leader orderer")

for lbl, title in [("peer1org1", "Fault test: SIGKILL peer1.org1 (non-gateway Org1 peer)"), ("peer0org2", "Fault test: SIGKILL peer0.org2 (Org2 peer)")]:
    f = os.path.join(R, f"fault_{lbl}.json")
    if os.path.exists(f):
        d = json.load(open(f))
        out.append(f"## {title}\n")
        out.append(f"- killed pid {d['killed_pid']}; commits before kill: {d['ok_before_kill']}; commits in the 30 s after kill: {d['ok_after_kill']}; failed submissions: {d['failed']}")
        out.append(f"- first commit after kill: {d['recovery_sec_first_commit_after_kill']:.3f} s; first commit of a tx started after kill: {d['recovery_sec_first_tx_started_after_kill']:.3f} s; max gap between commits: {d['max_gap_between_commits_sec']:.3f} s")
        out.append("")

open(os.path.join(R, "TABLES.md"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
