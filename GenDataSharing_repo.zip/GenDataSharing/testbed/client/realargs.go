package main

// Real-signature argument generation for the v2 (verifying) chaincode, using the
// paper's cryptobench package (BLS12-381 aggregate signature + ECDSA wrappers).
// A single DO key pair and a single GC key pair are generated once per client run;
// every transaction gets a fresh SigmaA -> SigmaB (fresh BLS scalars), so the
// on-chain SeqPriVer performs the full ECDSA check + 2 pairings per transaction.
// The exact argument list (encodeArgs) must match the chaincode's SeqPriVer signature.

import (
	"crypto/ecdsa"
	"encoding/hex"
	"fmt"
	"time"

	cb "github.com/tvle0101/GenDataSharing/cryptobench"
)

type realSigner struct {
	do, gc *ecdsa.PrivateKey
	alphaK []byte
}

func newRealSigner() *realSigner {
	return &realSigner{do: cb.GenerateKey(), gc: cb.GenerateKey(), alphaK: []byte("alphaK:wgs,price=100")}
}

// sigmaB runs SeqPriAcc (DO side) and SeqPriCfm (GC side) off-chain, like the paper's client.
func (r *realSigner) sigmaB(recordID string) *cb.SigmaB {
	t := time.Now().UTC().Format(time.RFC3339Nano)
	a := cb.SeqPriAcc(r.alphaK, r.do, "macDO-"+recordID, t)
	b, err := cb.SeqPriCfm(a, &r.do.PublicKey, r.gc, "macGC-"+recordID, t)
	must(err, "SeqPriCfm")
	return b
}

// encodeArgs produces the SeqPriVer argument list for the v2 chaincode (set by -argfmt).
func (r *realSigner) encodeArgs(recordID string) []string {
	b := r.sigmaB(recordID)
	s1, s2 := b.Sig.Bytes()
	pukHex := cb.PubHex(&r.gc.PublicKey)
	alpha := string(b.AlphaK)
	switch *tamper {
	case "alpha": // alter alpha_k after signing: ECDSA still verifies, the pairing e(h(alpha_k), sigma_b1) == e(sigma_b2, g) must fail
		alpha += "x"
	case "pubkey": // sign with GC key but present a different (freshly generated) public key
		pukHex = cb.PubHex(&cb.GenerateKey().PublicKey)
	case "sigma": // flip one hex nibble of sigma_b1 (the G1 component)
		h := []byte(hex.EncodeToString(s1))
		if h[10] == '0' { h[10] = '1' } else { h[10] = '0' }
		s1h := string(h)
		return []string{recordID, "DO-" + recordID, "GC1", string(b.AlphaK),
			s1h, hex.EncodeToString(s2),
			hex.EncodeToString(b.SigmaSeqPriAcc), hex.EncodeToString(b.SigmaSeqPriCfm),
			"macDO-" + recordID, b.MACGC, b.TSeqPriCfm, pukHex}
	}
	switch *argFmt {
	default: // "v2": recordID, dataOwnerID, gcsID, alphaK, sigmaB1(hex G1), sigmaB2(hex G2), sigmaSeqPriAcc(hex), sigmaSeqPriCfm(hex), macDO, macGC, tSeqPriCfm, pukGC(hex)
		return []string{recordID, "DO-" + recordID, "GC1", alpha,
			hex.EncodeToString(s1), hex.EncodeToString(s2),
			hex.EncodeToString(b.SigmaSeqPriAcc), hex.EncodeToString(b.SigmaSeqPriCfm),
			"macDO-" + recordID, b.MACGC, b.TSeqPriCfm, pukHex}
	}
}

func (r *realSigner) selfCheck() {
	b := r.sigmaB("selfcheck")
	must(cb.SeqPriVer(b, &r.gc.PublicKey), "local SeqPriVer self-check")
	fmt.Println("local cryptobench self-check OK (ECDSA + pairing verify)")
}
