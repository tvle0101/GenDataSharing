// Benchmark / fault-injection client for the genomic chaincode using fabric-gateway.
//
// Modes:
//   bench  -conc 1,10,50,100 -reps 5 -txs <per-rep tx count or 0 = 10*conc (min 20)>
//   fault  -kill <pid> -label <name> -warmup 5s -after 30s   (kills pid, measures recovery)
//
// All timings are measured with time.Now() around contract.SubmitTransaction, which
// returns only after the transaction has been committed to the gateway peer's ledger
// (or returns an error).
package main

import (
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"flag"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/hyperledger/fabric-gateway/pkg/client"
	"github.com/hyperledger/fabric-gateway/pkg/identity"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
)

const (
	mspID       = "Org1MSP"
	channelName = "mychannel"
	ccName      = "genomic"
	contractNm  = "GSContract"
)

var cryptoRoot = fabricWork() + "/fabric-samples/test-network-nano-bash/crypto-config"

// fabricWork returns the directory that holds fabric-samples (env FABRIC_WORK, default ~/fabric-work).
func fabricWork() string {
	if v := os.Getenv("FABRIC_WORK"); v != "" {
		return v
	}
	h, _ := os.UserHomeDir()
	return filepath.Join(h, "fabric-work")
}

var (
	peerAddr    = flag.String("peer", "127.0.0.1:7051", "gateway peer address")
	peerHost    = flag.String("peerhost", "peer0.org1.example.com", "TLS server name override of gateway peer")
	peerTLSCA   = flag.String("peertlsca", cryptoRoot+"/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt", "")
	mode        = flag.String("mode", "bench", "bench | fault")
	concList    = flag.String("conc", "1,10,50,100", "concurrency levels")
	reps        = flag.Int("reps", 5, "repetitions per level")
	txsPerRep   = flag.Int("txs", 0, "transactions per repetition (0 => max(20, 10*conc))")
	out         = flag.String("out", "", "output JSON file")
	killPid     = flag.Int("kill", 0, "pid to SIGKILL in fault mode")
	label       = flag.String("label", "", "label for fault run")
	warmup      = flag.Duration("warmup", 5*time.Second, "time before kill in fault mode")
	after       = flag.Duration("after", 40*time.Second, "time to keep submitting after kill")
	interval    = flag.Duration("interval", 250*time.Millisecond, "open-loop submission interval in fault mode")
	commitTO    = flag.Duration("committimeout", 90*time.Second, "commit status timeout")
	runPrefix   = flag.String("prefix", "", "record id prefix (default: unix nanos)")
	argsMode    = flag.String("args", "dummy", "dummy (v1 placeholder strings) | real (cryptobench BLS12-381+ECDSA SigmaB per tx)")
	argFmt      = flag.String("argfmt", "v2", "argument layout for -args real")
	tamper      = flag.String("tamper", "", "none | pubkey (wrong puk_GC) | sigma (flip one nibble of sigma_b1) | alpha (alter alpha_k after signing) -- negative test for on-chain verification")
	signer      *realSigner
)

type txResult struct {
	Worker    int     `json:"worker"`
	RecordID  string  `json:"recordID"`
	StartUnix float64 `json:"start"`
	EndUnix   float64 `json:"end"`
	LatencyMs float64 `json:"latency_ms"`
	Err       string  `json:"err,omitempty"`
}

type repResult struct {
	Conc            int        `json:"concurrency"`
	Rep             int        `json:"rep"`
	Txs             int        `json:"txs"`
	Ok              int        `json:"ok"`
	Failed          int        `json:"failed"`
	WallSec         float64    `json:"wall_sec"`
	ThroughputTPS   float64    `json:"throughput_tps"`
	LatMeanMs       float64    `json:"lat_mean_ms"`
	LatStdMs        float64    `json:"lat_std_ms"`
	LatP50Ms        float64    `json:"lat_p50_ms"`
	LatP95Ms        float64    `json:"lat_p95_ms"`
	LatMaxMs        float64    `json:"lat_max_ms"`
	StartHeight     uint64     `json:"start_height"`
	EndHeight       uint64     `json:"end_height"`
	Results         []txResult `json:"results"`
}

func must(err error, what string) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "FATAL %s: %v\n", what, err)
		os.Exit(1)
	}
}

func connect() (*client.Gateway, *grpc.ClientConn) {
	caPEM, err := os.ReadFile(*peerTLSCA)
	must(err, "read peer tls ca")
	pool := x509.NewCertPool()
	pool.AppendCertsFromPEM(caPEM)
	creds := credentials.NewClientTLSFromCert(pool, *peerHost)
	conn, err := grpc.NewClient(*peerAddr, grpc.WithTransportCredentials(creds))
	must(err, "grpc client")

	userMSP := filepath.Join(cryptoRoot, "peerOrganizations/org1.example.com/users/User1@org1.example.com/msp")
	certPEM, err := os.ReadFile(filepath.Join(userMSP, "signcerts/User1@org1.example.com-cert.pem"))
	must(err, "read user cert")
	block, _ := pem.Decode(certPEM)
	cert, err := x509.ParseCertificate(block.Bytes)
	must(err, "parse cert")
	id, err := identity.NewX509Identity(mspID, cert)
	must(err, "identity")
	keyFiles, _ := filepath.Glob(filepath.Join(userMSP, "keystore/*"))
	keyPEM, err := os.ReadFile(keyFiles[0])
	must(err, "read key")
	key, err := identity.PrivateKeyFromPEM(keyPEM)
	must(err, "parse key")
	signer, err := identity.NewPrivateKeySign(key)
	must(err, "signer")

	gw, err := client.Connect(id, client.WithSign(signer), client.WithClientConnection(conn),
		client.WithEvaluateTimeout(10*time.Second),
		client.WithEndorseTimeout(30*time.Second),
		client.WithSubmitTimeout(30*time.Second),
		client.WithCommitStatusTimeout(*commitTO))
	must(err, "gateway connect")
	return gw, conn
}

func height(network *client.Network) uint64 {
	// qscc GetChainInfo returns a BlockchainInfo protobuf; parse height from the first varint.
	c := network.GetContract("qscc")
	b, err := c.EvaluateTransaction("GetChainInfo", channelName)
	if err != nil || len(b) < 2 || b[0] != 0x08 {
		return 0
	}
	var h uint64
	var shift uint
	for _, by := range b[1:] {
		h |= uint64(by&0x7f) << shift
		if by&0x80 == 0 {
			break
		}
		shift += 7
	}
	return h
}

func submit(contract *client.Contract, worker int, recordID string) txResult {
	var args []string
	if signer != nil {
		args = signer.encodeArgs(recordID) // off-chain SeqPriAcc+SeqPriCfm cost is excluded from the latency
	} else {
		args = []string{recordID, "DO-" + recordID, "GC1", "alphaK:wgs,price=100", "sigmaB1-" + recordID, "sigmaB2-" + recordID, "sigmaSeqPriCfm-" + recordID, "macDO-" + recordID, "macGC-" + recordID}
	}
	start := time.Now()
	_, err := contract.SubmitTransaction("SeqPriVer", args...)
	end := time.Now()
	r := txResult{Worker: worker, RecordID: recordID,
		StartUnix: float64(start.UnixNano()) / 1e9, EndUnix: float64(end.UnixNano()) / 1e9,
		LatencyMs: float64(end.Sub(start).Microseconds()) / 1000}
	if err != nil {
		r.Err = err.Error()
	}
	return r
}

func stats(lats []float64) (mean, std, p50, p95, max float64) {
	if len(lats) == 0 {
		return
	}
	s := append([]float64(nil), lats...)
	sort.Float64s(s)
	var sum float64
	for _, v := range s {
		sum += v
	}
	mean = sum / float64(len(s))
	var ss float64
	for _, v := range s {
		ss += (v - mean) * (v - mean)
	}
	if len(s) > 1 {
		std = math.Sqrt(ss / float64(len(s)-1))
	}
	p50 = s[len(s)/2]
	p95 = s[int(float64(len(s)-1)*0.95)]
	max = s[len(s)-1]
	return
}

func runRep(contract *client.Contract, network *client.Network, conc, rep, txs int, prefix string) repResult {
	rr := repResult{Conc: conc, Rep: rep, Txs: txs}
	rr.StartHeight = height(network)
	results := make([]txResult, txs)
	var next int64 = -1
	var wg sync.WaitGroup
	wallStart := time.Now()
	for w := 0; w < conc; w++ {
		wg.Add(1)
		go func(w int) {
			defer wg.Done()
			for {
				i := int(atomic.AddInt64(&next, 1))
				if i >= txs {
					return
				}
				results[i] = submit(contract, w, fmt.Sprintf("%s-c%d-r%d-%d", prefix, conc, rep, i))
			}
		}(w)
	}
	wg.Wait()
	rr.WallSec = time.Since(wallStart).Seconds()
	rr.EndHeight = height(network)
	var lats []float64
	for _, r := range results {
		if r.Err == "" {
			rr.Ok++
			lats = append(lats, r.LatencyMs)
		} else {
			rr.Failed++
		}
	}
	rr.ThroughputTPS = float64(rr.Ok) / rr.WallSec
	rr.LatMeanMs, rr.LatStdMs, rr.LatP50Ms, rr.LatP95Ms, rr.LatMaxMs = stats(lats)
	rr.Results = results
	return rr
}

func bench(contract *client.Contract, network *client.Network, prefix string) {
	var all []repResult
	for _, cs := range strings.Split(*concList, ",") {
		conc, _ := strconv.Atoi(cs)
		txs := *txsPerRep
		if txs == 0 {
			txs = 20 * conc
			if txs < 20 {
				txs = 20
			}
		}
		for rep := 1; rep <= *reps; rep++ {
			rr := runRep(contract, network, conc, rep, txs, prefix)
			fmt.Printf("conc=%d rep=%d txs=%d ok=%d failed=%d wall=%.2fs tps=%.2f lat_mean=%.1fms lat_std=%.1fms p95=%.1fms blocks=%d..%d\n",
				conc, rep, txs, rr.Ok, rr.Failed, rr.WallSec, rr.ThroughputTPS, rr.LatMeanMs, rr.LatStdMs, rr.LatP95Ms, rr.StartHeight, rr.EndHeight)
			all = append(all, rr)
			time.Sleep(3 * time.Second) // let the last block flush
		}
	}
	writeJSON(map[string]any{"mode": "bench", "args": *argsMode, "prefix": prefix, "peer": *peerAddr, "reps": all})
}

type faultResult struct {
	Label                    string     `json:"label"`
	KilledPid                int        `json:"killed_pid"`
	KillUnix                 float64    `json:"kill_time"`
	FirstCommitAfterKillUnix float64    `json:"first_commit_end_after_kill"`
	RecoveryCommitSec        float64    `json:"recovery_sec_first_commit_after_kill"`
	FirstFullTxAfterKillUnix float64    `json:"first_commit_end_of_tx_started_after_kill"`
	RecoveryFullTxSec        float64    `json:"recovery_sec_first_tx_started_after_kill"`
	MaxGapSec                float64    `json:"max_gap_between_commits_sec"`
	OkBefore                 int        `json:"ok_before_kill"`
	OkAfter                  int        `json:"ok_after_kill"`
	Failed                   int        `json:"failed"`
	Errors                   []string   `json:"errors"`
	Results                  []txResult `json:"results"`
}

func fault(contract *client.Contract, prefix string) {
	if *killPid == 0 {
		must(fmt.Errorf("-kill pid required"), "fault")
	}
	var mu sync.Mutex
	var results []txResult
	stop := int32(0)
	var wg sync.WaitGroup
	// Open-loop submitter: a new independent SeqPriVer transaction is launched every
	// *interval regardless of whether earlier ones have completed, so that transactions
	// lost in a killed orderer's pending batch do not block observation of recovery.
	go func() {
		for i := 0; atomic.LoadInt32(&stop) == 0; i++ {
			wg.Add(1)
			go func(i int) {
				defer wg.Done()
				r := submit(contract, i, fmt.Sprintf("%s-%s-%d", prefix, *label, i))
				mu.Lock()
				results = append(results, r)
				mu.Unlock()
			}(i)
			time.Sleep(*interval)
		}
	}()
	time.Sleep(*warmup)
	killT := time.Now()
	err := syscall.Kill(*killPid, syscall.SIGKILL)
	must(err, "kill")
	fmt.Printf("[%s] killed pid %d at %s\n", *label, *killPid, killT.Format(time.RFC3339Nano))
	time.Sleep(*after)
	atomic.StoreInt32(&stop, 1)
	wg.Wait() // waits for in-flight (possibly lost) transactions to time out

	kt := float64(killT.UnixNano()) / 1e9
	fr := faultResult{Label: *label, KilledPid: *killPid, KillUnix: kt}
	sort.Slice(results, func(i, j int) bool { return results[i].EndUnix < results[j].EndUnix })
	var lastOkEnd float64
	for _, r := range results {
		if r.Err != "" {
			fr.Failed++
			fr.Errors = append(fr.Errors, fmt.Sprintf("%.3f: %s", r.EndUnix-kt, r.Err))
			continue
		}
		if r.EndUnix < kt {
			fr.OkBefore++
		} else {
			fr.OkAfter++
			if fr.FirstCommitAfterKillUnix == 0 {
				fr.FirstCommitAfterKillUnix = r.EndUnix
				fr.RecoveryCommitSec = r.EndUnix - kt
			}
			if r.StartUnix >= kt && fr.FirstFullTxAfterKillUnix == 0 {
				fr.FirstFullTxAfterKillUnix = r.EndUnix
				fr.RecoveryFullTxSec = r.EndUnix - kt
			}
		}
		if lastOkEnd > 0 && r.EndUnix-lastOkEnd > fr.MaxGapSec {
			fr.MaxGapSec = r.EndUnix - lastOkEnd
		}
		lastOkEnd = r.EndUnix
	}
	fr.Results = results
	fmt.Printf("[%s] ok_before=%d ok_after=%d failed=%d recovery(first commit after kill)=%.3fs recovery(first tx started after kill)=%.3fs max_gap=%.3fs\n",
		*label, fr.OkBefore, fr.OkAfter, fr.Failed, fr.RecoveryCommitSec, fr.RecoveryFullTxSec, fr.MaxGapSec)
	writeJSON(fr)
}

func writeJSON(v any) {
	if *out == "" {
		return
	}
	b, err := json.MarshalIndent(v, "", " ")
	must(err, "marshal")
	must(os.WriteFile(*out, b, 0o644), "write")
}

func main() {
	flag.Parse()
	prefix := *runPrefix
	if prefix == "" {
		prefix = strconv.FormatInt(time.Now().UnixNano(), 36)
	}
	if *argsMode == "real" {
		signer = newRealSigner()
		signer.selfCheck()
	}
	gw, conn := connect()
	defer conn.Close()
	defer gw.Close()
	network := gw.GetNetwork(channelName)
	contract := network.GetContractWithName(ccName, contractNm)
	switch *mode {
	case "bench":
		bench(contract, network, prefix)
	case "fault":
		fault(contract, prefix)
	case "height":
		fmt.Println(height(network))
	default:
		must(fmt.Errorf("unknown mode"), *mode)
	}
}
