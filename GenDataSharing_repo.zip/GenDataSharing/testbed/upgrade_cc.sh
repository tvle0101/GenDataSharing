#!/bin/bash
# Upgrade chaincode "genomic" on mychannel to a new CCaaS package.
# Usage: upgrade_cc.sh <dir containing a built chaincode binary> [version] [sequence] [binary-name]
#   e.g. upgrade_cc.sh $F/chaincode_v2 2.0 2 genomic-ccaas
# Steps: package (ccaas) -> install on all 4 peers -> approve Org1 + Org2 -> commit -> restart CCaaS process with new package id.
set -euo pipefail
F=${FABRIC_WORK:-$HOME/fabric-work}
BINDIR=${1:?dir with built chaincode binary}
VERSION=${2:-2.0}
SEQ=${3:-2}
BIN=${4:-genomic-ccaas}
[ -x "$BINDIR/$BIN" ] || { echo "no executable $BINDIR/$BIN"; exit 1; }
NET=$F/fabric-samples/test-network-nano-bash
CA=$NET/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/ca.crt
LABEL=genomic_${VERSION}
PKGDIR=$F/ccpkg_${VERSION}; mkdir -p $PKGDIR; cd $PKGDIR
echo '{"address":"127.0.0.1:9999","dial_timeout":"10s","tls_required":false}' > connection.json
echo "{\"type\":\"ccaas\",\"label\":\"$LABEL\"}" > metadata.json
tar cfz code.tar.gz connection.json && tar cfz genomic-ccaas.tgz metadata.json code.tar.gz
cd $NET
for p in 1 2 3 4; do (. ./peer${p}admin.sh && peer lifecycle chaincode install $PKGDIR/genomic-ccaas.tgz 2>&1 | tail -1); done
CCID=$(. ./peer1admin.sh && peer lifecycle chaincode calculatepackageid $PKGDIR/genomic-ccaas.tgz)
echo "package id: $CCID"
# start the new chaincode process BEFORE approve/commit so that peers can connect at commit time
pkill -f "$F/chaincode.*genomic-ccaas" || true; pkill -x genomic-ccaas || true; sleep 1
cat > $F/start_cc.sh <<EOS
#!/bin/bash
cd $F
export CHAINCODE_SERVER_ADDRESS=127.0.0.1:9999
export CORE_CHAINCODE_ID_NAME=$CCID
export CORE_PEER_TLS_ENABLED=false
exec $BINDIR/$BIN
EOS
chmod +x $F/start_cc.sh
(setsid $F/start_cc.sh >> $F/logs/chaincode_${VERSION}.log 2>&1 &)
sleep 2; pgrep -x $BIN >/dev/null || { echo "chaincode process did not start; see $F/logs/chaincode_${VERSION}.log"; exit 1; }
for p in 1 3; do (. ./peer${p}admin.sh && peer lifecycle chaincode approveformyorg -o 127.0.0.1:6050 --channelID mychannel --name genomic --version $VERSION --package-id $CCID --sequence $SEQ --tls --cafile $CA 2>&1 | tail -1); done
(. ./peer1admin.sh && peer lifecycle chaincode checkcommitreadiness --channelID mychannel --name genomic --version $VERSION --sequence $SEQ --output json)
(. ./peer1admin.sh && peer lifecycle chaincode commit -o 127.0.0.1:6050 --channelID mychannel --name genomic --version $VERSION --sequence $SEQ --tls --cafile $CA \
   --peerAddresses 127.0.0.1:7051 --tlsRootCertFiles $NET/crypto-config/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt \
   --peerAddresses 127.0.0.1:7055 --tlsRootCertFiles $NET/crypto-config/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt 2>&1 | grep -v '^ \|^$' | tail -2)
(. ./peer1admin.sh && peer lifecycle chaincode querycommitted --channelID mychannel --name genomic)
echo "$CCID" > $F/ccid_${VERSION}.txt
echo "upgrade to genomic v$VERSION seq $SEQ done; CCaaS pid $(pgrep -x $BIN)"
