#!/bin/bash
# Orderer fault tests: 5 trials killing a Raft follower, 5 trials killing the Raft leader,
# then 1 peer-kill trial (peer1.org1, the non-gateway Org1 peer) and 1 trial killing an Org2 peer.
set -u
F=${FABRIC_WORK:-$HOME/fabric-work}
cd $F
run_trial() { # $1 label  $2 orderer number
  local label=$1 n=$2 pid
  pid=$(./orderer_pid.sh $n)
  echo "=== $label trial: orderer$n pid=$pid leader_before=$(./leader.sh) $(date -u +%FT%TZ)"
  ./client/fabclient -mode fault -kill $pid -label $label -warmup 5s -after 45s -interval 250ms -committimeout 40s -out results/fault_${label}.json | tee -a results/fault.log
  echo "leader_after=$(./leader.sh)" | tee -a results/fault.log
  ./restart_orderer.sh $n
  sleep 15   # let the restarted node catch up and the cluster settle
  echo "restarted orderer$n pid=$(./orderer_pid.sh $n) leader_now=$(./leader.sh)" | tee -a results/fault.log
}
for t in 1 2 3 4 5; do
  L=$(./leader.sh); for n in 1 2 3; do [ "$n" != "$L" ] && { FOLLOWER=$n; break; }; done
  run_trial follower_t$t $FOLLOWER
done
for t in 1 2 3 4 5; do
  L=$(./leader.sh)
  run_trial leader_t$t $L
done
# peer fault: kill peer1.org1 (non-gateway peer of Org1) and keep submitting through peer0.org1
pid=$(./peer_pid.sh 2); echo "=== peer kill: peer1.org1 pid=$pid $(date -u +%FT%TZ)" | tee -a results/fault.log
./client/fabclient -mode fault -kill $pid -label peer1org1 -warmup 5s -after 30s -interval 250ms -committimeout 40s -out results/fault_peer1org1.json | tee -a results/fault.log
# peer fault 2: kill peer0.org2
pid=$(./peer_pid.sh 3); echo "=== peer kill: peer0.org2 pid=$pid $(date -u +%FT%TZ)" | tee -a results/fault.log
./client/fabclient -mode fault -kill $pid -label peer0org2 -warmup 5s -after 30s -interval 250ms -committimeout 40s -out results/fault_peer0org2.json | tee -a results/fault.log
echo DONE | tee -a results/fault.log
