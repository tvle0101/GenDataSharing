#!/bin/bash
# Prints the current Raft leader node id (1..3) from the most recent "Raft leader changed" line in any orderer log.
cd ${FABRIC_WORK:-$HOME/fabric-work}/fabric-samples/test-network-nano-bash/logs
grep -h 'Raft leader changed' orderer*.log | sed 's/\x1b\[[0-9;]*m//g' | sort -k1,2 | tail -1 | sed -E 's/.*-> ([0-9]+) channel.*/\1/'
