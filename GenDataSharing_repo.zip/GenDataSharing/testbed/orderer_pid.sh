#!/bin/bash
# pid of orderer N: find the orderer process whose environment has ORDERER_ADMIN_LISTENADDRESS=127.0.0.1:944(2+N)
n=$1; port=$((9442+n))
for p in $(pgrep -x orderer); do
  if tr '\0' '\n' < /proc/$p/environ 2>/dev/null | grep -q "ORDERER_ADMIN_LISTENADDRESS=127.0.0.1:$port$"; then echo $p; exit 0; fi
done
