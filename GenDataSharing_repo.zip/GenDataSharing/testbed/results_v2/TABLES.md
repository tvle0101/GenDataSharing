## Benchmark: SeqPriVer commit latency and throughput (5 repetitions per level)

| Concurrency | Txs/rep | OK/Failed (total) | Throughput (tx/s) mean ± std | Commit latency mean (ms) mean ± std | p50 (ms) | p95 (ms) | max (ms) | blocks/rep |
|---|---|---|---|---|---|---|---|---|
| 1 | 20 | 100/0 | 0.49 ± 0.00 | 2028.39 ± 0.99 | 2027.97 ± 1.70 | 2036.21 ± 2.94 | 2039.26 ± 5.26 | 20.00 ± 0.00 |
| 10 | 200 | 1000/0 | 80.14 ± 3.65 | 115.37 ± 5.73 | 115.14 ± 5.06 | 154.09 ± 12.16 | 179.31 ± 17.16 | 20.00 ± 0.00 |
| 50 | 1000 | 5000/0 | 90.98 ± 2.17 | 526.29 ± 12.48 | 530.60 ± 12.98 | 687.22 ± 23.16 | 865.43 ± 61.80 | 100.00 ± 0.00 |
| 100 | 2000 | 10000/0 | 93.98 ± 2.79 | 1035.81 ± 30.42 | 1045.69 ± 28.76 | 1368.83 ± 68.59 | 1759.80 ± 220.94 | 200.00 ± 0.00 |

Per-repetition raw values:

| conc | rep | ok | failed | wall (s) | tps | lat mean (ms) | lat std (ms) | p95 (ms) | height start→end |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 20 | 0 | 40.68 | 0.49 | 2029.3 | 5.0 | 2034.9 | 2109→2129 |
| 1 | 2 | 20 | 0 | 40.62 | 0.49 | 2027.0 | 3.4 | 2034.4 | 2129→2149 |
| 1 | 3 | 20 | 0 | 40.65 | 0.49 | 2027.8 | 4.1 | 2034.4 | 2149→2169 |
| 1 | 4 | 20 | 0 | 40.68 | 0.49 | 2029.3 | 6.4 | 2041.3 | 2169→2189 |
| 1 | 5 | 20 | 0 | 40.66 | 0.49 | 2028.5 | 3.9 | 2036.0 | 2189→2209 |
| 10 | 1 | 200 | 0 | 2.59 | 77.31 | 119.1 | 20.9 | 151.2 | 2209→2229 |
| 10 | 2 | 200 | 0 | 2.46 | 81.38 | 112.2 | 23.9 | 152.8 | 2229→2249 |
| 10 | 3 | 200 | 0 | 2.35 | 85.01 | 108.0 | 20.1 | 139.0 | 2249→2269 |
| 10 | 4 | 200 | 0 | 2.46 | 81.22 | 114.9 | 24.4 | 154.6 | 2269→2289 |
| 10 | 5 | 200 | 0 | 2.64 | 75.80 | 122.6 | 27.2 | 172.9 | 2289→2309 |
| 50 | 1 | 1000 | 0 | 11.39 | 87.83 | 545.8 | 96.2 | 703.4 | 2309→2409 |
| 50 | 2 | 1000 | 0 | 10.80 | 92.59 | 517.1 | 93.9 | 661.8 | 2409→2509 |
| 50 | 3 | 1000 | 0 | 10.71 | 93.34 | 514.0 | 94.8 | 662.1 | 2509→2609 |
| 50 | 4 | 1000 | 0 | 11.10 | 90.13 | 528.9 | 103.0 | 701.5 | 2609→2709 |
| 50 | 5 | 1000 | 0 | 10.99 | 91.01 | 525.6 | 115.2 | 707.3 | 2709→2809 |
| 100 | 1 | 2000 | 0 | 22.13 | 90.38 | 1071.3 | 239.3 | 1470.6 | 2809→3009 |
| 100 | 2 | 2000 | 0 | 21.23 | 94.21 | 1034.5 | 187.7 | 1321.7 | 3009→3209 |
| 100 | 3 | 2000 | 0 | 21.73 | 92.04 | 1060.6 | 223.0 | 1409.1 | 3209→3409 |
| 100 | 4 | 2000 | 0 | 20.80 | 96.16 | 1012.9 | 207.2 | 1329.1 | 3409→3609 |
| 100 | 5 | 2000 | 0 | 20.60 | 97.09 | 999.7 | 178.0 | 1313.6 | 3609→3809 |

## Fault test: SIGKILL a Raft follower orderer (5 trials)

| Trial | killed pid | commits before kill | commits after kill (45 s window) | failed submissions | recovery A: first commit after kill (s) | recovery B: first commit of a tx started after kill (s) | max gap between commits (s) |
|---|---|---|---|---|---|---|---|
| follower_t1 | 3687 | 16 | 184 | 0 | 1.059 | 1.059 | 2.311 |
| follower_t2 | 4457 | 17 | 183 | 0 | 1.330 | 1.330 | 2.272 |
| follower_t3 | 4591 | 16 | 184 | 0 | 1.058 | 1.058 | 2.260 |
| follower_t4 | 4678 | 16 | 184 | 0 | 1.054 | 1.054 | 2.263 |
| follower_t5 | 4765 | 16 | 184 | 0 | 1.079 | 1.079 | 2.253 |
| **mean ± std** | | | | | **1.12 ± 0.12** | **1.12 ± 0.12** | **2.27 ± 0.02** |

## Fault test: SIGKILL the Raft leader orderer (5 trials)

| Trial | killed pid | commits before kill | commits after kill (45 s window) | failed submissions | recovery A: first commit after kill (s) | recovery B: first commit of a tx started after kill (s) | max gap between commits (s) |
|---|---|---|---|---|---|---|---|
| leader_t1 | 3693 | 16 | 140 | 44 | 12.097 | 12.097 | 13.054 |
| leader_t2 | 3694 | 16 | 128 | 56 | 15.095 | 15.095 | 16.037 |
| leader_t3 | 4856 | 16 | 72 | 112 | 30.551 | 30.551 | 31.505 |
| leader_t4 | 5025 | 16 | 150 | 34 | 14.610 | 14.610 | 15.557 |
| leader_t5 | 4942 | 16 | 125 | 59 | 19.881 | 19.881 | 20.821 |
| **mean ± std** | | | | | **18.45 ± 7.33** | **18.45 ± 7.33** | **19.39 ± 7.33** |

Distinct submission errors observed during these trials:

- `rpc error: code = DeadlineExceeded desc = context deadline exceeded`
- `rpc error: code = Unavailable desc = no orderers could successfully process transaction`

## Fault test: SIGKILL peer1.org1 (non-gateway Org1 peer)

- killed pid 3689; commits before kill: 17; commits in the 30 s after kill: 123; failed submissions: 0
- first commit after kill: 1.311 s; first commit of a tx started after kill: 1.311 s; max gap between commits: 2.234 s

## Fault test: SIGKILL peer0.org2 (Org2 peer)

- killed pid 3690; commits before kill: 17; commits in the 30 s after kill: 123; failed submissions: 0
- first commit after kill: 1.321 s; first commit of a tx started after kill: 1.321 s; max gap between commits: 2.264 s

