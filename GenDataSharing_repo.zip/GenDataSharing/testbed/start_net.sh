#!/bin/bash
# Starts 3 Raft orderers + 4 peers (2 orgs x 2 peers) as plain processes, no Docker.
set -u
cd ${FABRIC_WORK:-$HOME/fabric-work}/fabric-samples/test-network-nano-bash
mkdir -p logs
export CORE_VM_ENDPOINT=""         # disable docker chaincode builder entirely
export CORE_CHAINCODE_EXECUTETIMEOUT=60s
for i in 1 2 3; do
  [ -z "${SKIP_ORDERERS:-}" ] && { setsid ./orderer$i.sh > logs/orderer$i.log 2>&1 & echo "orderer$i pid $!"; }
done
for p in 1 2 3 4; do
  [ -z "${SKIP_PEERS:-}" ] && { setsid ./peer$p.sh > logs/peer$p.log 2>&1 & echo "peer$p pid $!"; }
done
